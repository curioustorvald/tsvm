// CheckStyle: start generated
package com.oracle.truffle.runtime;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.provider.InternalResourceProvider;

@GeneratedBy(LibTruffleAttachResource.class)
public final class LibTruffleAttachResourceProvider extends InternalResourceProvider {

    @Override
    protected String getComponentId() {
        return "engine";
    }

    @Override
    protected String getResourceId() {
        return "libtruffleattach";
    }

    @Override
    protected Object createInternalResource() {
        return new LibTruffleAttachResource();
    }

}
