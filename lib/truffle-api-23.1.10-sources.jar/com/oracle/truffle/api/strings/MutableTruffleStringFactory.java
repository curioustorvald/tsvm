// CheckStyle: start generated
package com.oracle.truffle.api.strings;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.InlineSupport;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.RequiredField;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.InlinedBranchProfile;
import com.oracle.truffle.api.profiles.InlinedConditionProfile;
import com.oracle.truffle.api.strings.AbstractTruffleString.NativePointer;
import com.oracle.truffle.api.strings.MutableTruffleString.AsManagedNode;
import com.oracle.truffle.api.strings.MutableTruffleString.AsMutableTruffleStringNode;
import com.oracle.truffle.api.strings.MutableTruffleString.CalcLazyAttributesNode;
import com.oracle.truffle.api.strings.MutableTruffleString.ConcatNode;
import com.oracle.truffle.api.strings.MutableTruffleString.DataClassProfile;
import com.oracle.truffle.api.strings.MutableTruffleString.ForceEncodingNode;
import com.oracle.truffle.api.strings.MutableTruffleString.FromByteArrayNode;
import com.oracle.truffle.api.strings.MutableTruffleString.FromNativePointerNode;
import com.oracle.truffle.api.strings.MutableTruffleString.SubstringByteIndexNode;
import com.oracle.truffle.api.strings.MutableTruffleString.SubstringNode;
import com.oracle.truffle.api.strings.MutableTruffleString.SwitchEncodingNode;
import com.oracle.truffle.api.strings.MutableTruffleString.WriteByteNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.CodePointIndexToRawNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.ConcatMaterializeBytesNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.GetCodePointLengthNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.GetCodeRangeForIndexCalculationNode;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.CodePointIndexToRawNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.ConcatMaterializeBytesNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.GetCodePointLengthNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.GetCodeRangeForIndexCalculationNodeGen;
import com.oracle.truffle.api.strings.TruffleString.CopyToByteArrayNode;
import com.oracle.truffle.api.strings.TruffleString.Encoding;
import com.oracle.truffle.api.strings.TruffleString.InternalSwitchEncodingNode;
import com.oracle.truffle.api.strings.TruffleString.ToIndexableNode;
import com.oracle.truffle.api.strings.TruffleStringFactory.InternalSwitchEncodingNodeGen;
import com.oracle.truffle.api.strings.TruffleStringFactory.ToIndexableNodeGen;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Objects;

@GeneratedBy(MutableTruffleString.class)
@SuppressWarnings("javadoc")
public final class MutableTruffleStringFactory {

    /**
     * Debug Info: <pre>
     *   Specialization {@link FromByteArrayNode#fromByteArray}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(FromByteArrayNode.class)
    @SuppressWarnings("javadoc")
    static final class FromByteArrayNodeGen extends FromByteArrayNode {

        private static final Uncached UNCACHED = new Uncached();

        private FromByteArrayNodeGen() {
        }

        @Override
        public MutableTruffleString execute(byte[] arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            return FromByteArrayNode.fromByteArray(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static FromByteArrayNode create() {
            return new FromByteArrayNodeGen();
        }

        @NeverDefault
        public static FromByteArrayNode getUncached() {
            return FromByteArrayNodeGen.UNCACHED;
        }

        @GeneratedBy(FromByteArrayNode.class)
        @DenyReplace
        private static final class Uncached extends FromByteArrayNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(byte[] arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
                return FromByteArrayNode.fromByteArray(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link FromNativePointerNode#fromNativePointer}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(FromNativePointerNode.class)
    @SuppressWarnings("javadoc")
    static final class FromNativePointerNodeGen extends FromNativePointerNode {

        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link FromNativePointerNode#fromNativePointer}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromNativePointerNode#fromNativePointer}
         *   Parameter: {@link Node} interopLibrary</pre>
         */
        @Child private Node interopLibrary_;

        private FromNativePointerNodeGen() {
        }

        @Override
        public MutableTruffleString execute(Object arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[MutableTruffleString.FromNativePointerNode.fromNativePointer(Object, int, int, Encoding, boolean, Node)] */) {
                {
                    Node interopLibrary__ = this.interopLibrary_;
                    if (interopLibrary__ != null) {
                        return fromNativePointer(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, interopLibrary__);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
        }

        private MutableTruffleString executeAndSpecialize(Object arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            int state_0 = this.state_0_;
            Node interopLibrary__ = this.insert((TStringAccessor.createInteropLibrary()));
            Objects.requireNonNull(interopLibrary__, "Specialization 'fromNativePointer(Object, int, int, Encoding, boolean, Node)' cache 'interopLibrary' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.interopLibrary_ = interopLibrary__;
            state_0 = state_0 | 0b1 /* add SpecializationActive[MutableTruffleString.FromNativePointerNode.fromNativePointer(Object, int, int, Encoding, boolean, Node)] */;
            this.state_0_ = state_0;
            return fromNativePointer(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, interopLibrary__);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static FromNativePointerNode create() {
            return new FromNativePointerNodeGen();
        }

        @NeverDefault
        public static FromNativePointerNode getUncached() {
            return FromNativePointerNodeGen.UNCACHED;
        }

        @GeneratedBy(FromNativePointerNode.class)
        @DenyReplace
        private static final class Uncached extends FromNativePointerNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(Object arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
                return fromNativePointer(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (TStringAccessor.getUncachedInteropLibrary()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AsMutableTruffleStringNode#mutable}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link AsMutableTruffleStringNode#fromTruffleString}
     *     Activation probability: 0.35000
     *     With/without class size: 11/1 bytes
     * </pre>
     */
    @GeneratedBy(AsMutableTruffleStringNode.class)
    @SuppressWarnings("javadoc")
    static final class AsMutableTruffleStringNodeGen extends AsMutableTruffleStringNode {

        private static final StateField STATE_0_AsMutableTruffleStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsMutableTruffleStringNode#fromTruffleString}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_FROM_TRUFFLE_STRING_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_AsMutableTruffleStringNode_UPDATER.subUpdater(2, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AsMutableTruffleStringNode#mutable}
         *   1: SpecializationActive {@link AsMutableTruffleStringNode#fromTruffleString}
         *   2-8: InlinedCache
         *        Specialization: {@link AsMutableTruffleStringNode#fromTruffleString}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AsMutableTruffleStringNodeGen() {
        }

        @Override
        public MutableTruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[MutableTruffleString.AsMutableTruffleStringNode.mutable(MutableTruffleString, Encoding)] || SpecializationActive[MutableTruffleString.AsMutableTruffleStringNode.fromTruffleString(TruffleString, Encoding, Node, ToIndexableNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[MutableTruffleString.AsMutableTruffleStringNode.mutable(MutableTruffleString, Encoding)] */ && arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    return AsMutableTruffleStringNode.mutable(arg0Value_, arg1Value);
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[MutableTruffleString.AsMutableTruffleStringNode.fromTruffleString(TruffleString, Encoding, Node, ToIndexableNode)] */ && arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    {
                        Node node__ = (this);
                        return AsMutableTruffleStringNode.fromTruffleString(arg0Value_, arg1Value, node__, INLINED_FROM_TRUFFLE_STRING_TO_INDEXABLE_NODE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private MutableTruffleString executeAndSpecialize(AbstractTruffleString arg0Value, Encoding arg1Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof MutableTruffleString) {
                MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[MutableTruffleString.AsMutableTruffleStringNode.mutable(MutableTruffleString, Encoding)] */;
                this.state_0_ = state_0;
                return AsMutableTruffleStringNode.mutable(arg0Value_, arg1Value);
            }
            {
                Node node__ = null;
                if (arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    node__ = (this);
                    state_0 = state_0 | 0b10 /* add SpecializationActive[MutableTruffleString.AsMutableTruffleStringNode.fromTruffleString(TruffleString, Encoding, Node, ToIndexableNode)] */;
                    this.state_0_ = state_0;
                    return AsMutableTruffleStringNode.fromTruffleString(arg0Value_, arg1Value, node__, INLINED_FROM_TRUFFLE_STRING_TO_INDEXABLE_NODE_);
                }
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if (((state_0 & 0b11) & ((state_0 & 0b11) - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static AsMutableTruffleStringNode create() {
            return new AsMutableTruffleStringNodeGen();
        }

        @NeverDefault
        public static AsMutableTruffleStringNode getUncached() {
            return AsMutableTruffleStringNodeGen.UNCACHED;
        }

        @GeneratedBy(AsMutableTruffleStringNode.class)
        @DenyReplace
        private static final class Uncached extends AsMutableTruffleStringNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    return AsMutableTruffleStringNode.mutable(arg0Value_, arg1Value);
                }
                if (arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    return AsMutableTruffleStringNode.fromTruffleString(arg0Value_, arg1Value, (this), (ToIndexableNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AsManagedNode#mutable}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link AsManagedNode#fromTruffleString}
     *     Activation probability: 0.35000
     *     With/without class size: 11/1 bytes
     * </pre>
     */
    @GeneratedBy(AsManagedNode.class)
    @SuppressWarnings("javadoc")
    static final class AsManagedNodeGen extends AsManagedNode {

        private static final StateField STATE_0_AsManagedNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsManagedNode#fromTruffleString}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_FROM_TRUFFLE_STRING_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_AsManagedNode_UPDATER.subUpdater(2, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AsManagedNode#mutable}
         *   1: SpecializationActive {@link AsManagedNode#fromTruffleString}
         *   2-8: InlinedCache
         *        Specialization: {@link AsManagedNode#fromTruffleString}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AsManagedNodeGen() {
        }

        @Override
        public MutableTruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[MutableTruffleString.AsManagedNode.mutable(MutableTruffleString, Encoding)] || SpecializationActive[MutableTruffleString.AsManagedNode.fromTruffleString(AbstractTruffleString, Encoding, Node, ToIndexableNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[MutableTruffleString.AsManagedNode.mutable(MutableTruffleString, Encoding)] */ && arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((!(arg0Value_.isNative()))) {
                        return AsManagedNode.mutable(arg0Value_, arg1Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[MutableTruffleString.AsManagedNode.fromTruffleString(AbstractTruffleString, Encoding, Node, ToIndexableNode)] */) {
                    if ((arg0Value.isNative() || arg0Value.isImmutable())) {
                        Node node__ = (this);
                        return AsManagedNode.fromTruffleString(arg0Value, arg1Value, node__, INLINED_FROM_TRUFFLE_STRING_TO_INDEXABLE_NODE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private MutableTruffleString executeAndSpecialize(AbstractTruffleString arg0Value, Encoding arg1Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof MutableTruffleString) {
                MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                if ((!(arg0Value_.isNative()))) {
                    state_0 = state_0 | 0b1 /* add SpecializationActive[MutableTruffleString.AsManagedNode.mutable(MutableTruffleString, Encoding)] */;
                    this.state_0_ = state_0;
                    return AsManagedNode.mutable(arg0Value_, arg1Value);
                }
            }
            {
                Node node__ = null;
                if ((arg0Value.isNative() || arg0Value.isImmutable())) {
                    node__ = (this);
                    state_0 = state_0 | 0b10 /* add SpecializationActive[MutableTruffleString.AsManagedNode.fromTruffleString(AbstractTruffleString, Encoding, Node, ToIndexableNode)] */;
                    this.state_0_ = state_0;
                    return AsManagedNode.fromTruffleString(arg0Value, arg1Value, node__, INLINED_FROM_TRUFFLE_STRING_TO_INDEXABLE_NODE_);
                }
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if (((state_0 & 0b11) & ((state_0 & 0b11) - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static AsManagedNode create() {
            return new AsManagedNodeGen();
        }

        @NeverDefault
        public static AsManagedNode getUncached() {
            return AsManagedNodeGen.UNCACHED;
        }

        @GeneratedBy(AsManagedNode.class)
        @DenyReplace
        private static final class Uncached extends AsManagedNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((!(arg0Value_.isNative()))) {
                        return AsManagedNode.mutable(arg0Value_, arg1Value);
                    }
                }
                if ((arg0Value.isNative() || arg0Value.isImmutable())) {
                    return AsManagedNode.fromTruffleString(arg0Value, arg1Value, (this), (ToIndexableNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link WriteByteNode#writeByte}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(WriteByteNode.class)
    @SuppressWarnings("javadoc")
    static final class WriteByteNodeGen extends WriteByteNode {

        private static final Uncached UNCACHED = new Uncached();

        private WriteByteNodeGen() {
        }

        @Override
        public void execute(MutableTruffleString arg0Value, int arg1Value, byte arg2Value, Encoding arg3Value) {
            WriteByteNode.writeByte(arg0Value, arg1Value, arg2Value, arg3Value);
            return;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static WriteByteNode create() {
            return new WriteByteNodeGen();
        }

        @NeverDefault
        public static WriteByteNode getUncached() {
            return WriteByteNodeGen.UNCACHED;
        }

        @GeneratedBy(WriteByteNode.class)
        @DenyReplace
        private static final class Uncached extends WriteByteNode {

            @TruffleBoundary
            @Override
            public void execute(MutableTruffleString arg0Value, int arg1Value, byte arg2Value, Encoding arg3Value) {
                WriteByteNode.writeByte(arg0Value, arg1Value, arg2Value, arg3Value);
                return;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ConcatNode#concat}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(ConcatNode.class)
    @SuppressWarnings("javadoc")
    static final class ConcatNodeGen extends ConcatNode {

        private static final StateField STATE_0_ConcatNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#concat}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ConcatNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#concat}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ConcatNode_UPDATER.subUpdater(7, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#concat}
         *   Parameter: {@link ConcatMaterializeBytesNode} materializeBytesNode
         *   Inline method: {@link ConcatMaterializeBytesNodeGen#inline}</pre>
         */
        private static final ConcatMaterializeBytesNode INLINED_MATERIALIZE_BYTES_NODE_ = ConcatMaterializeBytesNodeGen.inline(InlineTarget.create(ConcatMaterializeBytesNode.class, STATE_0_ConcatNode_UPDATER.subUpdater(14, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#concat}
         *   Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_OUT_OF_MEMORY_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_ConcatNode_UPDATER.subUpdater(16, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link ConcatNode#concat}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link ConcatNode#concat}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   14-15: InlinedCache
         *        Specialization: {@link ConcatNode#concat}
         *        Parameter: {@link ConcatMaterializeBytesNode} materializeBytesNode
         *        Inline method: {@link ConcatMaterializeBytesNodeGen#inline}
         *   16: InlinedCache
         *        Specialization: {@link ConcatNode#concat}
         *        Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private ConcatNodeGen() {
        }

        @Override
        public MutableTruffleString execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
            return concat(arg0Value, arg1Value, arg2Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_, INLINED_MATERIALIZE_BYTES_NODE_, INLINED_OUT_OF_MEMORY_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static ConcatNode create() {
            return new ConcatNodeGen();
        }

        @NeverDefault
        public static ConcatNode getUncached() {
            return ConcatNodeGen.UNCACHED;
        }

        @GeneratedBy(ConcatNode.class)
        @DenyReplace
        private static final class Uncached extends ConcatNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
                return concat(arg0Value, arg1Value, arg2Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()), (ConcatMaterializeBytesNodeGen.getUncached()), (InlinedBranchProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link SubstringNode#substring}
     *     Activation probability: 1.00000
     *     With/without class size: 32/12 bytes
     * </pre>
     */
    @GeneratedBy(SubstringNode.class)
    @SuppressWarnings("javadoc")
    static final class SubstringNodeGen extends SubstringNode {

        private static final StateField STATE_0_SubstringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_SubstringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_SubstringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link SubstringNode#substring}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_SubstringNode_UPDATER.subUpdater(1, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link SubstringNode#substring}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_1_SubstringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link SubstringNode#substring}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_2_SubstringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link SubstringNode#substring}
         *   Parameter: {@link CodePointIndexToRawNode} translateIndexNode
         *   Inline method: {@link CodePointIndexToRawNodeGen#inline}</pre>
         */
        private static final CodePointIndexToRawNode INLINED_TRANSLATE_INDEX_NODE_ = CodePointIndexToRawNodeGen.inline(InlineTarget.create(CodePointIndexToRawNode.class, STATE_0_SubstringNode_UPDATER.subUpdater(8, 6)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link SubstringNode#substring}
         *   1-7: InlinedCache
         *        Specialization: {@link SubstringNode#substring}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   8-13: InlinedCache
         *        Specialization: {@link SubstringNode#substring}
         *        Parameter: {@link CodePointIndexToRawNode} translateIndexNode
         *        Inline method: {@link CodePointIndexToRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link SubstringNode#substring}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link SubstringNode#substring}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link SubstringNode#substring}
         *   Parameter: {@link CopyToByteArrayNode} copyToByteArrayNode</pre>
         */
        @Child private CopyToByteArrayNode copyToByteArrayNode_;

        private SubstringNodeGen() {
        }

        @Override
        public MutableTruffleString execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[MutableTruffleString.SubstringNode.substring(AbstractTruffleString, int, int, Encoding, ToIndexableNode, GetCodeRangeForIndexCalculationNode, GetCodePointLengthNode, CodePointIndexToRawNode, CopyToByteArrayNode)] */) {
                {
                    CopyToByteArrayNode copyToByteArrayNode__ = this.copyToByteArrayNode_;
                    if (copyToByteArrayNode__ != null) {
                        return substring(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_A_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_TRANSLATE_INDEX_NODE_, copyToByteArrayNode__);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
        }

        private MutableTruffleString executeAndSpecialize(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
            int state_0 = this.state_0_;
            CopyToByteArrayNode copyToByteArrayNode__ = this.insert((CopyToByteArrayNode.create()));
            Objects.requireNonNull(copyToByteArrayNode__, "Specialization 'substring(AbstractTruffleString, int, int, Encoding, ToIndexableNode, GetCodeRangeForIndexCalculationNode, GetCodePointLengthNode, CodePointIndexToRawNode, CopyToByteArrayNode)' cache 'copyToByteArrayNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.copyToByteArrayNode_ = copyToByteArrayNode__;
            state_0 = state_0 | 0b1 /* add SpecializationActive[MutableTruffleString.SubstringNode.substring(AbstractTruffleString, int, int, Encoding, ToIndexableNode, GetCodeRangeForIndexCalculationNode, GetCodePointLengthNode, CodePointIndexToRawNode, CopyToByteArrayNode)] */;
            this.state_0_ = state_0;
            return substring(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_A_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_TRANSLATE_INDEX_NODE_, copyToByteArrayNode__);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static SubstringNode create() {
            return new SubstringNodeGen();
        }

        @NeverDefault
        public static SubstringNode getUncached() {
            return SubstringNodeGen.UNCACHED;
        }

        @GeneratedBy(SubstringNode.class)
        @DenyReplace
        private static final class Uncached extends SubstringNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
                return substring(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (CodePointIndexToRawNodeGen.getUncached()), (CopyToByteArrayNode.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link SubstringByteIndexNode#substringByteIndex}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(SubstringByteIndexNode.class)
    @SuppressWarnings("javadoc")
    static final class SubstringByteIndexNodeGen extends SubstringByteIndexNode {

        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link SubstringByteIndexNode#substringByteIndex}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link SubstringByteIndexNode#substringByteIndex}
         *   Parameter: {@link CopyToByteArrayNode} copyToByteArrayNode</pre>
         */
        @Child private CopyToByteArrayNode copyToByteArrayNode_;

        private SubstringByteIndexNodeGen() {
        }

        @Override
        public MutableTruffleString execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[MutableTruffleString.SubstringByteIndexNode.substringByteIndex(AbstractTruffleString, int, int, Encoding, CopyToByteArrayNode)] */) {
                {
                    CopyToByteArrayNode copyToByteArrayNode__ = this.copyToByteArrayNode_;
                    if (copyToByteArrayNode__ != null) {
                        return SubstringByteIndexNode.substringByteIndex(arg0Value, arg1Value, arg2Value, arg3Value, copyToByteArrayNode__);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
        }

        private MutableTruffleString executeAndSpecialize(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
            int state_0 = this.state_0_;
            CopyToByteArrayNode copyToByteArrayNode__ = this.insert((CopyToByteArrayNode.create()));
            Objects.requireNonNull(copyToByteArrayNode__, "Specialization 'substringByteIndex(AbstractTruffleString, int, int, Encoding, CopyToByteArrayNode)' cache 'copyToByteArrayNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.copyToByteArrayNode_ = copyToByteArrayNode__;
            state_0 = state_0 | 0b1 /* add SpecializationActive[MutableTruffleString.SubstringByteIndexNode.substringByteIndex(AbstractTruffleString, int, int, Encoding, CopyToByteArrayNode)] */;
            this.state_0_ = state_0;
            return SubstringByteIndexNode.substringByteIndex(arg0Value, arg1Value, arg2Value, arg3Value, copyToByteArrayNode__);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static SubstringByteIndexNode create() {
            return new SubstringByteIndexNodeGen();
        }

        @NeverDefault
        public static SubstringByteIndexNode getUncached() {
            return SubstringByteIndexNodeGen.UNCACHED;
        }

        @GeneratedBy(SubstringByteIndexNode.class)
        @DenyReplace
        private static final class Uncached extends SubstringByteIndexNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
                return SubstringByteIndexNode.substringByteIndex(arg0Value, arg1Value, arg2Value, arg3Value, (CopyToByteArrayNode.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link SwitchEncodingNode#compatibleMutable}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link SwitchEncodingNode#transcodeAndCopy}
     *     Activation probability: 0.35000
     *     With/without class size: 27/50 bytes
     * </pre>
     */
    @GeneratedBy(SwitchEncodingNode.class)
    @SuppressWarnings("javadoc")
    static final class SwitchEncodingNodeGen extends SwitchEncodingNode {

        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_0_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_0_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_1_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_1_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_2_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_2_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_3_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_3_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_4_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_4_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_5_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_5_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_6_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_6_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_7_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_7_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_8_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_8_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_9_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_9_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_10_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_10_");
        private static final StateField TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_11_UPDATER = StateField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_state_11_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
         *   Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *   Inline method: {@link InternalSwitchEncodingNodeGen#inline}</pre>
         */
        private static final InternalSwitchEncodingNode INLINED_TRANSCODE_AND_COPY_SWITCH_ENCODING_NODE_ = InternalSwitchEncodingNodeGen.inline(InlineTarget.create(InternalSwitchEncodingNode.class, TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_0_UPDATER.subUpdater(0, 31), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_1_UPDATER.subUpdater(0, 31), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_2_UPDATER.subUpdater(0, 31), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_3_UPDATER.subUpdater(0, 29), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_4_UPDATER.subUpdater(0, 32), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_5_UPDATER.subUpdater(0, 26), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_6_UPDATER.subUpdater(0, 25), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_7_UPDATER.subUpdater(0, 25), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_8_UPDATER.subUpdater(0, 25), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_9_UPDATER.subUpdater(0, 24), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_10_UPDATER.subUpdater(0, 32), TRANSCODE_AND_COPY__SWITCH_ENCODING_NODE_TRANSCODE_AND_COPY_STATE_11_UPDATER.subUpdater(0, 25), ReferenceField.create(TranscodeAndCopyData.lookup_(), "transcodeAndCopy_switchEncodingNode__field12_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link SwitchEncodingNode#compatibleMutable}
         *   1: SpecializationActive {@link SwitchEncodingNode#transcodeAndCopy}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        @Child private TranscodeAndCopyData transcodeAndCopy_cache;

        private SwitchEncodingNodeGen() {
        }

        @Override
        public MutableTruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, TranscodingErrorHandler arg2Value) {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[MutableTruffleString.SwitchEncodingNode.compatibleMutable(MutableTruffleString, Encoding, TranscodingErrorHandler)] || SpecializationActive[MutableTruffleString.SwitchEncodingNode.transcodeAndCopy(AbstractTruffleString, Encoding, TranscodingErrorHandler, Node, InternalSwitchEncodingNode, AsMutableTruffleStringNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[MutableTruffleString.SwitchEncodingNode.compatibleMutable(MutableTruffleString, Encoding, TranscodingErrorHandler)] */ && arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((arg0Value_.isCompatibleToIntl(arg1Value))) {
                        return SwitchEncodingNode.compatibleMutable(arg0Value_, arg1Value, arg2Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[MutableTruffleString.SwitchEncodingNode.transcodeAndCopy(AbstractTruffleString, Encoding, TranscodingErrorHandler, Node, InternalSwitchEncodingNode, AsMutableTruffleStringNode)] */) {
                    TranscodeAndCopyData s1_ = this.transcodeAndCopy_cache;
                    if (s1_ != null) {
                        if ((!(arg0Value.isCompatibleToIntl(arg1Value)) || arg0Value.isImmutable())) {
                            Node node__ = (s1_);
                            return SwitchEncodingNode.transcodeAndCopy(arg0Value, arg1Value, arg2Value, node__, INLINED_TRANSCODE_AND_COPY_SWITCH_ENCODING_NODE_, s1_.asMutableTruffleStringNode_);
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private MutableTruffleString executeAndSpecialize(AbstractTruffleString arg0Value, Encoding arg1Value, TranscodingErrorHandler arg2Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof MutableTruffleString) {
                MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                if ((arg0Value_.isCompatibleToIntl(arg1Value))) {
                    state_0 = state_0 | 0b1 /* add SpecializationActive[MutableTruffleString.SwitchEncodingNode.compatibleMutable(MutableTruffleString, Encoding, TranscodingErrorHandler)] */;
                    this.state_0_ = state_0;
                    return SwitchEncodingNode.compatibleMutable(arg0Value_, arg1Value, arg2Value);
                }
            }
            {
                Node node__ = null;
                if ((!(arg0Value.isCompatibleToIntl(arg1Value)) || arg0Value.isImmutable())) {
                    TranscodeAndCopyData s1_ = this.insert(new TranscodeAndCopyData());
                    node__ = (s1_);
                    AsMutableTruffleStringNode asMutableTruffleStringNode__ = s1_.insert((AsMutableTruffleStringNode.create()));
                    Objects.requireNonNull(asMutableTruffleStringNode__, "Specialization 'transcodeAndCopy(AbstractTruffleString, Encoding, TranscodingErrorHandler, Node, InternalSwitchEncodingNode, AsMutableTruffleStringNode)' cache 'asMutableTruffleStringNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                    s1_.asMutableTruffleStringNode_ = asMutableTruffleStringNode__;
                    VarHandle.storeStoreFence();
                    this.transcodeAndCopy_cache = s1_;
                    state_0 = state_0 | 0b10 /* add SpecializationActive[MutableTruffleString.SwitchEncodingNode.transcodeAndCopy(AbstractTruffleString, Encoding, TranscodingErrorHandler, Node, InternalSwitchEncodingNode, AsMutableTruffleStringNode)] */;
                    this.state_0_ = state_0;
                    return SwitchEncodingNode.transcodeAndCopy(arg0Value, arg1Value, arg2Value, node__, INLINED_TRANSCODE_AND_COPY_SWITCH_ENCODING_NODE_, asMutableTruffleStringNode__);
                }
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static SwitchEncodingNode create() {
            return new SwitchEncodingNodeGen();
        }

        @NeverDefault
        public static SwitchEncodingNode getUncached() {
            return SwitchEncodingNodeGen.UNCACHED;
        }

        @GeneratedBy(SwitchEncodingNode.class)
        @DenyReplace
        private static final class TranscodeAndCopyData extends Node implements SpecializationDataNode {

            /**
             * State Info: <pre>
             *   0-30: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_0_;
            /**
             * State Info: <pre>
             *   0-30: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_1_;
            /**
             * State Info: <pre>
             *   0-30: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_2_;
            /**
             * State Info: <pre>
             *   0-28: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_3_;
            /**
             * State Info: <pre>
             *   0-31: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_4_;
            /**
             * State Info: <pre>
             *   0-25: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_5_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_6_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_7_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_8_;
            /**
             * State Info: <pre>
             *   0-23: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_9_;
            /**
             * State Info: <pre>
             *   0-31: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_10_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int transcodeAndCopy_state_11_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *   Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
             *   Inline method: {@link InternalSwitchEncodingNodeGen#inline}
             *   Inline field: {@link Node} field12</pre>
             */
            @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node transcodeAndCopy_switchEncodingNode__field12_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link SwitchEncodingNode#transcodeAndCopy}
             *   Parameter: {@link AsMutableTruffleStringNode} asMutableTruffleStringNode</pre>
             */
            @Child AsMutableTruffleStringNode asMutableTruffleStringNode_;

            TranscodeAndCopyData() {
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

            private static Lookup lookup_() {
                return MethodHandles.lookup();
            }

        }
        @GeneratedBy(SwitchEncodingNode.class)
        @DenyReplace
        private static final class Uncached extends SwitchEncodingNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, TranscodingErrorHandler arg2Value) {
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((arg0Value_.isCompatibleToIntl(arg1Value))) {
                        return SwitchEncodingNode.compatibleMutable(arg0Value_, arg1Value, arg2Value);
                    }
                }
                if ((!(arg0Value.isCompatibleToIntl(arg1Value)) || arg0Value.isImmutable())) {
                    return SwitchEncodingNode.transcodeAndCopy(arg0Value, arg1Value, arg2Value, (this), (InternalSwitchEncodingNodeGen.getUncached()), (AsMutableTruffleStringNode.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ForceEncodingNode#compatible}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link ForceEncodingNode#reinterpret}
     *     Activation probability: 0.35000
     *     With/without class size: 11/1 bytes
     * </pre>
     */
    @GeneratedBy(ForceEncodingNode.class)
    @SuppressWarnings("javadoc")
    static final class ForceEncodingNodeGen extends ForceEncodingNode {

        private static final StateField STATE_0_ForceEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ForceEncodingNode#reinterpret}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_REINTERPRET_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ForceEncodingNode_UPDATER.subUpdater(2, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link ForceEncodingNode#compatible}
         *   1: SpecializationActive {@link ForceEncodingNode#reinterpret}
         *   2-8: InlinedCache
         *        Specialization: {@link ForceEncodingNode#reinterpret}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private ForceEncodingNodeGen() {
        }

        @Override
        public MutableTruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, Encoding arg2Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[MutableTruffleString.ForceEncodingNode.compatible(MutableTruffleString, Encoding, Encoding)] || SpecializationActive[MutableTruffleString.ForceEncodingNode.reinterpret(AbstractTruffleString, Encoding, Encoding, Node, ToIndexableNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[MutableTruffleString.ForceEncodingNode.compatible(MutableTruffleString, Encoding, Encoding)] */ && arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((arg0Value_.isCompatibleToIntl(arg2Value))) {
                        return ForceEncodingNode.compatible(arg0Value_, arg1Value, arg2Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[MutableTruffleString.ForceEncodingNode.reinterpret(AbstractTruffleString, Encoding, Encoding, Node, ToIndexableNode)] */) {
                    if ((!(arg0Value.isCompatibleToIntl(arg2Value)) || arg0Value.isImmutable())) {
                        Node node__ = (this);
                        return ForceEncodingNode.reinterpret(arg0Value, arg1Value, arg2Value, node__, INLINED_REINTERPRET_TO_INDEXABLE_NODE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private MutableTruffleString executeAndSpecialize(AbstractTruffleString arg0Value, Encoding arg1Value, Encoding arg2Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof MutableTruffleString) {
                MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                if ((arg0Value_.isCompatibleToIntl(arg2Value))) {
                    state_0 = state_0 | 0b1 /* add SpecializationActive[MutableTruffleString.ForceEncodingNode.compatible(MutableTruffleString, Encoding, Encoding)] */;
                    this.state_0_ = state_0;
                    return ForceEncodingNode.compatible(arg0Value_, arg1Value, arg2Value);
                }
            }
            {
                Node node__ = null;
                if ((!(arg0Value.isCompatibleToIntl(arg2Value)) || arg0Value.isImmutable())) {
                    node__ = (this);
                    state_0 = state_0 | 0b10 /* add SpecializationActive[MutableTruffleString.ForceEncodingNode.reinterpret(AbstractTruffleString, Encoding, Encoding, Node, ToIndexableNode)] */;
                    this.state_0_ = state_0;
                    return ForceEncodingNode.reinterpret(arg0Value, arg1Value, arg2Value, node__, INLINED_REINTERPRET_TO_INDEXABLE_NODE_);
                }
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if (((state_0 & 0b11) & ((state_0 & 0b11) - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static ForceEncodingNode create() {
            return new ForceEncodingNodeGen();
        }

        @NeverDefault
        public static ForceEncodingNode getUncached() {
            return ForceEncodingNodeGen.UNCACHED;
        }

        @GeneratedBy(ForceEncodingNode.class)
        @DenyReplace
        private static final class Uncached extends ForceEncodingNode {

            @TruffleBoundary
            @Override
            public MutableTruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, Encoding arg2Value) {
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((arg0Value_.isCompatibleToIntl(arg2Value))) {
                        return ForceEncodingNode.compatible(arg0Value_, arg1Value, arg2Value);
                    }
                }
                if ((!(arg0Value.isCompatibleToIntl(arg2Value)) || arg0Value.isImmutable())) {
                    return ForceEncodingNode.reinterpret(arg0Value, arg1Value, arg2Value, (this), (ToIndexableNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link DataClassProfile#doByteArray}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link DataClassProfile#doNativePointer}
     *     Activation probability: 0.35000
     *     With/without class size: 8/0 bytes
     * </pre>
     */
    @GeneratedBy(DataClassProfile.class)
    @SuppressWarnings("javadoc")
    static final class DataClassProfileNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static DataClassProfile getUncached() {
            return DataClassProfileNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * </ul>
         */
        @NeverDefault
        public static DataClassProfile inline(@RequiredField(bits = 2, value = StateField.class) InlineTarget target) {
            return new DataClassProfileNodeGen.Inlined(target);
        }

        @GeneratedBy(DataClassProfile.class)
        @DenyReplace
        private static final class Inlined extends DataClassProfile {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link DataClassProfile#doByteArray}
             *   1: SpecializationActive {@link DataClassProfile#doNativePointer}
             * </pre>
             */
            private final StateField state_0_;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(DataClassProfile.class);
                this.state_0_ = target.getState(0, 2);
            }

            @Override
            Object execute(Node arg0Value, Object arg1Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if (state_0 != 0 /* is SpecializationActive[MutableTruffleString.DataClassProfile.doByteArray(byte[])] || SpecializationActive[MutableTruffleString.DataClassProfile.doNativePointer(NativePointer)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[MutableTruffleString.DataClassProfile.doByteArray(byte[])] */ && arg1Value instanceof byte[]) {
                        byte[] arg1Value_ = (byte[]) arg1Value;
                        return DataClassProfile.doByteArray(arg1Value_);
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[MutableTruffleString.DataClassProfile.doNativePointer(NativePointer)] */ && arg1Value instanceof NativePointer) {
                        NativePointer arg1Value_ = (NativePointer) arg1Value;
                        return DataClassProfile.doNativePointer(arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value);
            }

            private Object executeAndSpecialize(Node arg0Value, Object arg1Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if (arg1Value instanceof byte[]) {
                    byte[] arg1Value_ = (byte[]) arg1Value;
                    state_0 = state_0 | 0b1 /* add SpecializationActive[MutableTruffleString.DataClassProfile.doByteArray(byte[])] */;
                    this.state_0_.set(arg0Value, state_0);
                    return DataClassProfile.doByteArray(arg1Value_);
                }
                if (arg1Value instanceof NativePointer) {
                    NativePointer arg1Value_ = (NativePointer) arg1Value;
                    state_0 = state_0 | 0b10 /* add SpecializationActive[MutableTruffleString.DataClassProfile.doNativePointer(NativePointer)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return DataClassProfile.doNativePointer(arg1Value_);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(DataClassProfile.class)
        @DenyReplace
        private static final class Uncached extends DataClassProfile {

            @TruffleBoundary
            @Override
            Object execute(Node arg0Value, Object arg1Value) {
                if (arg1Value instanceof byte[]) {
                    byte[] arg1Value_ = (byte[]) arg1Value;
                    return DataClassProfile.doByteArray(arg1Value_);
                }
                if (arg1Value instanceof NativePointer) {
                    NativePointer arg1Value_ = (NativePointer) arg1Value;
                    return DataClassProfile.doNativePointer(arg1Value_);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CalcLazyAttributesNode#calc}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(CalcLazyAttributesNode.class)
    @SuppressWarnings("javadoc")
    static final class CalcLazyAttributesNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static CalcLazyAttributesNode getUncached() {
            return CalcLazyAttributesNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * </ul>
         */
        @NeverDefault
        public static CalcLazyAttributesNode inline(@RequiredField(bits = 24, value = StateField.class) InlineTarget target) {
            return new CalcLazyAttributesNodeGen.Inlined(target);
        }

        @GeneratedBy(CalcLazyAttributesNode.class)
        @DenyReplace
        private static final class Inlined extends CalcLazyAttributesNode {

            /**
             * State Info: <pre>
             *   0-1: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link DataClassProfile} dataClassProfile
             *        Inline method: {@link DataClassProfileNodeGen#inline}
             *   2-3: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} asciiBytesLatinProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   4-5: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} utf8Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   6-7: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} utf8BrokenProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   8-9: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} utf16Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   10-11: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} utf16S0Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   12-13: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} utf32Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   14-15: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} utf32S0Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   16-17: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} utf32S1Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   18-19: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} exoticMaterializeNativeProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   20-21: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} exoticValidProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   22-23: InlinedCache
             *        Specialization: {@link CalcLazyAttributesNode#calc}
             *        Parameter: {@link InlinedConditionProfile} exoticFixedWidthProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link DataClassProfile} dataClassProfile
             *   Inline method: {@link DataClassProfileNodeGen#inline}</pre>
             */
            private final DataClassProfile dataClassProfile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} asciiBytesLatinProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile asciiBytesLatinProfile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} utf8Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf8Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} utf8BrokenProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf8BrokenProfile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} utf16Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf16Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} utf16S0Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf16S0Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} utf32Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf32Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} utf32S0Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf32S0Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} utf32S1Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf32S1Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} exoticMaterializeNativeProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile exoticMaterializeNativeProfile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} exoticValidProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile exoticValidProfile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link CalcLazyAttributesNode#calc}
             *   Parameter: {@link InlinedConditionProfile} exoticFixedWidthProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile exoticFixedWidthProfile_;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(CalcLazyAttributesNode.class);
                this.state_0_ = target.getState(0, 24);
                this.dataClassProfile_ = DataClassProfileNodeGen.inline(InlineTarget.create(DataClassProfile.class, state_0_.subUpdater(0, 2)));
                this.asciiBytesLatinProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(2, 2)));
                this.utf8Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(4, 2)));
                this.utf8BrokenProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(6, 2)));
                this.utf16Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(8, 2)));
                this.utf16S0Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(10, 2)));
                this.utf32Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(12, 2)));
                this.utf32S0Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(14, 2)));
                this.utf32S1Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(16, 2)));
                this.exoticMaterializeNativeProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(18, 2)));
                this.exoticValidProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(20, 2)));
                this.exoticFixedWidthProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(22, 2)));
            }

            @Override
            void execute(Node arg0Value, MutableTruffleString arg1Value) {
                assert InlineSupport.validate(arg0Value, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_);
                CalcLazyAttributesNode.calc(arg0Value, arg1Value, this.dataClassProfile_, this.asciiBytesLatinProfile_, this.utf8Profile_, this.utf8BrokenProfile_, this.utf16Profile_, this.utf16S0Profile_, this.utf32Profile_, this.utf32S0Profile_, this.utf32S1Profile_, this.exoticMaterializeNativeProfile_, this.exoticValidProfile_, this.exoticFixedWidthProfile_);
                return;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(CalcLazyAttributesNode.class)
        @DenyReplace
        private static final class Uncached extends CalcLazyAttributesNode {

            @TruffleBoundary
            @Override
            void execute(Node arg0Value, MutableTruffleString arg1Value) {
                CalcLazyAttributesNode.calc(arg0Value, arg1Value, (DataClassProfileNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()));
                return;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
}
