// CheckStyle: start generated
package com.oracle.truffle.api.strings;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.RequiredField;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.InlinedConditionProfile;
import com.oracle.truffle.api.strings.TStringOpsNodes.RawReadValueNode;
import com.oracle.truffle.api.strings.TStringOpsNodesFactory.RawReadValueNodeGen;
import com.oracle.truffle.api.strings.TruffleStringIterator.InternalNextNode;
import com.oracle.truffle.api.strings.TruffleStringIterator.InternalPreviousNode;
import com.oracle.truffle.api.strings.TruffleStringIterator.NextNode;
import com.oracle.truffle.api.strings.TruffleStringIterator.PreviousNode;
import java.lang.invoke.MethodHandles;

@GeneratedBy(TruffleStringIterator.class)
@SuppressWarnings("javadoc")
public final class TruffleStringIteratorFactory {

    /**
     * Debug Info: <pre>
     *   Specialization {@link InternalNextNode#fixed}
     *     Activation probability: 0.19111
     *     With/without class size: 7/0 bytes
     *   Specialization {@link InternalNextNode#fixedValid}
     *     Activation probability: 0.17111
     *     With/without class size: 6/0 bytes
     *   Specialization {@link InternalNextNode#brokenAscii}
     *     Activation probability: 0.15111
     *     With/without class size: 6/0 bytes
     *   Specialization {@link InternalNextNode#brokenUTF32}
     *     Activation probability: 0.13111
     *     With/without class size: 6/0 bytes
     *   Specialization {@link InternalNextNode#utf8Valid}
     *     Activation probability: 0.11111
     *     With/without class size: 5/0 bytes
     *   Specialization {@link InternalNextNode#utf8Broken}
     *     Activation probability: 0.09111
     *     With/without class size: 5/0 bytes
     *   Specialization {@link InternalNextNode#utf16Valid}
     *     Activation probability: 0.07111
     *     With/without class size: 4/0 bytes
     *   Specialization {@link InternalNextNode#utf16Broken}
     *     Activation probability: 0.05111
     *     With/without class size: 4/0 bytes
     *   Specialization {@link InternalNextNode#unsupported}
     *     Activation probability: 0.03111
     *     With/without class size: 4/0 bytes
     * </pre>
     */
    @GeneratedBy(InternalNextNode.class)
    @SuppressWarnings("javadoc")
    static final class InternalNextNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static InternalNextNode getUncached() {
            return InternalNextNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * </ul>
         */
        @NeverDefault
        public static InternalNextNode inline(@RequiredField(bits = 21, value = StateField.class) InlineTarget target) {
            return new InternalNextNodeGen.Inlined(target);
        }

        @GeneratedBy(InternalNextNode.class)
        @DenyReplace
        private static final class Inlined extends InternalNextNode {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link InternalNextNode#fixed}
             *   1: SpecializationActive {@link InternalNextNode#fixedValid}
             *   2: SpecializationActive {@link InternalNextNode#brokenAscii}
             *   3: SpecializationActive {@link InternalNextNode#brokenUTF32}
             *   4: SpecializationActive {@link InternalNextNode#utf8Valid}
             *   5: SpecializationActive {@link InternalNextNode#utf8Broken}
             *   6: SpecializationActive {@link InternalNextNode#utf16Valid}
             *   7: SpecializationActive {@link InternalNextNode#utf16Broken}
             *   8: SpecializationActive {@link InternalNextNode#unsupported}
             *   9-20: InlinedCache
             *        Specialization: {@link InternalNextNode#fixed}
             *        Parameter: {@link RawReadValueNode} readNode
             *        Inline method: {@link RawReadValueNodeGen#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalNextNode#fixed}
             *   Parameter: {@link RawReadValueNode} readNode
             *   Inline method: {@link RawReadValueNodeGen#inline}</pre>
             */
            private final RawReadValueNode readRaw;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(InternalNextNode.class);
                this.state_0_ = target.getState(0, 21);
                this.readRaw = RawReadValueNodeGen.inline(InlineTarget.create(RawReadValueNode.class, state_0_.subUpdater(9, 12)));
            }

            @Override
            int executeInternal(Node arg0Value, TruffleStringIterator arg1Value, DecodingErrorHandler arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((state_0 & 0b111111111) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.fixed(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] || SpecializationActive[TruffleStringIterator.InternalNextNode.fixedValid(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] || SpecializationActive[TruffleStringIterator.InternalNextNode.brokenAscii(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] || SpecializationActive[TruffleStringIterator.InternalNextNode.brokenUTF32(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] || SpecializationActive[TruffleStringIterator.InternalNextNode.utf8Valid(TruffleStringIterator, DecodingErrorHandler)] || SpecializationActive[TruffleStringIterator.InternalNextNode.utf8Broken(TruffleStringIterator, DecodingErrorHandler)] || SpecializationActive[TruffleStringIterator.InternalNextNode.utf16Valid(TruffleStringIterator, DecodingErrorHandler)] || SpecializationActive[TruffleStringIterator.InternalNextNode.utf16Broken(TruffleStringIterator, DecodingErrorHandler)] || SpecializationActive[TruffleStringIterator.InternalNextNode.unsupported(TruffleStringIterator, DecodingErrorHandler)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.fixed(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */) {
                        if ((TStringGuards.isUTF32(arg1Value.encoding) || TStringGuards.isFixedWidth(arg1Value.codeRangeA)) && (TStringGuards.isDefaultVariant(arg2Value))) {
                            return InternalNextNode.fixed(arg0Value, arg1Value, arg2Value, this.readRaw);
                        }
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.fixedValid(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */) {
                        if ((TStringGuards.isUpToValidFixedWidth(arg1Value.codeRangeA))) {
                            return InternalNextNode.fixedValid(arg0Value, arg1Value, arg2Value, this.readRaw);
                        }
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.brokenAscii(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */) {
                        if ((TStringGuards.isAscii(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                            return InternalNextNode.brokenAscii(arg0Value, arg1Value, arg2Value, this.readRaw);
                        }
                    }
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.brokenUTF32(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */) {
                        if ((TStringGuards.isUTF32(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                            return InternalNextNode.brokenUTF32(arg0Value, arg1Value, arg2Value, this.readRaw);
                        }
                    }
                    if ((state_0 & 0b10000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.utf8Valid(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                            return InternalNextNode.utf8Valid(arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b100000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.utf8Broken(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                            return InternalNextNode.utf8Broken(arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b1000000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.utf16Valid(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                            return InternalNextNode.utf16Valid(arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b10000000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.utf16Broken(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                            return InternalNextNode.utf16Broken(arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b100000000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalNextNode.unsupported(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUnsupportedEncoding(arg1Value.encoding))) {
                            return InternalNextNode.unsupported(arg1Value, arg2Value);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
            }

            private int executeAndSpecialize(Node arg0Value, TruffleStringIterator arg1Value, DecodingErrorHandler arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((TStringGuards.isUTF32(arg1Value.encoding) || TStringGuards.isFixedWidth(arg1Value.codeRangeA)) && (TStringGuards.isDefaultVariant(arg2Value))) {
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.fixed(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.fixed(arg0Value, arg1Value, arg2Value, this.readRaw);
                }
                if ((TStringGuards.isUpToValidFixedWidth(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.fixedValid(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.fixedValid(arg0Value, arg1Value, arg2Value, this.readRaw);
                }
                if ((TStringGuards.isAscii(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.brokenAscii(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.brokenAscii(arg0Value, arg1Value, arg2Value, this.readRaw);
                }
                if ((TStringGuards.isUTF32(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.brokenUTF32(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.brokenUTF32(arg0Value, arg1Value, arg2Value, this.readRaw);
                }
                if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b10000 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.utf8Valid(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.utf8Valid(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b100000 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.utf8Broken(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.utf8Broken(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b1000000 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.utf16Valid(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.utf16Valid(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b10000000 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.utf16Broken(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.utf16Broken(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUnsupportedEncoding(arg1Value.encoding))) {
                    state_0 = state_0 | 0b100000000 /* add SpecializationActive[TruffleStringIterator.InternalNextNode.unsupported(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalNextNode.unsupported(arg1Value, arg2Value);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(InternalNextNode.class)
        @DenyReplace
        private static final class Uncached extends InternalNextNode {

            @TruffleBoundary
            @Override
            int executeInternal(Node arg0Value, TruffleStringIterator arg1Value, DecodingErrorHandler arg2Value) {
                if ((TStringGuards.isUTF32(arg1Value.encoding) || TStringGuards.isFixedWidth(arg1Value.codeRangeA)) && (TStringGuards.isDefaultVariant(arg2Value))) {
                    return InternalNextNode.fixed(arg0Value, arg1Value, arg2Value, (RawReadValueNodeGen.getUncached()));
                }
                if ((TStringGuards.isUpToValidFixedWidth(arg1Value.codeRangeA))) {
                    return InternalNextNode.fixedValid(arg0Value, arg1Value, arg2Value, (RawReadValueNodeGen.getUncached()));
                }
                if ((TStringGuards.isAscii(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    return InternalNextNode.brokenAscii(arg0Value, arg1Value, arg2Value, (RawReadValueNodeGen.getUncached()));
                }
                if ((TStringGuards.isUTF32(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    return InternalNextNode.brokenUTF32(arg0Value, arg1Value, arg2Value, (RawReadValueNodeGen.getUncached()));
                }
                if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                    return InternalNextNode.utf8Valid(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                    return InternalNextNode.utf8Broken(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                    return InternalNextNode.utf16Valid(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                    return InternalNextNode.utf16Broken(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUnsupportedEncoding(arg1Value.encoding))) {
                    return InternalNextNode.unsupported(arg1Value, arg2Value);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link NextNode#doDefault}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(NextNode.class)
    @SuppressWarnings("javadoc")
    static final class NextNodeGen extends NextNode {

        private static final StateField STATE_0_NextNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link NextNode#doDefault}
         *   Parameter: {@link InternalNextNode} nextNode
         *   Inline method: {@link InternalNextNodeGen#inline}</pre>
         */
        private static final InternalNextNode INLINED_NEXT_NODE_ = InternalNextNodeGen.inline(InlineTarget.create(InternalNextNode.class, STATE_0_NextNode_UPDATER.subUpdater(0, 21)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link NextNode#doDefault}
         *   Parameter: {@link InlinedConditionProfile} errorHandlerProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_ERROR_HANDLER_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_NextNode_UPDATER.subUpdater(21, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link NextNode#doDefault}
         *        Parameter: {@link InternalNextNode} nextNode
         *        Inline method: {@link InternalNextNodeGen#inline}
         *   21-22: InlinedCache
         *        Specialization: {@link NextNode#doDefault}
         *        Parameter: {@link InlinedConditionProfile} errorHandlerProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private NextNodeGen() {
        }

        @Override
        public int execute(TruffleStringIterator arg0Value) {
            return doDefault(arg0Value, INLINED_NEXT_NODE_, INLINED_ERROR_HANDLER_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static NextNode create() {
            return new NextNodeGen();
        }

        @NeverDefault
        public static NextNode getUncached() {
            return NextNodeGen.UNCACHED;
        }

        @GeneratedBy(NextNode.class)
        @DenyReplace
        private static final class Uncached extends NextNode {

            @TruffleBoundary
            @Override
            public int execute(TruffleStringIterator arg0Value) {
                return doDefault(arg0Value, (InternalNextNodeGen.getUncached()), (InlinedConditionProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link PreviousNode#doDefault}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(PreviousNode.class)
    @SuppressWarnings("javadoc")
    static final class PreviousNodeGen extends PreviousNode {

        private static final StateField STATE_0_PreviousNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link PreviousNode#doDefault}
         *   Parameter: {@link InternalPreviousNode} previousNode
         *   Inline method: {@link InternalPreviousNodeGen#inline}</pre>
         */
        private static final InternalPreviousNode INLINED_PREVIOUS_NODE_ = InternalPreviousNodeGen.inline(InlineTarget.create(InternalPreviousNode.class, STATE_0_PreviousNode_UPDATER.subUpdater(0, 21)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link PreviousNode#doDefault}
         *   Parameter: {@link InlinedConditionProfile} errorHandlerProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_ERROR_HANDLER_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_PreviousNode_UPDATER.subUpdater(21, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link PreviousNode#doDefault}
         *        Parameter: {@link InternalPreviousNode} previousNode
         *        Inline method: {@link InternalPreviousNodeGen#inline}
         *   21-22: InlinedCache
         *        Specialization: {@link PreviousNode#doDefault}
         *        Parameter: {@link InlinedConditionProfile} errorHandlerProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private PreviousNodeGen() {
        }

        @Override
        public int execute(TruffleStringIterator arg0Value) {
            return doDefault(arg0Value, INLINED_PREVIOUS_NODE_, INLINED_ERROR_HANDLER_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static PreviousNode create() {
            return new PreviousNodeGen();
        }

        @NeverDefault
        public static PreviousNode getUncached() {
            return PreviousNodeGen.UNCACHED;
        }

        @GeneratedBy(PreviousNode.class)
        @DenyReplace
        private static final class Uncached extends PreviousNode {

            @TruffleBoundary
            @Override
            public int execute(TruffleStringIterator arg0Value) {
                return doDefault(arg0Value, (InternalPreviousNodeGen.getUncached()), (InlinedConditionProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link InternalPreviousNode#fixed}
     *     Activation probability: 0.19111
     *     With/without class size: 7/0 bytes
     *   Specialization {@link InternalPreviousNode#fixedValid}
     *     Activation probability: 0.17111
     *     With/without class size: 6/0 bytes
     *   Specialization {@link InternalPreviousNode#brokenAscii}
     *     Activation probability: 0.15111
     *     With/without class size: 6/0 bytes
     *   Specialization {@link InternalPreviousNode#brokenUTF32}
     *     Activation probability: 0.13111
     *     With/without class size: 6/0 bytes
     *   Specialization {@link InternalPreviousNode#utf8Valid}
     *     Activation probability: 0.11111
     *     With/without class size: 5/0 bytes
     *   Specialization {@link InternalPreviousNode#utf8Broken}
     *     Activation probability: 0.09111
     *     With/without class size: 5/0 bytes
     *   Specialization {@link InternalPreviousNode#utf16Valid}
     *     Activation probability: 0.07111
     *     With/without class size: 4/0 bytes
     *   Specialization {@link InternalPreviousNode#utf16Broken}
     *     Activation probability: 0.05111
     *     With/without class size: 4/0 bytes
     *   Specialization {@link InternalPreviousNode#unsupported}
     *     Activation probability: 0.03111
     *     With/without class size: 4/0 bytes
     * </pre>
     */
    @GeneratedBy(InternalPreviousNode.class)
    @SuppressWarnings("javadoc")
    static final class InternalPreviousNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static InternalPreviousNode getUncached() {
            return InternalPreviousNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * </ul>
         */
        @NeverDefault
        public static InternalPreviousNode inline(@RequiredField(bits = 21, value = StateField.class) InlineTarget target) {
            return new InternalPreviousNodeGen.Inlined(target);
        }

        @GeneratedBy(InternalPreviousNode.class)
        @DenyReplace
        private static final class Inlined extends InternalPreviousNode {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link InternalPreviousNode#fixed}
             *   1: SpecializationActive {@link InternalPreviousNode#fixedValid}
             *   2: SpecializationActive {@link InternalPreviousNode#brokenAscii}
             *   3: SpecializationActive {@link InternalPreviousNode#brokenUTF32}
             *   4: SpecializationActive {@link InternalPreviousNode#utf8Valid}
             *   5: SpecializationActive {@link InternalPreviousNode#utf8Broken}
             *   6: SpecializationActive {@link InternalPreviousNode#utf16Valid}
             *   7: SpecializationActive {@link InternalPreviousNode#utf16Broken}
             *   8: SpecializationActive {@link InternalPreviousNode#unsupported}
             *   9-20: InlinedCache
             *        Specialization: {@link InternalPreviousNode#fixed}
             *        Parameter: {@link RawReadValueNode} readNode
             *        Inline method: {@link RawReadValueNodeGen#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalPreviousNode#fixed}
             *   Parameter: {@link RawReadValueNode} readNode
             *   Inline method: {@link RawReadValueNodeGen#inline}</pre>
             */
            private final RawReadValueNode readRaw;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(InternalPreviousNode.class);
                this.state_0_ = target.getState(0, 21);
                this.readRaw = RawReadValueNodeGen.inline(InlineTarget.create(RawReadValueNode.class, state_0_.subUpdater(9, 12)));
            }

            @Override
            int executeInternal(Node arg0Value, TruffleStringIterator arg1Value, DecodingErrorHandler arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((state_0 & 0b111111111) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.fixed(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] || SpecializationActive[TruffleStringIterator.InternalPreviousNode.fixedValid(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] || SpecializationActive[TruffleStringIterator.InternalPreviousNode.brokenAscii(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] || SpecializationActive[TruffleStringIterator.InternalPreviousNode.brokenUTF32(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] || SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf8Valid(TruffleStringIterator, DecodingErrorHandler)] || SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf8Broken(TruffleStringIterator, DecodingErrorHandler)] || SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf16Valid(TruffleStringIterator, DecodingErrorHandler)] || SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf16Broken(TruffleStringIterator, DecodingErrorHandler)] || SpecializationActive[TruffleStringIterator.InternalPreviousNode.unsupported(TruffleStringIterator, DecodingErrorHandler)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.fixed(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */) {
                        if ((TStringGuards.isFixedWidth(arg1Value.codeRangeA)) && (TStringGuards.isDefaultVariant(arg2Value))) {
                            return InternalPreviousNode.fixed(arg0Value, arg1Value, arg2Value, this.readRaw);
                        }
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.fixedValid(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */) {
                        if ((TStringGuards.isUpToValidFixedWidth(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                            return InternalPreviousNode.fixedValid(arg0Value, arg1Value, arg2Value, this.readRaw);
                        }
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.brokenAscii(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */) {
                        if ((TStringGuards.isAscii(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                            return InternalPreviousNode.brokenAscii(arg0Value, arg1Value, arg2Value, this.readRaw);
                        }
                    }
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.brokenUTF32(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */) {
                        if ((TStringGuards.isUTF32(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                            return InternalPreviousNode.brokenUTF32(arg0Value, arg1Value, arg2Value, this.readRaw);
                        }
                    }
                    if ((state_0 & 0b10000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf8Valid(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                            return InternalPreviousNode.utf8Valid(arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b100000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf8Broken(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                            return InternalPreviousNode.utf8Broken(arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b1000000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf16Valid(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                            return InternalPreviousNode.utf16Valid(arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b10000000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf16Broken(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                            return InternalPreviousNode.utf16Broken(arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b100000000) != 0 /* is SpecializationActive[TruffleStringIterator.InternalPreviousNode.unsupported(TruffleStringIterator, DecodingErrorHandler)] */) {
                        if ((TStringGuards.isUnsupportedEncoding(arg1Value.encoding))) {
                            return InternalPreviousNode.unsupported(arg1Value, arg2Value);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
            }

            private int executeAndSpecialize(Node arg0Value, TruffleStringIterator arg1Value, DecodingErrorHandler arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((TStringGuards.isFixedWidth(arg1Value.codeRangeA)) && (TStringGuards.isDefaultVariant(arg2Value))) {
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.fixed(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.fixed(arg0Value, arg1Value, arg2Value, this.readRaw);
                }
                if ((TStringGuards.isUpToValidFixedWidth(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.fixedValid(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.fixedValid(arg0Value, arg1Value, arg2Value, this.readRaw);
                }
                if ((TStringGuards.isAscii(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.brokenAscii(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.brokenAscii(arg0Value, arg1Value, arg2Value, this.readRaw);
                }
                if ((TStringGuards.isUTF32(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.brokenUTF32(Node, TruffleStringIterator, DecodingErrorHandler, RawReadValueNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.brokenUTF32(arg0Value, arg1Value, arg2Value, this.readRaw);
                }
                if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b10000 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf8Valid(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.utf8Valid(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b100000 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf8Broken(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.utf8Broken(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b1000000 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf16Valid(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.utf16Valid(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                    state_0 = state_0 | 0b10000000 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.utf16Broken(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.utf16Broken(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUnsupportedEncoding(arg1Value.encoding))) {
                    state_0 = state_0 | 0b100000000 /* add SpecializationActive[TruffleStringIterator.InternalPreviousNode.unsupported(TruffleStringIterator, DecodingErrorHandler)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalPreviousNode.unsupported(arg1Value, arg2Value);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(InternalPreviousNode.class)
        @DenyReplace
        private static final class Uncached extends InternalPreviousNode {

            @TruffleBoundary
            @Override
            int executeInternal(Node arg0Value, TruffleStringIterator arg1Value, DecodingErrorHandler arg2Value) {
                if ((TStringGuards.isFixedWidth(arg1Value.codeRangeA)) && (TStringGuards.isDefaultVariant(arg2Value))) {
                    return InternalPreviousNode.fixed(arg0Value, arg1Value, arg2Value, (RawReadValueNodeGen.getUncached()));
                }
                if ((TStringGuards.isUpToValidFixedWidth(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    return InternalPreviousNode.fixedValid(arg0Value, arg1Value, arg2Value, (RawReadValueNodeGen.getUncached()));
                }
                if ((TStringGuards.isAscii(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    return InternalPreviousNode.brokenAscii(arg0Value, arg1Value, arg2Value, (RawReadValueNodeGen.getUncached()));
                }
                if ((TStringGuards.isUTF32(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA)) && (!(TStringGuards.isDefaultVariant(arg2Value)))) {
                    return InternalPreviousNode.brokenUTF32(arg0Value, arg1Value, arg2Value, (RawReadValueNodeGen.getUncached()));
                }
                if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                    return InternalPreviousNode.utf8Valid(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF8(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                    return InternalPreviousNode.utf8Broken(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isValid(arg1Value.codeRangeA))) {
                    return InternalPreviousNode.utf16Valid(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUTF16(arg1Value.encoding)) && (TStringGuards.isBroken(arg1Value.codeRangeA))) {
                    return InternalPreviousNode.utf16Broken(arg1Value, arg2Value);
                }
                if ((TStringGuards.isUnsupportedEncoding(arg1Value.encoding))) {
                    return InternalPreviousNode.unsupported(arg1Value, arg2Value);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
}
