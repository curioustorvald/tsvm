// CheckStyle: start generated
package com.oracle.truffle.api.strings;

import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.InlinedBranchProfile;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.AnyMatch;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.IndexOfAnyRangeNode;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.IndexOfAnyValueNode;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.IndexOfBitSetNode;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.IndexOfNode;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.IndexOfRangesNode;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.IndexOfStringNode;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.IndexOfTableNode;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.NoMatch;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.OptimizedIndexOfNode;
import com.oracle.truffle.api.strings.IndexOfCodePointSet.ScalarIndexOfNode;
import com.oracle.truffle.api.strings.TruffleString.Encoding;
import java.lang.invoke.MethodHandles;

@GeneratedBy(IndexOfCodePointSet.class)
@SuppressWarnings("javadoc")
final class IndexOfCodePointSetFactory {

    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfNodeGen extends IndexOfNode {

        private static final StateField STATE_0_IndexOfNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_IndexOfNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IndexOfNodeGen(int maxCodeRange) {
            super(maxCodeRange);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfNode create(int maxCodeRange) {
            return new IndexOfNodeGen(maxCodeRange);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(OptimizedIndexOfNode.class)
    @SuppressWarnings("javadoc")
    static final class OptimizedIndexOfNodeGen extends OptimizedIndexOfNode {

        private static final StateField STATE_0_OptimizedIndexOfNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_OptimizedIndexOfNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private OptimizedIndexOfNodeGen(int maxCodeRange) {
            super(maxCodeRange);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static OptimizedIndexOfNode create(int maxCodeRange) {
            return new OptimizedIndexOfNodeGen(maxCodeRange);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(ScalarIndexOfNode.class)
    @SuppressWarnings("javadoc")
    static final class ScalarIndexOfNodeGen extends ScalarIndexOfNode {

        private static final StateField STATE_0_ScalarIndexOfNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_ScalarIndexOfNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private ScalarIndexOfNodeGen(int maxCodeRange) {
            super(maxCodeRange);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static ScalarIndexOfNode create(int maxCodeRange) {
            return new ScalarIndexOfNodeGen(maxCodeRange);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(NoMatch.class)
    @SuppressWarnings("javadoc")
    static final class NoMatchNodeGen extends NoMatch {

        private static final StateField STATE_0_NoMatch_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_NoMatch_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private NoMatchNodeGen(int maxCodeRange) {
            super(maxCodeRange);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static NoMatch create(int maxCodeRange) {
            return new NoMatchNodeGen(maxCodeRange);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(AnyMatch.class)
    @SuppressWarnings("javadoc")
    static final class AnyMatchNodeGen extends AnyMatch {

        private static final StateField STATE_0_AnyMatch_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AnyMatch_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AnyMatchNodeGen(int maxCodeRange) {
            super(maxCodeRange);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static AnyMatch create(int maxCodeRange) {
            return new AnyMatchNodeGen(maxCodeRange);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfAnyValueNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfAnyValueNodeGen extends IndexOfAnyValueNode {

        private static final StateField STATE_0_IndexOfAnyValueNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_IndexOfAnyValueNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IndexOfAnyValueNodeGen(int maxCodeRange, int[] values) {
            super(maxCodeRange, values);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfAnyValueNode create(int maxCodeRange, int[] values) {
            return new IndexOfAnyValueNodeGen(maxCodeRange, values);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfAnyRangeNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfAnyRangeNodeGen extends IndexOfAnyRangeNode {

        private static final StateField STATE_0_IndexOfAnyRangeNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_IndexOfAnyRangeNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IndexOfAnyRangeNodeGen(int maxCodeRange, int[] ranges) {
            super(maxCodeRange, ranges);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfAnyRangeNode create(int maxCodeRange, int[] ranges) {
            return new IndexOfAnyRangeNodeGen(maxCodeRange, ranges);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfTableNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfTableNodeGen extends IndexOfTableNode {

        private static final StateField STATE_0_IndexOfTableNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_IndexOfTableNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IndexOfTableNodeGen(int maxCodeRange, byte[] tables) {
            super(maxCodeRange, tables);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfTableNode create(int maxCodeRange, byte[] tables) {
            return new IndexOfTableNodeGen(maxCodeRange, tables);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfStringNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfStringNodeGen extends IndexOfStringNode {

        private static final StateField STATE_0_IndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_IndexOfStringNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IndexOfStringNodeGen(int maxCodeRange, TruffleString string) {
            super(maxCodeRange, string);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfStringNode create(int maxCodeRange, TruffleString string) {
            return new IndexOfStringNodeGen(maxCodeRange, string);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfBitSetNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfBitSetNodeGen extends IndexOfBitSetNode {

        private static final StateField STATE_0_IndexOfBitSetNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_IndexOfBitSetNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IndexOfBitSetNodeGen(int maxCodeRange, long[] bitSet) {
            super(maxCodeRange, bitSet);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfBitSetNode create(int maxCodeRange, long[] bitSet) {
            return new IndexOfBitSetNodeGen(maxCodeRange, bitSet);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfNode#doWithConditionProfile}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfRangesNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfRangesNodeGen extends IndexOfRangesNode {

        private static final StateField STATE_0_IndexOfRangesNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfNode#doWithConditionProfile}
         *   Parameter: {@link InlinedBranchProfile} branchProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BRANCH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_IndexOfRangesNode_UPDATER.subUpdater(0, 1)));

        /**
         * State Info: <pre>
         *   0: InlinedCache
         *        Specialization: {@link IndexOfNode#doWithConditionProfile}
         *        Parameter: {@link InlinedBranchProfile} branchProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IndexOfRangesNodeGen(int maxCodeRange, int[] ranges) {
            super(maxCodeRange, ranges);
        }

        @Override
        int execute(Node arg0Value, Object arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, int arg6Value, int arg7Value, Encoding arg8Value) {
            return doWithConditionProfile(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, arg7Value, arg8Value, INLINED_BRANCH_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfRangesNode create(int maxCodeRange, int[] ranges) {
            return new IndexOfRangesNodeGen(maxCodeRange, ranges);
        }

    }
}
