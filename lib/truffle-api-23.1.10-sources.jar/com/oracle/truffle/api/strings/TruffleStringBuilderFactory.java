// CheckStyle: start generated
package com.oracle.truffle.api.strings;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.InlineSupport;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.RequiredField;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.InlinedBranchProfile;
import com.oracle.truffle.api.profiles.InlinedConditionProfile;
import com.oracle.truffle.api.strings.TStringInternalNodes.CalcStringAttributesNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.GetCodePointLengthNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.GetPreciseCodeRangeNode;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.CalcStringAttributesNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.GetCodePointLengthNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.GetPreciseCodeRangeNodeGen;
import com.oracle.truffle.api.strings.TruffleString.ToIndexableNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendByteNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendCharUTF16Node;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendCodePointIntlNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendCodePointNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendIntNumberNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendJavaStringUTF16Node;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendLongNumberNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendStringIntlNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendStringNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.AppendSubstringByteIndexNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.ToStringIntlNode;
import com.oracle.truffle.api.strings.TruffleStringBuilder.ToStringNode;
import com.oracle.truffle.api.strings.TruffleStringFactory.ToIndexableNodeGen;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.lang.invoke.MethodHandles.Lookup;

@GeneratedBy(TruffleStringBuilder.class)
@SuppressWarnings("javadoc")
public final class TruffleStringBuilderFactory {

    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendByteNode#append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.65000
     *     With/without class size: 14/0 bytes
     *   Specialization {@link AppendByteNode#append(TruffleStringBuilderGeneric, byte, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.35000
     *     With/without class size: 9/0 bytes
     * </pre>
     */
    @GeneratedBy(AppendByteNode.class)
    @SuppressWarnings("javadoc")
    static final class AppendByteNodeGen extends AppendByteNode {

        private static final StateField STATE_0_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendByteNode#append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BUFFER_GROW_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(2, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendByteNode#append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} errorProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_ERROR_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(3, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AppendByteNode#append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)}
         *   1: SpecializationActive {@link AppendByteNode#append(TruffleStringBuilderGeneric, byte, InlinedBranchProfile, InlinedBranchProfile)}
         *   2: InlinedCache
         *        Specialization: {@link AppendByteNode#append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   3: InlinedCache
         *        Specialization: {@link AppendByteNode#append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} errorProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AppendByteNodeGen() {
        }

        @Override
        public void execute(TruffleStringBuilder arg0Value, byte arg1Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendByteNode.append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendByteNode.append(TruffleStringBuilderGeneric, byte, InlinedBranchProfile, InlinedBranchProfile)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendByteNode.append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                    append(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendByteNode.append(TruffleStringBuilderGeneric, byte, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    append(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            executeAndSpecialize(arg0Value, arg1Value);
            return;
        }

        private void executeAndSpecialize(TruffleStringBuilder arg0Value, byte arg1Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof TruffleStringBuilderUTF8) {
                TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.AppendByteNode.append(TruffleStringBuilderUTF8, byte, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                append(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderGeneric) {
                TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringBuilder.AppendByteNode.append(TruffleStringBuilderGeneric, byte, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                append(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if (((state_0 & 0b11) & ((state_0 & 0b11) - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static AppendByteNode create() {
            return new AppendByteNodeGen();
        }

        @NeverDefault
        public static AppendByteNode getUncached() {
            return AppendByteNodeGen.UNCACHED;
        }

        @GeneratedBy(AppendByteNode.class)
        @DenyReplace
        private static final class Uncached extends AppendByteNode {

            @TruffleBoundary
            @Override
            public void execute(TruffleStringBuilder arg0Value, byte arg1Value) {
                if (arg0Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                    append(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    append(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendCharUTF16Node#append}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(AppendCharUTF16Node.class)
    @SuppressWarnings("javadoc")
    static final class AppendCharUTF16NodeGen extends AppendCharUTF16Node {

        private static final StateField STATE_0_AppendCharUTF16Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendCharUTF16Node#append}
         *   Parameter: {@link InlinedBranchProfile} nonAsciiProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_NON_ASCII_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendCharUTF16Node_UPDATER.subUpdater(1, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendCharUTF16Node#append}
         *   Parameter: {@link InlinedBranchProfile} inflateProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_INFLATE_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendCharUTF16Node_UPDATER.subUpdater(2, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendCharUTF16Node#append}
         *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BUFFER_GROW_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendCharUTF16Node_UPDATER.subUpdater(3, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendCharUTF16Node#append}
         *   Parameter: {@link InlinedBranchProfile} errorProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_ERROR_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendCharUTF16Node_UPDATER.subUpdater(4, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AppendCharUTF16Node#append}
         *   1: InlinedCache
         *        Specialization: {@link AppendCharUTF16Node#append}
         *        Parameter: {@link InlinedBranchProfile} nonAsciiProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   2: InlinedCache
         *        Specialization: {@link AppendCharUTF16Node#append}
         *        Parameter: {@link InlinedBranchProfile} inflateProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   3: InlinedCache
         *        Specialization: {@link AppendCharUTF16Node#append}
         *        Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   4: InlinedCache
         *        Specialization: {@link AppendCharUTF16Node#append}
         *        Parameter: {@link InlinedBranchProfile} errorProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AppendCharUTF16NodeGen() {
        }

        @Override
        public void execute(TruffleStringBuilder arg0Value, char arg1Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendCharUTF16Node.append(TruffleStringBuilderUTF16, char, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF16) {
                TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                append(arg0Value_, arg1Value, INLINED_NON_ASCII_PROFILE_, INLINED_INFLATE_PROFILE_, INLINED_BUFFER_GROW_PROFILE_, INLINED_ERROR_PROFILE_);
                return;
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            executeAndSpecialize(arg0Value, arg1Value);
            return;
        }

        private void executeAndSpecialize(TruffleStringBuilder arg0Value, char arg1Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof TruffleStringBuilderUTF16) {
                TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.AppendCharUTF16Node.append(TruffleStringBuilderUTF16, char, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                append(arg0Value_, arg1Value, INLINED_NON_ASCII_PROFILE_, INLINED_INFLATE_PROFILE_, INLINED_BUFFER_GROW_PROFILE_, INLINED_ERROR_PROFILE_);
                return;
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static AppendCharUTF16Node create() {
            return new AppendCharUTF16NodeGen();
        }

        @NeverDefault
        public static AppendCharUTF16Node getUncached() {
            return AppendCharUTF16NodeGen.UNCACHED;
        }

        @GeneratedBy(AppendCharUTF16Node.class)
        @DenyReplace
        private static final class Uncached extends AppendCharUTF16Node {

            @TruffleBoundary
            @Override
            public void execute(TruffleStringBuilder arg0Value, char arg1Value) {
                if (arg0Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                    append(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendCodePointNode#append}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(AppendCodePointNode.class)
    @SuppressWarnings("javadoc")
    static final class AppendCodePointNodeGen extends AppendCodePointNode {

        private static final StateField STATE_0_AppendCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendCodePointNode#append}
         *   Parameter: {@link AppendCodePointIntlNode} appendCodePointIntlNode
         *   Inline method: {@link AppendCodePointIntlNodeGen#inline}</pre>
         */
        private static final AppendCodePointIntlNode INLINED_APPEND_CODE_POINT_INTL_NODE_ = AppendCodePointIntlNodeGen.inline(InlineTarget.create(AppendCodePointIntlNode.class, STATE_0_AppendCodePointNode_UPDATER.subUpdater(0, 11)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-10: InlinedCache
         *        Specialization: {@link AppendCodePointNode#append}
         *        Parameter: {@link AppendCodePointIntlNode} appendCodePointIntlNode
         *        Inline method: {@link AppendCodePointIntlNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AppendCodePointNodeGen() {
        }

        @Override
        public void execute(TruffleStringBuilder arg0Value, int arg1Value, int arg2Value, boolean arg3Value) {
            append(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_APPEND_CODE_POINT_INTL_NODE_);
            return;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static AppendCodePointNode create() {
            return new AppendCodePointNodeGen();
        }

        @NeverDefault
        public static AppendCodePointNode getUncached() {
            return AppendCodePointNodeGen.UNCACHED;
        }

        @GeneratedBy(AppendCodePointNode.class)
        @DenyReplace
        private static final class Uncached extends AppendCodePointNode {

            @TruffleBoundary
            @Override
            public void execute(TruffleStringBuilder arg0Value, int arg1Value, int arg2Value, boolean arg3Value) {
                append(arg0Value, arg1Value, arg2Value, arg3Value, (AppendCodePointIntlNodeGen.getUncached()));
                return;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.38500
     *     With/without class size: 10/0 bytes
     *   Specialization {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.29500
     *     With/without class size: 8/0 bytes
     *   Specialization {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF32, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.20500
     *     With/without class size: 7/0 bytes
     *   Specialization {@link AppendCodePointIntlNode#generic}
     *     Activation probability: 0.11500
     *     With/without class size: 6/1 bytes
     * </pre>
     */
    @GeneratedBy(AppendCodePointIntlNode.class)
    @SuppressWarnings("javadoc")
    static final class AppendCodePointIntlNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static AppendCodePointIntlNode getUncached() {
            return AppendCodePointIntlNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * </ul>
         */
        @NeverDefault
        public static AppendCodePointIntlNode inline(@RequiredField(bits = 11, value = StateField.class) InlineTarget target) {
            return new AppendCodePointIntlNodeGen.Inlined(target);
        }

        @GeneratedBy(AppendCodePointIntlNode.class)
        @DenyReplace
        private static final class Inlined extends AppendCodePointIntlNode {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   1: SpecializationActive {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   2: SpecializationActive {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF32, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   3: SpecializationActive {@link AppendCodePointIntlNode#generic}
             *   4: InlinedCache
             *        Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} multiByteProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   5: InlinedCache
             *        Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} bufferGrowProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   6: InlinedCache
             *        Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} errorProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   7: InlinedCache
             *        Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} nonAsciiProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   8: InlinedCache
             *        Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} inflateProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   9-10: InlinedCache
             *        Specialization: {@link AppendCodePointIntlNode#generic}
             *        Parameter: {@link InlinedConditionProfile} supportedProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} multiByteProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile multiByteProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile bufferGrowProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} errorProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile errorProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} nonAsciiProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile nonAsciiProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendCodePointIntlNode#append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} inflateProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile inflateProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendCodePointIntlNode#generic}
             *   Parameter: {@link InlinedConditionProfile} supportedProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile generic_supportedProfile_;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(AppendCodePointIntlNode.class);
                this.state_0_ = target.getState(0, 11);
                this.multiByteProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(4, 1)));
                this.bufferGrowProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(5, 1)));
                this.errorProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(6, 1)));
                this.nonAsciiProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(7, 1)));
                this.inflateProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(8, 1)));
                this.generic_supportedProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(9, 2)));
            }

            @Override
            void execute(Node arg0Value, TruffleStringBuilder arg1Value, int arg2Value, int arg3Value, boolean arg4Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((state_0 & 0b1111) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF32, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.generic(Node, TruffleStringBuilderGeneric, int, int, boolean, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg1Value instanceof TruffleStringBuilderUTF8) {
                        TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                        AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, this.multiByteProfile, this.bufferGrowProfile, this.errorProfile);
                        return;
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg1Value instanceof TruffleStringBuilderUTF16) {
                        TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                        AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, this.nonAsciiProfile, this.multiByteProfile, this.inflateProfile, this.bufferGrowProfile, this.errorProfile);
                        return;
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF32, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg1Value instanceof TruffleStringBuilderUTF32) {
                        TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                        AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, this.nonAsciiProfile, this.inflateProfile, this.bufferGrowProfile, this.errorProfile);
                        return;
                    }
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.generic(Node, TruffleStringBuilderGeneric, int, int, boolean, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg1Value instanceof TruffleStringBuilderGeneric) {
                        TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                        assert InlineSupport.validate(arg0Value, this.state_0_);
                        AppendCodePointIntlNode.generic(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, this.generic_supportedProfile_, this.bufferGrowProfile, this.errorProfile);
                        return;
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
                return;
            }

            private void executeAndSpecialize(Node arg0Value, TruffleStringBuilder arg1Value, int arg2Value, int arg3Value, boolean arg4Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if (arg1Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF8, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, this.multiByteProfile, this.bufferGrowProfile, this.errorProfile);
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF16, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, this.nonAsciiProfile, this.multiByteProfile, this.inflateProfile, this.bufferGrowProfile, this.errorProfile);
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                    state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.append(Node, TruffleStringBuilderUTF32, int, int, boolean, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, this.nonAsciiProfile, this.inflateProfile, this.bufferGrowProfile, this.errorProfile);
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                    state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleStringBuilder.AppendCodePointIntlNode.generic(Node, TruffleStringBuilderGeneric, int, int, boolean, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    assert InlineSupport.validate(arg0Value, this.state_0_);
                    AppendCodePointIntlNode.generic(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, this.generic_supportedProfile_, this.bufferGrowProfile, this.errorProfile);
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(AppendCodePointIntlNode.class)
        @DenyReplace
        private static final class Uncached extends AppendCodePointIntlNode {

            @TruffleBoundary
            @Override
            void execute(Node arg0Value, TruffleStringBuilder arg1Value, int arg2Value, int arg3Value, boolean arg4Value) {
                if (arg1Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                    AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                    AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                    AppendCodePointIntlNode.append(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                    AppendCodePointIntlNode.generic(arg0Value, arg1Value_, arg2Value, arg3Value, arg4Value, (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.38500
     *     With/without class size: 10/0 bytes
     *   Specialization {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF16, int, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.29500
     *     With/without class size: 8/0 bytes
     *   Specialization {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF32, int, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.20500
     *     With/without class size: 8/1 bytes
     *   Specialization {@link AppendIntNumberNode#doAppend(TruffleStringBuilderGeneric, int, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.11500
     *     With/without class size: 5/0 bytes
     * </pre>
     */
    @GeneratedBy(AppendIntNumberNode.class)
    @SuppressWarnings("javadoc")
    static final class AppendIntNumberNodeGen extends AppendIntNumberNode {

        private static final StateField STATE_0_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_0_AppendIntNumberNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BUFFER_GROW_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(4, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} errorProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_ERROR_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(5, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF16, int, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedConditionProfile} stride0Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_STRIDE0_PROFILE = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_UPDATER.subUpdater(6, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF32, int, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedConditionProfile} stride1Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_APPEND2_STRIDE1_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_AppendIntNumberNode_UPDATER.subUpdater(8, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)}
         *   1: SpecializationActive {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF16, int, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   2: SpecializationActive {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF32, int, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   3: SpecializationActive {@link AppendIntNumberNode#doAppend(TruffleStringBuilderGeneric, int, InlinedBranchProfile, InlinedBranchProfile)}
         *   4: InlinedCache
         *        Specialization: {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   5: InlinedCache
         *        Specialization: {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} errorProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   6-7: InlinedCache
         *        Specialization: {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF16, int, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedConditionProfile} stride0Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   8-9: InlinedCache
         *        Specialization: {@link AppendIntNumberNode#doAppend(TruffleStringBuilderUTF32, int, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedConditionProfile} stride1Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AppendIntNumberNodeGen() {
        }

        @Override
        public void execute(TruffleStringBuilder arg0Value, int arg1Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1111) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF16, int, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF32, int, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderGeneric, int, InlinedBranchProfile, InlinedBranchProfile)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                    doAppend(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF16, int, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                    doAppend(arg0Value_, arg1Value, INLINED_STRIDE0_PROFILE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF32, int, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                    doAppend(arg0Value_, arg1Value, INLINED_STRIDE0_PROFILE, INLINED_APPEND2_STRIDE1_PROFILE_, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderGeneric, int, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    doAppend(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            executeAndSpecialize(arg0Value, arg1Value);
            return;
        }

        private void executeAndSpecialize(TruffleStringBuilder arg0Value, int arg1Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof TruffleStringBuilderUTF8) {
                TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF8, int, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                doAppend(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderUTF16) {
                TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF16, int, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                doAppend(arg0Value_, arg1Value, INLINED_STRIDE0_PROFILE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderUTF32) {
                TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderUTF32, int, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                doAppend(arg0Value_, arg1Value, INLINED_STRIDE0_PROFILE, INLINED_APPEND2_STRIDE1_PROFILE_, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderGeneric) {
                TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleStringBuilder.AppendIntNumberNode.doAppend(TruffleStringBuilderGeneric, int, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                doAppend(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1111) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if (((state_0 & 0b1111) & ((state_0 & 0b1111) - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static AppendIntNumberNode create() {
            return new AppendIntNumberNodeGen();
        }

        @NeverDefault
        public static AppendIntNumberNode getUncached() {
            return AppendIntNumberNodeGen.UNCACHED;
        }

        @GeneratedBy(AppendIntNumberNode.class)
        @DenyReplace
        private static final class Uncached extends AppendIntNumberNode {

            @TruffleBoundary
            @Override
            public void execute(TruffleStringBuilder arg0Value, int arg1Value) {
                if (arg0Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                    doAppend(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                    doAppend(arg0Value_, arg1Value, (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                    doAppend(arg0Value_, arg1Value, (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    doAppend(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.38500
     *     With/without class size: 10/0 bytes
     *   Specialization {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF16, long, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.29500
     *     With/without class size: 8/0 bytes
     *   Specialization {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF32, long, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.20500
     *     With/without class size: 8/1 bytes
     *   Specialization {@link AppendLongNumberNode#doAppend(TruffleStringBuilderGeneric, long, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.11500
     *     With/without class size: 5/0 bytes
     * </pre>
     */
    @GeneratedBy(AppendLongNumberNode.class)
    @SuppressWarnings("javadoc")
    static final class AppendLongNumberNodeGen extends AppendLongNumberNode {

        private static final StateField STATE_0_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_0_AppendLongNumberNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BUFFER_GROW_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(4, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} errorProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_ERROR_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(5, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF16, long, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedConditionProfile} stride0Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_STRIDE0_PROFILE = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_UPDATER.subUpdater(6, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF32, long, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedConditionProfile} stride1Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_APPEND2_STRIDE1_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_AppendLongNumberNode_UPDATER.subUpdater(8, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)}
         *   1: SpecializationActive {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF16, long, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   2: SpecializationActive {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF32, long, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   3: SpecializationActive {@link AppendLongNumberNode#doAppend(TruffleStringBuilderGeneric, long, InlinedBranchProfile, InlinedBranchProfile)}
         *   4: InlinedCache
         *        Specialization: {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   5: InlinedCache
         *        Specialization: {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} errorProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   6-7: InlinedCache
         *        Specialization: {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF16, long, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedConditionProfile} stride0Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   8-9: InlinedCache
         *        Specialization: {@link AppendLongNumberNode#doAppend(TruffleStringBuilderUTF32, long, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedConditionProfile} stride1Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AppendLongNumberNodeGen() {
        }

        @Override
        public void execute(TruffleStringBuilder arg0Value, long arg1Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1111) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF16, long, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF32, long, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderGeneric, long, InlinedBranchProfile, InlinedBranchProfile)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                    doAppend(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF16, long, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                    doAppend(arg0Value_, arg1Value, INLINED_STRIDE0_PROFILE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF32, long, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                    doAppend(arg0Value_, arg1Value, INLINED_STRIDE0_PROFILE, INLINED_APPEND2_STRIDE1_PROFILE_, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderGeneric, long, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    doAppend(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            executeAndSpecialize(arg0Value, arg1Value);
            return;
        }

        private void executeAndSpecialize(TruffleStringBuilder arg0Value, long arg1Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof TruffleStringBuilderUTF8) {
                TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF8, long, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                doAppend(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderUTF16) {
                TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF16, long, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                doAppend(arg0Value_, arg1Value, INLINED_STRIDE0_PROFILE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderUTF32) {
                TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderUTF32, long, InlinedConditionProfile, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                doAppend(arg0Value_, arg1Value, INLINED_STRIDE0_PROFILE, INLINED_APPEND2_STRIDE1_PROFILE_, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderGeneric) {
                TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleStringBuilder.AppendLongNumberNode.doAppend(TruffleStringBuilderGeneric, long, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                doAppend(arg0Value_, arg1Value, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1111) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if (((state_0 & 0b1111) & ((state_0 & 0b1111) - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static AppendLongNumberNode create() {
            return new AppendLongNumberNodeGen();
        }

        @NeverDefault
        public static AppendLongNumberNode getUncached() {
            return AppendLongNumberNodeGen.UNCACHED;
        }

        @GeneratedBy(AppendLongNumberNode.class)
        @DenyReplace
        private static final class Uncached extends AppendLongNumberNode {

            @TruffleBoundary
            @Override
            public void execute(TruffleStringBuilder arg0Value, long arg1Value) {
                if (arg0Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                    doAppend(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                    doAppend(arg0Value_, arg1Value, (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                    doAppend(arg0Value_, arg1Value, (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    doAppend(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendStringNode#append}
     *     Activation probability: 1.00000
     *     With/without class size: 36/16 bytes
     * </pre>
     */
    @GeneratedBy(AppendStringNode.class)
    @SuppressWarnings("javadoc")
    static final class AppendStringNodeGen extends AppendStringNode {

        private static final StateField STATE_0_AppendStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_AppendStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_AppendStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_AppendStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendStringNode#append}
         *   Parameter: {@link AppendStringIntlNode} intlNode
         *   Inline method: {@link AppendStringIntlNodeGen#inline}</pre>
         */
        private static final AppendStringIntlNode INLINED_INTL_NODE_ = AppendStringIntlNodeGen.inline(InlineTarget.create(AppendStringIntlNode.class, STATE_0_AppendStringNode_UPDATER.subUpdater(0, 15), STATE_1_AppendStringNode_UPDATER.subUpdater(0, 25), STATE_2_AppendStringNode_UPDATER.subUpdater(0, 25), STATE_3_AppendStringNode_UPDATER.subUpdater(0, 25), ReferenceField.create(MethodHandles.lookup(), "intlNode__field4_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-14: InlinedCache
         *        Specialization: {@link AppendStringNode#append}
         *        Parameter: {@link AppendStringIntlNode} intlNode
         *        Inline method: {@link AppendStringIntlNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link AppendStringNode#append}
         *        Parameter: {@link AppendStringIntlNode} intlNode
         *        Inline method: {@link AppendStringIntlNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link AppendStringNode#append}
         *        Parameter: {@link AppendStringIntlNode} intlNode
         *        Inline method: {@link AppendStringIntlNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link AppendStringNode#append}
         *        Parameter: {@link AppendStringIntlNode} intlNode
         *        Inline method: {@link AppendStringIntlNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendStringNode#append}
         *   Parameter: {@link AppendStringIntlNode} intlNode
         *   Inline method: {@link AppendStringIntlNodeGen#inline}
         *   Inline field: {@link Node} field4</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node intlNode__field4_;

        private AppendStringNodeGen() {
        }

        @Override
        public void execute(TruffleStringBuilder arg0Value, AbstractTruffleString arg1Value) {
            append(arg0Value, arg1Value, INLINED_INTL_NODE_);
            return;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static AppendStringNode create() {
            return new AppendStringNodeGen();
        }

        @NeverDefault
        public static AppendStringNode getUncached() {
            return AppendStringNodeGen.UNCACHED;
        }

        @GeneratedBy(AppendStringNode.class)
        @DenyReplace
        private static final class Uncached extends AppendStringNode {

            @TruffleBoundary
            @Override
            public void execute(TruffleStringBuilder arg0Value, AbstractTruffleString arg1Value) {
                append(arg0Value, arg1Value, (AppendStringIntlNodeGen.getUncached()));
                return;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.38500
     *     With/without class size: 10/0 bytes
     *   Specialization {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.29500
     *     With/without class size: 11/7 bytes
     *   Specialization {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF32, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.20500
     *     With/without class size: 8/4 bytes
     *   Specialization {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.11500
     *     With/without class size: 6/7 bytes
     * </pre>
     */
    @GeneratedBy(AppendStringIntlNode.class)
    @SuppressWarnings("javadoc")
    static final class AppendStringIntlNodeGen {

        private static final StateField APPEND3__APPEND_STRING_INTL_NODE_APPEND3_STATE_0_UPDATER = StateField.create(Append3Data.lookup_(), "append3_state_0_");
        private static final StateField APPEND3__APPEND_STRING_INTL_NODE_APPEND3_STATE_1_UPDATER = StateField.create(Append3Data.lookup_(), "append3_state_1_");
        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static AppendStringIntlNode getUncached() {
            return AppendStringIntlNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * <li>{@link Inlined#state_1_}
         * <li>{@link Inlined#state_2_}
         * <li>{@link Inlined#state_3_}
         * <li>{@link Inlined#append3_cache}
         * </ul>
         */
        @NeverDefault
        public static AppendStringIntlNode inline(@RequiredField(bits = 15, value = StateField.class)@RequiredField(bits = 25, value = StateField.class)@RequiredField(bits = 25, value = StateField.class)@RequiredField(bits = 25, value = StateField.class)@RequiredField(type = Node.class, value = ReferenceField.class) InlineTarget target) {
            return new AppendStringIntlNodeGen.Inlined(target);
        }

        @GeneratedBy(AppendStringIntlNode.class)
        @DenyReplace
        private static final class Inlined extends AppendStringIntlNode {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   1: SpecializationActive {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   2: SpecializationActive {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF32, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   3: SpecializationActive {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   4-10: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link ToIndexableNode} toIndexableNode
             *        Inline method: {@link ToIndexableNodeGen#inline}
             *   11: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} bufferGrowProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   12: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} errorProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   13: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} slowPathProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   14: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedBranchProfile} inflateProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
             * </pre>
             */
            private final StateField state_1_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
             *        Inline method: {@link GetCodePointLengthNodeGen#inline}
             * </pre>
             */
            private final StateField state_2_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF32, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
             * </pre>
             */
            private final StateField state_3_;
            private final ReferenceField<Append3Data> append3_cache;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link ToIndexableNode} toIndexableNode
             *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
             */
            private final ToIndexableNode toIndexableNode;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile bufferGrowProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} errorProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile errorProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} slowPathProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile slowPathProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} inflateProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile inflateProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
             */
            private final GetPreciseCodeRangeNode append1_getPreciseCodeRangeNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
             *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
             */
            private final GetCodePointLengthNode append1_getCodePointLengthNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderUTF32, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
             */
            private final GetPreciseCodeRangeNode append2_getPreciseCodeRangeNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link ToIndexableNode} toIndexableNode
             *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
             */
            private final ToIndexableNode append3_toIndexableNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
             */
            private final GetPreciseCodeRangeNode append3_getPreciseCodeRangeNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
             *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
             */
            private final GetCodePointLengthNode append3_getCodePointLengthNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile append3_bufferGrowProfile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
             *   Parameter: {@link InlinedBranchProfile} errorProfile
             *   Inline method: {@link InlinedBranchProfile#inline}</pre>
             */
            private final InlinedBranchProfile append3_errorProfile_;

            @SuppressWarnings("unchecked")
            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(AppendStringIntlNode.class);
                this.state_0_ = target.getState(0, 15);
                this.state_1_ = target.getState(1, 25);
                this.state_2_ = target.getState(2, 25);
                this.state_3_ = target.getState(3, 25);
                this.append3_cache = target.getReference(4, Append3Data.class);
                this.toIndexableNode = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, state_0_.subUpdater(4, 7)));
                this.bufferGrowProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(11, 1)));
                this.errorProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(12, 1)));
                this.slowPathProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(13, 1)));
                this.inflateProfile = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(14, 1)));
                this.append1_getPreciseCodeRangeNode_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, state_1_.subUpdater(0, 25)));
                this.append1_getCodePointLengthNode_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, state_2_.subUpdater(0, 25)));
                this.append2_getPreciseCodeRangeNode_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, state_3_.subUpdater(0, 25)));
                this.append3_toIndexableNode_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, state_0_.subUpdater(4, 7)));
                this.append3_getPreciseCodeRangeNode_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, APPEND3__APPEND_STRING_INTL_NODE_APPEND3_STATE_0_UPDATER.subUpdater(0, 25)));
                this.append3_getCodePointLengthNode_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, APPEND3__APPEND_STRING_INTL_NODE_APPEND3_STATE_1_UPDATER.subUpdater(0, 25)));
                this.append3_bufferGrowProfile_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(11, 1)));
                this.append3_errorProfile_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, state_0_.subUpdater(12, 1)));
            }

            @Override
            public void execute(Node arg0Value, TruffleStringBuilder arg1Value, AbstractTruffleString arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((state_0 & 0b1111) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF32, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)] */ && arg1Value instanceof TruffleStringBuilderUTF8) {
                        TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                        AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, this.toIndexableNode, this.bufferGrowProfile, this.errorProfile);
                        return;
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg1Value instanceof TruffleStringBuilderUTF16) {
                        TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                        assert InlineSupport.validate(arg0Value, this.state_1_, this.state_2_);
                        AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, this.toIndexableNode, this.append1_getPreciseCodeRangeNode_, this.append1_getCodePointLengthNode_, this.slowPathProfile, this.inflateProfile, this.bufferGrowProfile, this.errorProfile);
                        return;
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF32, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg1Value instanceof TruffleStringBuilderUTF32) {
                        TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                        assert InlineSupport.validate(arg0Value, this.state_3_);
                        AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, this.toIndexableNode, this.append2_getPreciseCodeRangeNode_, this.slowPathProfile, this.inflateProfile, this.bufferGrowProfile, this.errorProfile);
                        return;
                    }
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)] */ && arg1Value instanceof TruffleStringBuilderGeneric) {
                        TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                        Append3Data s3_ = this.append3_cache.get(arg0Value);
                        if (s3_ != null) {
                            AppendStringIntlNode.append(s3_, arg1Value_, arg2Value, this.append3_toIndexableNode_, this.append3_getPreciseCodeRangeNode_, this.append3_getCodePointLengthNode_, this.append3_bufferGrowProfile_, this.append3_errorProfile_);
                            return;
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                executeAndSpecialize(arg0Value, arg1Value, arg2Value);
                return;
            }

            private void executeAndSpecialize(Node arg0Value, TruffleStringBuilder arg1Value, AbstractTruffleString arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if (arg1Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF8, AbstractTruffleString, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, this.toIndexableNode, this.bufferGrowProfile, this.errorProfile);
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF16, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    assert InlineSupport.validate(arg0Value, this.state_1_, this.state_2_);
                    AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, this.toIndexableNode, this.append1_getPreciseCodeRangeNode_, this.append1_getCodePointLengthNode_, this.slowPathProfile, this.inflateProfile, this.bufferGrowProfile, this.errorProfile);
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                    state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderUTF32, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    assert InlineSupport.validate(arg0Value, this.state_3_);
                    AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, this.toIndexableNode, this.append2_getPreciseCodeRangeNode_, this.slowPathProfile, this.inflateProfile, this.bufferGrowProfile, this.errorProfile);
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                    Append3Data s3_ = arg0Value.insert(new Append3Data());
                    VarHandle.storeStoreFence();
                    this.append3_cache.set(arg0Value, s3_);
                    state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleStringBuilder.AppendStringIntlNode.append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    AppendStringIntlNode.append(s3_, arg1Value_, arg2Value, this.append3_toIndexableNode_, this.append3_getPreciseCodeRangeNode_, this.append3_getCodePointLengthNode_, this.append3_bufferGrowProfile_, this.append3_errorProfile_);
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(AppendStringIntlNode.class)
        @DenyReplace
        private static final class Append3Data extends Node implements SpecializationDataNode {

            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int append3_state_0_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link AppendStringIntlNode#append(Node, TruffleStringBuilderGeneric, AbstractTruffleString, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
             *        Inline method: {@link GetCodePointLengthNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int append3_state_1_;

            Append3Data() {
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

            private static Lookup lookup_() {
                return MethodHandles.lookup();
            }

        }
        @GeneratedBy(AppendStringIntlNode.class)
        @DenyReplace
        private static final class Uncached extends AppendStringIntlNode {

            @TruffleBoundary
            @Override
            public void execute(Node arg0Value, TruffleStringBuilder arg1Value, AbstractTruffleString arg2Value) {
                if (arg1Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                    AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, (ToIndexableNodeGen.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                    AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                    AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg1Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                    AppendStringIntlNode.append(arg0Value, arg1Value_, arg2Value, (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.38500
     *     With/without class size: 10/0 bytes
     *   Specialization {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.29500
     *     With/without class size: 8/0 bytes
     *   Specialization {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF32, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.20500
     *     With/without class size: 7/0 bytes
     *   Specialization {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
     *     Activation probability: 0.11500
     *     With/without class size: 7/9 bytes
     * </pre>
     */
    @GeneratedBy(AppendSubstringByteIndexNode.class)
    @SuppressWarnings("javadoc")
    static final class AppendSubstringByteIndexNodeGen extends AppendSubstringByteIndexNode {

        private static final StateField STATE_0_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_0_AppendSubstringByteIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField APPEND3__APPEND_SUBSTRING_BYTE_INDEX_NODE_APPEND3_STATE_0_UPDATER = StateField.create(Append3Data.lookup_(), "append3_state_0_");
        private static final StateField APPEND3__APPEND_SUBSTRING_BYTE_INDEX_NODE_APPEND3_STATE_1_UPDATER = StateField.create(Append3Data.lookup_(), "append3_state_1_");
        private static final StateField APPEND3__APPEND_SUBSTRING_BYTE_INDEX_NODE_APPEND3_STATE_2_UPDATER = StateField.create(Append3Data.lookup_(), "append3_state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_UPDATER.subUpdater(4, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BUFFER_GROW_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(11, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} errorProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_ERROR_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(12, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_GET_PRECISE_CODE_RANGE_NODE = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_1_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} slowPathProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_SLOW_PATH_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(13, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} inflateProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_INFLATE_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_UPDATER.subUpdater(14, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_APPEND3_TO_INDEXABLE_NODE = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_AppendSubstringByteIndexNode_UPDATER.subUpdater(4, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_APPEND3_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, APPEND3__APPEND_SUBSTRING_BYTE_INDEX_NODE_APPEND3_STATE_0_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_APPEND3_GET_PRECISE_CODE_RANGE_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, APPEND3__APPEND_SUBSTRING_BYTE_INDEX_NODE_APPEND3_STATE_1_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link CalcStringAttributesNode} calcAttributesNode
         *   Inline method: {@link CalcStringAttributesNodeGen#inline}</pre>
         */
        private static final CalcStringAttributesNode INLINED_APPEND3_CALC_ATTRIBUTES_NODE_ = CalcStringAttributesNodeGen.inline(InlineTarget.create(CalcStringAttributesNode.class, APPEND3__APPEND_SUBSTRING_BYTE_INDEX_NODE_APPEND3_STATE_2_UPDATER.subUpdater(0, 16)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedConditionProfile} calcAttrsProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_APPEND3_CALC_ATTRS_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, APPEND3__APPEND_SUBSTRING_BYTE_INDEX_NODE_APPEND3_STATE_0_UPDATER.subUpdater(25, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_APPEND3_BUFFER_GROW_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendSubstringByteIndexNode_UPDATER.subUpdater(11, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   Parameter: {@link InlinedBranchProfile} errorProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_APPEND3_ERROR_PROFILE = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendSubstringByteIndexNode_UPDATER.subUpdater(12, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
         *   1: SpecializationActive {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   2: SpecializationActive {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF32, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   3: SpecializationActive {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *   4-10: InlinedCache
         *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   11: InlinedCache
         *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   12: InlinedCache
         *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} errorProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   13: InlinedCache
         *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} slowPathProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   14: InlinedCache
         *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link InlinedBranchProfile} inflateProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)}
         *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        @Child private Append3Data append3_cache;

        private AppendSubstringByteIndexNodeGen() {
        }

        @Override
        public void execute(TruffleStringBuilder arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1111) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF32, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] || SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                    append(arg0Value_, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                    append(arg0Value_, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE, INLINED_GET_PRECISE_CODE_RANGE_NODE, INLINED_SLOW_PATH_PROFILE, INLINED_INFLATE_PROFILE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF32, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                    append(arg0Value_, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE, INLINED_GET_PRECISE_CODE_RANGE_NODE, INLINED_SLOW_PATH_PROFILE, INLINED_INFLATE_PROFILE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                    return;
                }
                if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    Append3Data s3_ = this.append3_cache;
                    if (s3_ != null) {
                        {
                            Node node__ = (s3_);
                            AppendSubstringByteIndexNode.append(arg0Value_, arg1Value, arg2Value, arg3Value, node__, INLINED_APPEND3_TO_INDEXABLE_NODE, INLINED_APPEND3_GET_CODE_POINT_LENGTH_NODE_, INLINED_APPEND3_GET_PRECISE_CODE_RANGE_NODE_, INLINED_APPEND3_CALC_ATTRIBUTES_NODE_, INLINED_APPEND3_CALC_ATTRS_PROFILE_, INLINED_APPEND3_BUFFER_GROW_PROFILE, INLINED_APPEND3_ERROR_PROFILE);
                            return;
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
            return;
        }

        private void executeAndSpecialize(TruffleStringBuilder arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof TruffleStringBuilderUTF8) {
                TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF8, AbstractTruffleString, int, int, ToIndexableNode, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                append(arg0Value_, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderUTF16) {
                TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF16, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                append(arg0Value_, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE, INLINED_GET_PRECISE_CODE_RANGE_NODE, INLINED_SLOW_PATH_PROFILE, INLINED_INFLATE_PROFILE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            if (arg0Value instanceof TruffleStringBuilderUTF32) {
                TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderUTF32, AbstractTruffleString, int, int, ToIndexableNode, GetPreciseCodeRangeNode, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                append(arg0Value_, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE, INLINED_GET_PRECISE_CODE_RANGE_NODE, INLINED_SLOW_PATH_PROFILE, INLINED_INFLATE_PROFILE, INLINED_BUFFER_GROW_PROFILE, INLINED_ERROR_PROFILE);
                return;
            }
            {
                Node node__ = null;
                if (arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    Append3Data s3_ = this.insert(new Append3Data());
                    node__ = (s3_);
                    VarHandle.storeStoreFence();
                    this.append3_cache = s3_;
                    state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleStringBuilder.AppendSubstringByteIndexNode.append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                    this.state_0_ = state_0;
                    AppendSubstringByteIndexNode.append(arg0Value_, arg1Value, arg2Value, arg3Value, node__, INLINED_APPEND3_TO_INDEXABLE_NODE, INLINED_APPEND3_GET_CODE_POINT_LENGTH_NODE_, INLINED_APPEND3_GET_PRECISE_CODE_RANGE_NODE_, INLINED_APPEND3_CALC_ATTRIBUTES_NODE_, INLINED_APPEND3_CALC_ATTRS_PROFILE_, INLINED_APPEND3_BUFFER_GROW_PROFILE, INLINED_APPEND3_ERROR_PROFILE);
                    return;
                }
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1111) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount((state_0 & 0b1111));
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static AppendSubstringByteIndexNode create() {
            return new AppendSubstringByteIndexNodeGen();
        }

        @NeverDefault
        public static AppendSubstringByteIndexNode getUncached() {
            return AppendSubstringByteIndexNodeGen.UNCACHED;
        }

        @GeneratedBy(AppendSubstringByteIndexNode.class)
        @DenyReplace
        private static final class Append3Data extends Node implements SpecializationDataNode {

            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
             *        Inline method: {@link GetCodePointLengthNodeGen#inline}
             *   25-26: InlinedCache
             *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link InlinedConditionProfile} calcAttrsProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int append3_state_0_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int append3_state_1_;
            /**
             * State Info: <pre>
             *   0-15: InlinedCache
             *        Specialization: {@link AppendSubstringByteIndexNode#append(TruffleStringBuilderGeneric, AbstractTruffleString, int, int, Node, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)}
             *        Parameter: {@link CalcStringAttributesNode} calcAttributesNode
             *        Inline method: {@link CalcStringAttributesNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int append3_state_2_;

            Append3Data() {
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

            private static Lookup lookup_() {
                return MethodHandles.lookup();
            }

        }
        @GeneratedBy(AppendSubstringByteIndexNode.class)
        @DenyReplace
        private static final class Uncached extends AppendSubstringByteIndexNode {

            @TruffleBoundary
            @Override
            public void execute(TruffleStringBuilder arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value) {
                if (arg0Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg0Value_ = (TruffleStringBuilderUTF8) arg0Value;
                    append(arg0Value_, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                    append(arg0Value_, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg0Value_ = (TruffleStringBuilderUTF32) arg0Value;
                    append(arg0Value_, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                if (arg0Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg0Value_ = (TruffleStringBuilderGeneric) arg0Value;
                    AppendSubstringByteIndexNode.append(arg0Value_, arg1Value, arg2Value, arg3Value, (this), (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (CalcStringAttributesNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AppendJavaStringUTF16Node#append}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(AppendJavaStringUTF16Node.class)
    @SuppressWarnings("javadoc")
    static final class AppendJavaStringUTF16NodeGen extends AppendJavaStringUTF16Node {

        private static final StateField STATE_0_AppendJavaStringUTF16Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendJavaStringUTF16Node#append}
         *   Parameter: {@link InlinedBranchProfile} slowPathProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_SLOW_PATH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendJavaStringUTF16Node_UPDATER.subUpdater(1, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendJavaStringUTF16Node#append}
         *   Parameter: {@link InlinedBranchProfile} inflateProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_INFLATE_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendJavaStringUTF16Node_UPDATER.subUpdater(2, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendJavaStringUTF16Node#append}
         *   Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_BUFFER_GROW_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendJavaStringUTF16Node_UPDATER.subUpdater(3, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AppendJavaStringUTF16Node#append}
         *   Parameter: {@link InlinedBranchProfile} errorProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_ERROR_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_AppendJavaStringUTF16Node_UPDATER.subUpdater(4, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AppendJavaStringUTF16Node#append}
         *   1: InlinedCache
         *        Specialization: {@link AppendJavaStringUTF16Node#append}
         *        Parameter: {@link InlinedBranchProfile} slowPathProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   2: InlinedCache
         *        Specialization: {@link AppendJavaStringUTF16Node#append}
         *        Parameter: {@link InlinedBranchProfile} inflateProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   3: InlinedCache
         *        Specialization: {@link AppendJavaStringUTF16Node#append}
         *        Parameter: {@link InlinedBranchProfile} bufferGrowProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   4: InlinedCache
         *        Specialization: {@link AppendJavaStringUTF16Node#append}
         *        Parameter: {@link InlinedBranchProfile} errorProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private AppendJavaStringUTF16NodeGen() {
        }

        @Override
        public void execute(TruffleStringBuilder arg0Value, String arg1Value, int arg2Value, int arg3Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.AppendJavaStringUTF16Node.append(TruffleStringBuilderUTF16, String, int, int, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */ && arg0Value instanceof TruffleStringBuilderUTF16) {
                TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                append(arg0Value_, arg1Value, arg2Value, arg3Value, INLINED_SLOW_PATH_PROFILE_, INLINED_INFLATE_PROFILE_, INLINED_BUFFER_GROW_PROFILE_, INLINED_ERROR_PROFILE_);
                return;
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
            return;
        }

        private void executeAndSpecialize(TruffleStringBuilder arg0Value, String arg1Value, int arg2Value, int arg3Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof TruffleStringBuilderUTF16) {
                TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.AppendJavaStringUTF16Node.append(TruffleStringBuilderUTF16, String, int, int, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                append(arg0Value_, arg1Value, arg2Value, arg3Value, INLINED_SLOW_PATH_PROFILE_, INLINED_INFLATE_PROFILE_, INLINED_BUFFER_GROW_PROFILE_, INLINED_ERROR_PROFILE_);
                return;
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static AppendJavaStringUTF16Node create() {
            return new AppendJavaStringUTF16NodeGen();
        }

        @NeverDefault
        public static AppendJavaStringUTF16Node getUncached() {
            return AppendJavaStringUTF16NodeGen.UNCACHED;
        }

        @GeneratedBy(AppendJavaStringUTF16Node.class)
        @DenyReplace
        private static final class Uncached extends AppendJavaStringUTF16Node {

            @TruffleBoundary
            @Override
            public void execute(TruffleStringBuilder arg0Value, String arg1Value, int arg2Value, int arg3Value) {
                if (arg0Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg0Value_ = (TruffleStringBuilderUTF16) arg0Value;
                    append(arg0Value_, arg1Value, arg2Value, arg3Value, (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
                    return;
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ToStringNode#createString}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(ToStringNode.class)
    @SuppressWarnings("javadoc")
    static final class ToStringNodeGen extends ToStringNode {

        private static final StateField STATE_0_ToStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToStringNode#createString}
         *   Parameter: {@link ToStringIntlNode} intlNode
         *   Inline method: {@link ToStringIntlNodeGen#inline}</pre>
         */
        private static final ToStringIntlNode INLINED_INTL_NODE_ = ToStringIntlNodeGen.inline(InlineTarget.create(ToStringIntlNode.class, STATE_0_ToStringNode_UPDATER.subUpdater(0, 24)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-23: InlinedCache
         *        Specialization: {@link ToStringNode#createString}
         *        Parameter: {@link ToStringIntlNode} intlNode
         *        Inline method: {@link ToStringIntlNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private ToStringNodeGen() {
        }

        @Override
        public TruffleString execute(TruffleStringBuilder arg0Value, boolean arg1Value) {
            return createString(arg0Value, arg1Value, INLINED_INTL_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static ToStringNode create() {
            return new ToStringNodeGen();
        }

        @NeverDefault
        public static ToStringNode getUncached() {
            return ToStringNodeGen.UNCACHED;
        }

        @GeneratedBy(ToStringNode.class)
        @DenyReplace
        private static final class Uncached extends ToStringNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(TruffleStringBuilder arg0Value, boolean arg1Value) {
                return createString(arg0Value, arg1Value, (ToStringIntlNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ToStringIntlNode#createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)}
     *     Activation probability: 0.38500
     *     With/without class size: 11/1 bytes
     *   Specialization {@link ToStringIntlNode#createString(Node, TruffleStringBuilderUTF16, boolean, InlinedConditionProfile)}
     *     Activation probability: 0.29500
     *     With/without class size: 8/0 bytes
     *   Specialization {@link ToStringIntlNode#createString(TruffleStringBuilderUTF32, boolean)}
     *     Activation probability: 0.20500
     *     With/without class size: 6/0 bytes
     *   Specialization {@link ToStringIntlNode#createString(Node, TruffleStringBuilderGeneric, boolean, InlinedConditionProfile, CalcStringAttributesNode)}
     *     Activation probability: 0.11500
     *     With/without class size: 6/2 bytes
     * </pre>
     */
    @GeneratedBy(ToStringIntlNode.class)
    @SuppressWarnings("javadoc")
    static final class ToStringIntlNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static ToStringIntlNode getUncached() {
            return ToStringIntlNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * </ul>
         */
        @NeverDefault
        public static ToStringIntlNode inline(@RequiredField(bits = 24, value = StateField.class) InlineTarget target) {
            return new ToStringIntlNodeGen.Inlined(target);
        }

        @GeneratedBy(ToStringIntlNode.class)
        @DenyReplace
        private static final class Inlined extends ToStringIntlNode {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link ToStringIntlNode#createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)}
             *   1: SpecializationActive {@link ToStringIntlNode#createString(Node, TruffleStringBuilderUTF16, boolean, InlinedConditionProfile)}
             *   2: SpecializationActive {@link ToStringIntlNode#createString(TruffleStringBuilderUTF32, boolean)}
             *   3: SpecializationActive {@link ToStringIntlNode#createString(Node, TruffleStringBuilderGeneric, boolean, InlinedConditionProfile, CalcStringAttributesNode)}
             *   4-5: InlinedCache
             *        Specialization: {@link ToStringIntlNode#createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)}
             *        Parameter: {@link InlinedConditionProfile} calcAttributesProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   6-7: InlinedCache
             *        Specialization: {@link ToStringIntlNode#createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)}
             *        Parameter: {@link InlinedConditionProfile} brokenProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   8-23: InlinedCache
             *        Specialization: {@link ToStringIntlNode#createString(Node, TruffleStringBuilderGeneric, boolean, InlinedConditionProfile, CalcStringAttributesNode)}
             *        Parameter: {@link CalcStringAttributesNode} calcAttributesNode
             *        Inline method: {@link CalcStringAttributesNodeGen#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ToStringIntlNode#createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)}
             *   Parameter: {@link InlinedConditionProfile} calcAttributesProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile calcAttributesProfile;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ToStringIntlNode#createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)}
             *   Parameter: {@link InlinedConditionProfile} brokenProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile createString0_brokenProfile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ToStringIntlNode#createString(Node, TruffleStringBuilderGeneric, boolean, InlinedConditionProfile, CalcStringAttributesNode)}
             *   Parameter: {@link CalcStringAttributesNode} calcAttributesNode
             *   Inline method: {@link CalcStringAttributesNodeGen#inline}</pre>
             */
            private final CalcStringAttributesNode createString3_calcAttributesNode_;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(ToStringIntlNode.class);
                this.state_0_ = target.getState(0, 24);
                this.calcAttributesProfile = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(4, 2)));
                this.createString0_brokenProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(6, 2)));
                this.createString3_calcAttributesNode_ = CalcStringAttributesNodeGen.inline(InlineTarget.create(CalcStringAttributesNode.class, state_0_.subUpdater(8, 16)));
            }

            @Override
            public TruffleString execute(Node arg0Value, TruffleStringBuilder arg1Value, boolean arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((state_0 & 0b1111) != 0 /* is SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)] || SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderUTF16, boolean, InlinedConditionProfile)] || SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(TruffleStringBuilderUTF32, boolean)] || SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderGeneric, boolean, InlinedConditionProfile, CalcStringAttributesNode)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)] */ && arg1Value instanceof TruffleStringBuilderUTF8) {
                        TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                        assert InlineSupport.validate(arg0Value, this.state_0_);
                        return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, this.calcAttributesProfile, this.createString0_brokenProfile_);
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderUTF16, boolean, InlinedConditionProfile)] */ && arg1Value instanceof TruffleStringBuilderUTF16) {
                        TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                        return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, this.calcAttributesProfile);
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(TruffleStringBuilderUTF32, boolean)] */ && arg1Value instanceof TruffleStringBuilderUTF32) {
                        TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                        return ToStringIntlNode.createString(arg1Value_, arg2Value);
                    }
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderGeneric, boolean, InlinedConditionProfile, CalcStringAttributesNode)] */ && arg1Value instanceof TruffleStringBuilderGeneric) {
                        TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                        assert InlineSupport.validate(arg0Value, this.state_0_);
                        return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, this.calcAttributesProfile, this.createString3_calcAttributesNode_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
            }

            private TruffleString executeAndSpecialize(Node arg0Value, TruffleStringBuilder arg1Value, boolean arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if (arg1Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderUTF8, boolean, InlinedConditionProfile, InlinedConditionProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    assert InlineSupport.validate(arg0Value, this.state_0_);
                    return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, this.calcAttributesProfile, this.createString0_brokenProfile_);
                }
                if (arg1Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderUTF16, boolean, InlinedConditionProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, this.calcAttributesProfile);
                }
                if (arg1Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                    state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(TruffleStringBuilderUTF32, boolean)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return ToStringIntlNode.createString(arg1Value_, arg2Value);
                }
                if (arg1Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                    state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleStringBuilder.ToStringIntlNode.createString(Node, TruffleStringBuilderGeneric, boolean, InlinedConditionProfile, CalcStringAttributesNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    assert InlineSupport.validate(arg0Value, this.state_0_);
                    return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, this.calcAttributesProfile, this.createString3_calcAttributesNode_);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(ToStringIntlNode.class)
        @DenyReplace
        private static final class Uncached extends ToStringIntlNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(Node arg0Value, TruffleStringBuilder arg1Value, boolean arg2Value) {
                if (arg1Value instanceof TruffleStringBuilderUTF8) {
                    TruffleStringBuilderUTF8 arg1Value_ = (TruffleStringBuilderUTF8) arg1Value;
                    return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()));
                }
                if (arg1Value instanceof TruffleStringBuilderUTF16) {
                    TruffleStringBuilderUTF16 arg1Value_ = (TruffleStringBuilderUTF16) arg1Value;
                    return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, (InlinedConditionProfile.getUncached()));
                }
                if (arg1Value instanceof TruffleStringBuilderUTF32) {
                    TruffleStringBuilderUTF32 arg1Value_ = (TruffleStringBuilderUTF32) arg1Value;
                    return ToStringIntlNode.createString(arg1Value_, arg2Value);
                }
                if (arg1Value instanceof TruffleStringBuilderGeneric) {
                    TruffleStringBuilderGeneric arg1Value_ = (TruffleStringBuilderGeneric) arg1Value;
                    return ToStringIntlNode.createString(arg0Value, arg1Value_, arg2Value, (InlinedConditionProfile.getUncached()), (CalcStringAttributesNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
}
