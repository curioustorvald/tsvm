// CheckStyle: start generated
package com.oracle.truffle.api.strings;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.InlineSupport;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.IntField;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.RequiredField;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.InlinedBranchProfile;
import com.oracle.truffle.api.profiles.InlinedConditionProfile;
import com.oracle.truffle.api.profiles.InlinedIntValueProfile;
import com.oracle.truffle.api.strings.AbstractTruffleString.LazyConcat;
import com.oracle.truffle.api.strings.AbstractTruffleString.LazyLong;
import com.oracle.truffle.api.strings.AbstractTruffleString.NativePointer;
import com.oracle.truffle.api.strings.TStringInternalNodes.CalcStringAttributesNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.CodePointAtNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.CodePointAtRawNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.CodePointIndexToRawNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.ConcatEagerNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.CreateJavaStringNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.FromBufferWithStringCompactionKnownAttributesNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.FromBufferWithStringCompactionNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.FromJavaStringUTF16Node;
import com.oracle.truffle.api.strings.TStringInternalNodes.GetCodePointLengthNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.GetCodeRangeForIndexCalculationNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.GetPreciseCodeRangeNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.IndexOfCodePointRawNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.IndexOfCodePointSetNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.IndexOfStringRawNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.InternalIndexOfStringNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfCodePointRawNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfStringRawNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.RawIndexToCodePointIndexNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.RegionEqualsNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.StrideFromCodeRangeNode;
import com.oracle.truffle.api.strings.TStringInternalNodes.TransCodeNode;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.CalcStringAttributesNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.CodePointAtNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.CodePointAtRawNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.CodePointIndexToRawNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.ConcatEagerNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.CreateJavaStringNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.FromBufferWithStringCompactionKnownAttributesNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.FromBufferWithStringCompactionNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.FromJavaStringUTF16NodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.GetCodePointLengthNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.GetCodeRangeForIndexCalculationNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.GetPreciseCodeRangeNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.IndexOfCodePointRawNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.IndexOfStringRawNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.InternalIndexOfStringNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfCodePointRawNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfStringRawNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.RawIndexToCodePointIndexNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.RegionEqualsNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.StrideFromCodeRangeNodeGen;
import com.oracle.truffle.api.strings.TStringInternalNodesFactory.TransCodeNodeGen;
import com.oracle.truffle.api.strings.TStringOpsNodes.CalculateHashCodeNode;
import com.oracle.truffle.api.strings.TStringOpsNodes.IndexOfAnyCharNode;
import com.oracle.truffle.api.strings.TStringOpsNodes.IndexOfAnyIntNode;
import com.oracle.truffle.api.strings.TStringOpsNodesFactory.CalculateHashCodeNodeGen;
import com.oracle.truffle.api.strings.TStringOpsNodesFactory.IndexOfAnyCharNodeGen;
import com.oracle.truffle.api.strings.TStringOpsNodesFactory.IndexOfAnyIntNodeGen;
import com.oracle.truffle.api.strings.TruffleString.AsManagedNode;
import com.oracle.truffle.api.strings.TruffleString.AsNativeNode;
import com.oracle.truffle.api.strings.TruffleString.AsTruffleStringNode;
import com.oracle.truffle.api.strings.TruffleString.ByteIndexOfAnyByteNode;
import com.oracle.truffle.api.strings.TruffleString.ByteIndexOfCodePointNode;
import com.oracle.truffle.api.strings.TruffleString.ByteIndexOfCodePointSetNode;
import com.oracle.truffle.api.strings.TruffleString.ByteIndexOfStringNode;
import com.oracle.truffle.api.strings.TruffleString.ByteIndexToCodePointIndexNode;
import com.oracle.truffle.api.strings.TruffleString.CharIndexOfAnyCharUTF16Node;
import com.oracle.truffle.api.strings.TruffleString.CodePointAtByteIndexNode;
import com.oracle.truffle.api.strings.TruffleString.CodePointAtIndexNode;
import com.oracle.truffle.api.strings.TruffleString.CodePointIndexToByteIndexNode;
import com.oracle.truffle.api.strings.TruffleString.CodePointLengthNode;
import com.oracle.truffle.api.strings.TruffleString.CodePointSet;
import com.oracle.truffle.api.strings.TruffleString.CodeRange;
import com.oracle.truffle.api.strings.TruffleString.CodeRangeEqualsNode;
import com.oracle.truffle.api.strings.TruffleString.CompactionLevel;
import com.oracle.truffle.api.strings.TruffleString.CompareBytesNode;
import com.oracle.truffle.api.strings.TruffleString.CompareCharsUTF16Node;
import com.oracle.truffle.api.strings.TruffleString.CompareIntsUTF32Node;
import com.oracle.truffle.api.strings.TruffleString.ConcatNode;
import com.oracle.truffle.api.strings.TruffleString.CopyToByteArrayNode;
import com.oracle.truffle.api.strings.TruffleString.CopyToNativeMemoryNode;
import com.oracle.truffle.api.strings.TruffleString.CreateBackwardCodePointIteratorNode;
import com.oracle.truffle.api.strings.TruffleString.CreateCodePointIteratorNode;
import com.oracle.truffle.api.strings.TruffleString.Encoding;
import com.oracle.truffle.api.strings.TruffleString.EqualNode;
import com.oracle.truffle.api.strings.TruffleString.ErrorHandling;
import com.oracle.truffle.api.strings.TruffleString.ForceEncodingNode;
import com.oracle.truffle.api.strings.TruffleString.FromByteArrayNode;
import com.oracle.truffle.api.strings.TruffleString.FromCharArrayUTF16Node;
import com.oracle.truffle.api.strings.TruffleString.FromCodePointNode;
import com.oracle.truffle.api.strings.TruffleString.FromIntArrayUTF32Node;
import com.oracle.truffle.api.strings.TruffleString.FromJavaStringNode;
import com.oracle.truffle.api.strings.TruffleString.FromLongNode;
import com.oracle.truffle.api.strings.TruffleString.GetByteCodeRangeNode;
import com.oracle.truffle.api.strings.TruffleString.GetCodeRangeImpreciseNode;
import com.oracle.truffle.api.strings.TruffleString.GetCodeRangeNode;
import com.oracle.truffle.api.strings.TruffleString.GetInternalByteArrayNode;
import com.oracle.truffle.api.strings.TruffleString.GetInternalNativePointerNode;
import com.oracle.truffle.api.strings.TruffleString.GetStringCompactionLevelNode;
import com.oracle.truffle.api.strings.TruffleString.HashCodeNode;
import com.oracle.truffle.api.strings.TruffleString.IndexOfStringNode;
import com.oracle.truffle.api.strings.TruffleString.IntIndexOfAnyIntUTF32Node;
import com.oracle.truffle.api.strings.TruffleString.InternalAsTruffleStringNode;
import com.oracle.truffle.api.strings.TruffleString.InternalCopyToByteArrayNode;
import com.oracle.truffle.api.strings.TruffleString.InternalSwitchEncodingNode;
import com.oracle.truffle.api.strings.TruffleString.IsValidNode;
import com.oracle.truffle.api.strings.TruffleString.LastByteIndexOfCodePointNode;
import com.oracle.truffle.api.strings.TruffleString.LastByteIndexOfStringNode;
import com.oracle.truffle.api.strings.TruffleString.MaterializeNode;
import com.oracle.truffle.api.strings.TruffleString.NumberFormatException;
import com.oracle.truffle.api.strings.TruffleString.ReadCharUTF16Node;
import com.oracle.truffle.api.strings.TruffleString.RegionEqualByteIndexNode;
import com.oracle.truffle.api.strings.TruffleString.RegionEqualNode;
import com.oracle.truffle.api.strings.TruffleString.RepeatNode;
import com.oracle.truffle.api.strings.TruffleString.SubstringByteIndexNode;
import com.oracle.truffle.api.strings.TruffleString.SwitchEncodingNode;
import com.oracle.truffle.api.strings.TruffleString.ToIndexableNode;
import com.oracle.truffle.api.strings.TruffleString.ToJavaStringNode;
import com.oracle.truffle.api.strings.TruffleString.WithMask;
import com.oracle.truffle.api.strings.TruffleString.WithMask.CreateNode;
import com.oracle.truffle.api.strings.TruffleString.WithMask.CreateUTF16Node;
import com.oracle.truffle.api.strings.TruffleString.WithMask.CreateUTF32Node;
import com.oracle.truffle.api.strings.TruffleStringIterator.InternalNextNode;
import com.oracle.truffle.api.strings.TruffleStringIteratorFactory.InternalNextNodeGen;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Objects;

@GeneratedBy(TruffleString.class)
@SuppressWarnings("javadoc")
public final class TruffleStringFactory {

    @GeneratedBy(WithMask.class)
    public static final class WithMaskFactory {

        /**
         * Debug Info: <pre>
         *   Specialization {@link CreateNode#doCreate}
         *     Activation probability: 1.00000
         *     With/without class size: 16/0 bytes
         * </pre>
         */
        @GeneratedBy(CreateNode.class)
        @SuppressWarnings("javadoc")
        static final class CreateNodeGen extends CreateNode {

            private static final Uncached UNCACHED = new Uncached();

            private CreateNodeGen() {
            }

            @Override
            public WithMask execute(AbstractTruffleString arg0Value, byte[] arg1Value, Encoding arg2Value) {
                return doCreate(arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MONOMORPHIC;
            }

            @NeverDefault
            public static CreateNode create() {
                return new CreateNodeGen();
            }

            @NeverDefault
            public static CreateNode getUncached() {
                return CreateNodeGen.UNCACHED;
            }

            @GeneratedBy(CreateNode.class)
            @DenyReplace
            private static final class Uncached extends CreateNode {

                @TruffleBoundary
                @Override
                public WithMask execute(AbstractTruffleString arg0Value, byte[] arg1Value, Encoding arg2Value) {
                    return doCreate(arg0Value, arg1Value, arg2Value);
                }

                @Override
                public NodeCost getCost() {
                    return NodeCost.MEGAMORPHIC;
                }

                @Override
                public boolean isAdoptable() {
                    return false;
                }

            }
        }
        /**
         * Debug Info: <pre>
         *   Specialization {@link CreateUTF16Node#doCreate}
         *     Activation probability: 1.00000
         *     With/without class size: 16/0 bytes
         * </pre>
         */
        @GeneratedBy(CreateUTF16Node.class)
        @SuppressWarnings("javadoc")
        static final class CreateUTF16NodeGen extends CreateUTF16Node {

            private static final Uncached UNCACHED = new Uncached();

            private CreateUTF16NodeGen() {
            }

            @Override
            public WithMask execute(AbstractTruffleString arg0Value, char[] arg1Value) {
                return doCreate(arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MONOMORPHIC;
            }

            @NeverDefault
            public static CreateUTF16Node create() {
                return new CreateUTF16NodeGen();
            }

            @NeverDefault
            public static CreateUTF16Node getUncached() {
                return CreateUTF16NodeGen.UNCACHED;
            }

            @GeneratedBy(CreateUTF16Node.class)
            @DenyReplace
            private static final class Uncached extends CreateUTF16Node {

                @TruffleBoundary
                @Override
                public WithMask execute(AbstractTruffleString arg0Value, char[] arg1Value) {
                    return doCreate(arg0Value, arg1Value);
                }

                @Override
                public NodeCost getCost() {
                    return NodeCost.MEGAMORPHIC;
                }

                @Override
                public boolean isAdoptable() {
                    return false;
                }

            }
        }
        /**
         * Debug Info: <pre>
         *   Specialization {@link CreateUTF32Node#doCreate}
         *     Activation probability: 1.00000
         *     With/without class size: 16/0 bytes
         * </pre>
         */
        @GeneratedBy(CreateUTF32Node.class)
        @SuppressWarnings("javadoc")
        static final class CreateUTF32NodeGen extends CreateUTF32Node {

            private static final Uncached UNCACHED = new Uncached();

            private CreateUTF32NodeGen() {
            }

            @Override
            public WithMask execute(AbstractTruffleString arg0Value, int[] arg1Value) {
                return doCreate(arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MONOMORPHIC;
            }

            @NeverDefault
            public static CreateUTF32Node create() {
                return new CreateUTF32NodeGen();
            }

            @NeverDefault
            public static CreateUTF32Node getUncached() {
                return CreateUTF32NodeGen.UNCACHED;
            }

            @GeneratedBy(CreateUTF32Node.class)
            @DenyReplace
            private static final class Uncached extends CreateUTF32Node {

                @TruffleBoundary
                @Override
                public WithMask execute(AbstractTruffleString arg0Value, int[] arg1Value) {
                    return doCreate(arg0Value, arg1Value);
                }

                @Override
                public NodeCost getCost() {
                    return NodeCost.MEGAMORPHIC;
                }

                @Override
                public boolean isAdoptable() {
                    return false;
                }

            }
        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link FromCodePointNode#fromCodePoint}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(FromCodePointNode.class)
    @SuppressWarnings("javadoc")
    static final class FromCodePointNodeGen extends FromCodePointNode {

        private static final StateField STATE_0_FromCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCodePointNode#fromCodePoint}
         *   Parameter: {@link InlinedConditionProfile} bytesProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_BYTES_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromCodePointNode_UPDATER.subUpdater(0, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCodePointNode#fromCodePoint}
         *   Parameter: {@link InlinedConditionProfile} utf8Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF8_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromCodePointNode_UPDATER.subUpdater(2, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCodePointNode#fromCodePoint}
         *   Parameter: {@link InlinedConditionProfile} utf16Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF16_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromCodePointNode_UPDATER.subUpdater(4, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCodePointNode#fromCodePoint}
         *   Parameter: {@link InlinedConditionProfile} utf32Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromCodePointNode_UPDATER.subUpdater(6, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCodePointNode#fromCodePoint}
         *   Parameter: {@link InlinedConditionProfile} exoticProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_EXOTIC_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromCodePointNode_UPDATER.subUpdater(8, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCodePointNode#fromCodePoint}
         *   Parameter: {@link InlinedConditionProfile} bmpProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_BMP_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromCodePointNode_UPDATER.subUpdater(10, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCodePointNode#fromCodePoint}
         *   Parameter: {@link InlinedBranchProfile} invalidCodePoint
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_INVALID_CODE_POINT_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_FromCodePointNode_UPDATER.subUpdater(12, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-1: InlinedCache
         *        Specialization: {@link FromCodePointNode#fromCodePoint}
         *        Parameter: {@link InlinedConditionProfile} bytesProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   2-3: InlinedCache
         *        Specialization: {@link FromCodePointNode#fromCodePoint}
         *        Parameter: {@link InlinedConditionProfile} utf8Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   4-5: InlinedCache
         *        Specialization: {@link FromCodePointNode#fromCodePoint}
         *        Parameter: {@link InlinedConditionProfile} utf16Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   6-7: InlinedCache
         *        Specialization: {@link FromCodePointNode#fromCodePoint}
         *        Parameter: {@link InlinedConditionProfile} utf32Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   8-9: InlinedCache
         *        Specialization: {@link FromCodePointNode#fromCodePoint}
         *        Parameter: {@link InlinedConditionProfile} exoticProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   10-11: InlinedCache
         *        Specialization: {@link FromCodePointNode#fromCodePoint}
         *        Parameter: {@link InlinedConditionProfile} bmpProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   12: InlinedCache
         *        Specialization: {@link FromCodePointNode#fromCodePoint}
         *        Parameter: {@link InlinedBranchProfile} invalidCodePoint
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private FromCodePointNodeGen() {
        }

        @Override
        public TruffleString execute(int arg0Value, Encoding arg1Value, boolean arg2Value) {
            return fromCodePoint(arg0Value, arg1Value, arg2Value, INLINED_BYTES_PROFILE_, INLINED_UTF8_PROFILE_, INLINED_UTF16_PROFILE_, INLINED_UTF32_PROFILE_, INLINED_EXOTIC_PROFILE_, INLINED_BMP_PROFILE_, INLINED_INVALID_CODE_POINT_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static FromCodePointNode create() {
            return new FromCodePointNodeGen();
        }

        @NeverDefault
        public static FromCodePointNode getUncached() {
            return FromCodePointNodeGen.UNCACHED;
        }

        @GeneratedBy(FromCodePointNode.class)
        @DenyReplace
        private static final class Uncached extends FromCodePointNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(int arg0Value, Encoding arg1Value, boolean arg2Value) {
                return fromCodePoint(arg0Value, arg1Value, arg2Value, (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link FromLongNode#doLazy}
     *     Activation probability: 0.48333
     *     With/without class size: 9/0 bytes
     *   Specialization {@link FromLongNode#doEager}
     *     Activation probability: 0.33333
     *     With/without class size: 8/0 bytes
     *   Specialization {@link FromLongNode#unsupported}
     *     Activation probability: 0.18333
     *     With/without class size: 6/0 bytes
     * </pre>
     */
    @GeneratedBy(FromLongNode.class)
    @SuppressWarnings("javadoc")
    static final class FromLongNodeGen extends FromLongNode {

        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link FromLongNode#doLazy}
         *   1: SpecializationActive {@link FromLongNode#doEager}
         *   2: SpecializationActive {@link FromLongNode#unsupported}
         * </pre>
         */
        @CompilationFinal private int state_0_;

        private FromLongNodeGen() {
        }

        @Override
        public TruffleString execute(long arg0Value, Encoding arg1Value, boolean arg2Value) {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[TruffleString.FromLongNode.doLazy(long, Encoding, boolean)] || SpecializationActive[TruffleString.FromLongNode.doEager(long, Encoding, boolean)] || SpecializationActive[TruffleString.FromLongNode.unsupported(long, Encoding, boolean)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.FromLongNode.doLazy(long, Encoding, boolean)] */) {
                    if ((TStringGuards.is7BitCompatible(arg1Value)) && (arg2Value)) {
                        return FromLongNode.doLazy(arg0Value, arg1Value, arg2Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.FromLongNode.doEager(long, Encoding, boolean)] */) {
                    if ((TStringGuards.is7BitCompatible(arg1Value)) && (!(arg2Value))) {
                        return FromLongNode.doEager(arg0Value, arg1Value, arg2Value);
                    }
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleString.FromLongNode.unsupported(long, Encoding, boolean)] */) {
                    if ((!(TStringGuards.is7BitCompatible(arg1Value)))) {
                        return FromLongNode.unsupported(arg0Value, arg1Value, arg2Value);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private TruffleString executeAndSpecialize(long arg0Value, Encoding arg1Value, boolean arg2Value) {
            int state_0 = this.state_0_;
            if ((TStringGuards.is7BitCompatible(arg1Value)) && (arg2Value)) {
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.FromLongNode.doLazy(long, Encoding, boolean)] */;
                this.state_0_ = state_0;
                return FromLongNode.doLazy(arg0Value, arg1Value, arg2Value);
            }
            if ((TStringGuards.is7BitCompatible(arg1Value)) && (!(arg2Value))) {
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.FromLongNode.doEager(long, Encoding, boolean)] */;
                this.state_0_ = state_0;
                return FromLongNode.doEager(arg0Value, arg1Value, arg2Value);
            }
            if ((!(TStringGuards.is7BitCompatible(arg1Value)))) {
                state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleString.FromLongNode.unsupported(long, Encoding, boolean)] */;
                this.state_0_ = state_0;
                return FromLongNode.unsupported(arg0Value, arg1Value, arg2Value);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static FromLongNode create() {
            return new FromLongNodeGen();
        }

        @NeverDefault
        public static FromLongNode getUncached() {
            return FromLongNodeGen.UNCACHED;
        }

        @GeneratedBy(FromLongNode.class)
        @DenyReplace
        private static final class Uncached extends FromLongNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(long arg0Value, Encoding arg1Value, boolean arg2Value) {
                if ((TStringGuards.is7BitCompatible(arg1Value)) && (arg2Value)) {
                    return FromLongNode.doLazy(arg0Value, arg1Value, arg2Value);
                }
                if ((TStringGuards.is7BitCompatible(arg1Value)) && (!(arg2Value))) {
                    return FromLongNode.doEager(arg0Value, arg1Value, arg2Value);
                }
                if ((!(TStringGuards.is7BitCompatible(arg1Value)))) {
                    return FromLongNode.unsupported(arg0Value, arg1Value, arg2Value);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link FromByteArrayNode#fromByteArray}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(FromByteArrayNode.class)
    @SuppressWarnings("javadoc")
    static final class FromByteArrayNodeGen extends FromByteArrayNode {

        private static final StateField STATE_0_FromByteArrayNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromByteArrayNode#fromByteArray}
         *   Parameter: {@link FromBufferWithStringCompactionNode} fromBufferWithStringCompactionNode
         *   Inline method: {@link FromBufferWithStringCompactionNodeGen#inline}</pre>
         */
        private static final FromBufferWithStringCompactionNode INLINED_FROM_BUFFER_WITH_STRING_COMPACTION_NODE_ = FromBufferWithStringCompactionNodeGen.inline(InlineTarget.create(FromBufferWithStringCompactionNode.class, STATE_0_FromByteArrayNode_UPDATER.subUpdater(0, 20)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-19: InlinedCache
         *        Specialization: {@link FromByteArrayNode#fromByteArray}
         *        Parameter: {@link FromBufferWithStringCompactionNode} fromBufferWithStringCompactionNode
         *        Inline method: {@link FromBufferWithStringCompactionNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private FromByteArrayNodeGen() {
        }

        @Override
        public TruffleString execute(byte[] arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            return fromByteArray(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_FROM_BUFFER_WITH_STRING_COMPACTION_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static FromByteArrayNode create() {
            return new FromByteArrayNodeGen();
        }

        @NeverDefault
        public static FromByteArrayNode getUncached() {
            return FromByteArrayNodeGen.UNCACHED;
        }

        @GeneratedBy(FromByteArrayNode.class)
        @DenyReplace
        private static final class Uncached extends FromByteArrayNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(byte[] arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
                return fromByteArray(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (FromBufferWithStringCompactionNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link FromCharArrayUTF16Node#doNonEmpty}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(FromCharArrayUTF16Node.class)
    @SuppressWarnings("javadoc")
    static final class FromCharArrayUTF16NodeGen extends FromCharArrayUTF16Node {

        private static final StateField STATE_0_FromCharArrayUTF16Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCharArrayUTF16Node#doNonEmpty}
         *   Parameter: {@link InlinedConditionProfile} utf16CompactProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF16_COMPACT_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromCharArrayUTF16Node_UPDATER.subUpdater(0, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromCharArrayUTF16Node#doNonEmpty}
         *   Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_OUT_OF_MEMORY_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_FromCharArrayUTF16Node_UPDATER.subUpdater(2, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-1: InlinedCache
         *        Specialization: {@link FromCharArrayUTF16Node#doNonEmpty}
         *        Parameter: {@link InlinedConditionProfile} utf16CompactProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   2: InlinedCache
         *        Specialization: {@link FromCharArrayUTF16Node#doNonEmpty}
         *        Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private FromCharArrayUTF16NodeGen() {
        }

        @Override
        public TruffleString execute(char[] arg0Value, int arg1Value, int arg2Value) {
            return doNonEmpty(arg0Value, arg1Value, arg2Value, INLINED_UTF16_COMPACT_PROFILE_, INLINED_OUT_OF_MEMORY_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static FromCharArrayUTF16Node create() {
            return new FromCharArrayUTF16NodeGen();
        }

        @NeverDefault
        public static FromCharArrayUTF16Node getUncached() {
            return FromCharArrayUTF16NodeGen.UNCACHED;
        }

        @GeneratedBy(FromCharArrayUTF16Node.class)
        @DenyReplace
        private static final class Uncached extends FromCharArrayUTF16Node {

            @TruffleBoundary
            @Override
            public TruffleString execute(char[] arg0Value, int arg1Value, int arg2Value) {
                return doNonEmpty(arg0Value, arg1Value, arg2Value, (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link FromJavaStringNode#doUTF16}
     *     Activation probability: 1.00000
     *     With/without class size: 68/47 bytes
     * </pre>
     */
    @GeneratedBy(FromJavaStringNode.class)
    @SuppressWarnings("javadoc")
    static final class FromJavaStringNodeGen extends FromJavaStringNode {

        private static final StateField STATE_0_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        private static final StateField STATE_4_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_4_");
        private static final StateField STATE_5_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_5_");
        private static final StateField STATE_6_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_6_");
        private static final StateField STATE_7_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_7_");
        private static final StateField STATE_8_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_8_");
        private static final StateField STATE_9_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_9_");
        private static final StateField STATE_10_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_10_");
        private static final StateField STATE_11_FromJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_11_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromJavaStringNode#doUTF16}
         *   Parameter: {@link FromJavaStringUTF16Node} fromJavaStringUTF16Node
         *   Inline method: {@link FromJavaStringUTF16NodeGen#inline}</pre>
         */
        private static final FromJavaStringUTF16Node INLINED_FROM_JAVA_STRING_U_T_F16_NODE_ = FromJavaStringUTF16NodeGen.inline(InlineTarget.create(FromJavaStringUTF16Node.class, STATE_0_FromJavaStringNode_UPDATER.subUpdater(0, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromJavaStringNode#doUTF16}
         *   Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *   Inline method: {@link InternalSwitchEncodingNodeGen#inline}</pre>
         */
        private static final InternalSwitchEncodingNode INLINED_SWITCH_ENCODING_NODE_ = InternalSwitchEncodingNodeGen.inline(InlineTarget.create(InternalSwitchEncodingNode.class, STATE_1_FromJavaStringNode_UPDATER.subUpdater(0, 31), STATE_2_FromJavaStringNode_UPDATER.subUpdater(0, 31), STATE_3_FromJavaStringNode_UPDATER.subUpdater(0, 31), STATE_4_FromJavaStringNode_UPDATER.subUpdater(0, 29), STATE_5_FromJavaStringNode_UPDATER.subUpdater(0, 32), STATE_6_FromJavaStringNode_UPDATER.subUpdater(0, 26), STATE_7_FromJavaStringNode_UPDATER.subUpdater(0, 25), STATE_8_FromJavaStringNode_UPDATER.subUpdater(0, 25), STATE_9_FromJavaStringNode_UPDATER.subUpdater(0, 25), STATE_10_FromJavaStringNode_UPDATER.subUpdater(0, 24), STATE_11_FromJavaStringNode_UPDATER.subUpdater(0, 32), STATE_0_FromJavaStringNode_UPDATER.subUpdater(2, 25), ReferenceField.create(MethodHandles.lookup(), "switchEncodingNode__field12_", Node.class)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromJavaStringNode#doUTF16}
         *   Parameter: {@link InlinedConditionProfile} utf16Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF16_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromJavaStringNode_UPDATER.subUpdater(27, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-1: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link FromJavaStringUTF16Node} fromJavaStringUTF16Node
         *        Inline method: {@link FromJavaStringUTF16NodeGen#inline}
         *   2-26: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         *   27-28: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InlinedConditionProfile} utf16Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * State Info: <pre>
         *   0-28: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_4_;
        /**
         * State Info: <pre>
         *   0-31: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_5_;
        /**
         * State Info: <pre>
         *   0-25: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_6_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_7_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_8_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_9_;
        /**
         * State Info: <pre>
         *   0-23: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_10_;
        /**
         * State Info: <pre>
         *   0-31: InlinedCache
         *        Specialization: {@link FromJavaStringNode#doUTF16}
         *        Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_11_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromJavaStringNode#doUTF16}
         *   Parameter: {@link InternalSwitchEncodingNode} switchEncodingNode
         *   Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         *   Inline field: {@link Node} field12</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node switchEncodingNode__field12_;

        private FromJavaStringNodeGen() {
        }

        @Override
        public TruffleString execute(String arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            return doUTF16(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_FROM_JAVA_STRING_U_T_F16_NODE_, INLINED_SWITCH_ENCODING_NODE_, INLINED_UTF16_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static FromJavaStringNode create() {
            return new FromJavaStringNodeGen();
        }

        @NeverDefault
        public static FromJavaStringNode getUncached() {
            return FromJavaStringNodeGen.UNCACHED;
        }

        @GeneratedBy(FromJavaStringNode.class)
        @DenyReplace
        private static final class Uncached extends FromJavaStringNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(String arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
                return doUTF16(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (FromJavaStringUTF16NodeGen.getUncached()), (InternalSwitchEncodingNodeGen.getUncached()), (InlinedConditionProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link FromIntArrayUTF32Node#doNonEmpty}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(FromIntArrayUTF32Node.class)
    @SuppressWarnings("javadoc")
    static final class FromIntArrayUTF32NodeGen extends FromIntArrayUTF32Node {

        private static final StateField STATE_0_FromIntArrayUTF32Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromIntArrayUTF32Node#doNonEmpty}
         *   Parameter: {@link InlinedConditionProfile} utf32Compact0Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_COMPACT0_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromIntArrayUTF32Node_UPDATER.subUpdater(0, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromIntArrayUTF32Node#doNonEmpty}
         *   Parameter: {@link InlinedConditionProfile} utf32Compact1Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_COMPACT1_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_FromIntArrayUTF32Node_UPDATER.subUpdater(2, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link FromIntArrayUTF32Node#doNonEmpty}
         *   Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_OUT_OF_MEMORY_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_FromIntArrayUTF32Node_UPDATER.subUpdater(4, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-1: InlinedCache
         *        Specialization: {@link FromIntArrayUTF32Node#doNonEmpty}
         *        Parameter: {@link InlinedConditionProfile} utf32Compact0Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   2-3: InlinedCache
         *        Specialization: {@link FromIntArrayUTF32Node#doNonEmpty}
         *        Parameter: {@link InlinedConditionProfile} utf32Compact1Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   4: InlinedCache
         *        Specialization: {@link FromIntArrayUTF32Node#doNonEmpty}
         *        Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private FromIntArrayUTF32NodeGen() {
        }

        @Override
        public TruffleString execute(int[] arg0Value, int arg1Value, int arg2Value) {
            return doNonEmpty(arg0Value, arg1Value, arg2Value, INLINED_UTF32_COMPACT0_PROFILE_, INLINED_UTF32_COMPACT1_PROFILE_, INLINED_OUT_OF_MEMORY_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static FromIntArrayUTF32Node create() {
            return new FromIntArrayUTF32NodeGen();
        }

        @NeverDefault
        public static FromIntArrayUTF32Node getUncached() {
            return FromIntArrayUTF32NodeGen.UNCACHED;
        }

        @GeneratedBy(FromIntArrayUTF32Node.class)
        @DenyReplace
        private static final class Uncached extends FromIntArrayUTF32Node {

            @TruffleBoundary
            @Override
            public TruffleString execute(int[] arg0Value, int arg1Value, int arg2Value) {
                return doNonEmpty(arg0Value, arg1Value, arg2Value, (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode#fromNativePointer}
     *     Activation probability: 1.00000
     *     With/without class size: 32/9 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode.class)
    @SuppressWarnings("javadoc")
    static final class FromNativePointerNodeGen extends com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode {

        private static final StateField STATE_0_FromNativePointerNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_FromNativePointerNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode#fromNativePointer}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.FromNativePointerNode} fromNativePointerNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.FromNativePointerNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.FromNativePointerNode INLINED_FROM_NATIVE_POINTER_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.FromNativePointerNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.FromNativePointerNode.class, STATE_0_FromNativePointerNode_UPDATER.subUpdater(1, 14)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode#fromNativePointer}
         *   Parameter: {@link FromBufferWithStringCompactionNode} fromBufferWithStringCompactionNode
         *   Inline method: {@link FromBufferWithStringCompactionNodeGen#inline}</pre>
         */
        private static final FromBufferWithStringCompactionNode INLINED_FROM_BUFFER_WITH_STRING_COMPACTION_NODE_ = FromBufferWithStringCompactionNodeGen.inline(InlineTarget.create(FromBufferWithStringCompactionNode.class, STATE_1_FromNativePointerNode_UPDATER.subUpdater(0, 20)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode#fromNativePointer}
         *   1-14: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode#fromNativePointer}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.FromNativePointerNode} fromNativePointerNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.FromNativePointerNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-19: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode#fromNativePointer}
         *        Parameter: {@link FromBufferWithStringCompactionNode} fromBufferWithStringCompactionNode
         *        Inline method: {@link FromBufferWithStringCompactionNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode#fromNativePointer}
         *   Parameter: {@link Node} interopLibrary</pre>
         */
        @Child private Node interopLibrary_;

        private FromNativePointerNodeGen() {
        }

        @Override
        public TruffleString execute(Object arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.FromNativePointerNode.fromNativePointer(Object, int, int, Encoding, boolean, Node, FromNativePointerNode, FromBufferWithStringCompactionNode)] */) {
                {
                    Node interopLibrary__ = this.interopLibrary_;
                    if (interopLibrary__ != null) {
                        return fromNativePointer(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, interopLibrary__, INLINED_FROM_NATIVE_POINTER_NODE_, INLINED_FROM_BUFFER_WITH_STRING_COMPACTION_NODE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
        }

        private TruffleString executeAndSpecialize(Object arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            int state_0 = this.state_0_;
            Node interopLibrary__ = this.insert((TStringAccessor.createInteropLibrary()));
            Objects.requireNonNull(interopLibrary__, "Specialization 'fromNativePointer(Object, int, int, Encoding, boolean, Node, FromNativePointerNode, FromBufferWithStringCompactionNode)' cache 'interopLibrary' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.interopLibrary_ = interopLibrary__;
            state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.FromNativePointerNode.fromNativePointer(Object, int, int, Encoding, boolean, Node, FromNativePointerNode, FromBufferWithStringCompactionNode)] */;
            this.state_0_ = state_0;
            return fromNativePointer(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, interopLibrary__, INLINED_FROM_NATIVE_POINTER_NODE_, INLINED_FROM_BUFFER_WITH_STRING_COMPACTION_NODE_);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.FromNativePointerNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode getUncached() {
            return FromNativePointerNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.FromNativePointerNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(Object arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
                return fromNativePointer(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (TStringAccessor.getUncachedInteropLibrary()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.FromNativePointerNodeGen.getUncached()), (FromBufferWithStringCompactionNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AsTruffleStringNode#doDefault}
     *     Activation probability: 1.00000
     *     With/without class size: 28/8 bytes
     * </pre>
     */
    @GeneratedBy(AsTruffleStringNode.class)
    @SuppressWarnings("javadoc")
    static final class AsTruffleStringNodeGen extends AsTruffleStringNode {

        private static final StateField STATE_0_AsTruffleStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_AsTruffleStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsTruffleStringNode#doDefault}
         *   Parameter: {@link InternalAsTruffleStringNode} internalNode
         *   Inline method: {@link InternalAsTruffleStringNodeGen#inline}</pre>
         */
        private static final InternalAsTruffleStringNode INLINED_INTERNAL_NODE_ = InternalAsTruffleStringNodeGen.inline(InlineTarget.create(InternalAsTruffleStringNode.class, STATE_0_AsTruffleStringNode_UPDATER.subUpdater(0, 31), STATE_1_AsTruffleStringNode_UPDATER.subUpdater(0, 31)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link AsTruffleStringNode#doDefault}
         *        Parameter: {@link InternalAsTruffleStringNode} internalNode
         *        Inline method: {@link InternalAsTruffleStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link AsTruffleStringNode#doDefault}
         *        Parameter: {@link InternalAsTruffleStringNode} internalNode
         *        Inline method: {@link InternalAsTruffleStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;

        private AsTruffleStringNodeGen() {
        }

        @Override
        public TruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return doDefault(arg0Value, arg1Value, INLINED_INTERNAL_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static AsTruffleStringNode create() {
            return new AsTruffleStringNodeGen();
        }

        @NeverDefault
        public static AsTruffleStringNode getUncached() {
            return AsTruffleStringNodeGen.UNCACHED;
        }

        @GeneratedBy(AsTruffleStringNode.class)
        @DenyReplace
        private static final class Uncached extends AsTruffleStringNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return doDefault(arg0Value, arg1Value, (InternalAsTruffleStringNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link InternalAsTruffleStringNode#immutable}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link InternalAsTruffleStringNode#fromMutableString}
     *     Activation probability: 0.35000
     *     With/without class size: 12/8 bytes
     * </pre>
     */
    @GeneratedBy(InternalAsTruffleStringNode.class)
    @SuppressWarnings("javadoc")
    static final class InternalAsTruffleStringNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static InternalAsTruffleStringNode getUncached() {
            return InternalAsTruffleStringNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * <li>{@link Inlined#state_1_}
         * </ul>
         */
        @NeverDefault
        public static InternalAsTruffleStringNode inline(@RequiredField(bits = 31, value = StateField.class)@RequiredField(bits = 31, value = StateField.class) InlineTarget target) {
            return new InternalAsTruffleStringNodeGen.Inlined(target);
        }

        @GeneratedBy(InternalAsTruffleStringNode.class)
        @DenyReplace
        private static final class Inlined extends InternalAsTruffleStringNode {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link InternalAsTruffleStringNode#immutable}
             *   1: SpecializationActive {@link InternalAsTruffleStringNode#fromMutableString}
             *   2-30: InlinedCache
             *        Specialization: {@link InternalAsTruffleStringNode#fromMutableString}
             *        Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} fromBufferWithStringCompactionNode
             *        Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * State Info: <pre>
             *   0-30: InlinedCache
             *        Specialization: {@link InternalAsTruffleStringNode#fromMutableString}
             *        Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} fromBufferWithStringCompactionNode
             *        Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}
             * </pre>
             */
            private final StateField state_1_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalAsTruffleStringNode#fromMutableString}
             *   Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} fromBufferWithStringCompactionNode
             *   Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}</pre>
             */
            private final FromBufferWithStringCompactionKnownAttributesNode fromMutableString_fromBufferWithStringCompactionNode_;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(InternalAsTruffleStringNode.class);
                this.state_0_ = target.getState(0, 31);
                this.state_1_ = target.getState(1, 31);
                this.fromMutableString_fromBufferWithStringCompactionNode_ = FromBufferWithStringCompactionKnownAttributesNodeGen.inline(InlineTarget.create(FromBufferWithStringCompactionKnownAttributesNode.class, state_1_.subUpdater(0, 31), state_0_.subUpdater(2, 29)));
            }

            @Override
            TruffleString execute(Node arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.InternalAsTruffleStringNode.immutable(TruffleString, Encoding)] || SpecializationActive[TruffleString.InternalAsTruffleStringNode.fromMutableString(Node, MutableTruffleString, Encoding, FromBufferWithStringCompactionKnownAttributesNode)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.InternalAsTruffleStringNode.immutable(TruffleString, Encoding)] */ && arg1Value instanceof TruffleString) {
                        TruffleString arg1Value_ = (TruffleString) arg1Value;
                        return InternalAsTruffleStringNode.immutable(arg1Value_, arg2Value);
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.InternalAsTruffleStringNode.fromMutableString(Node, MutableTruffleString, Encoding, FromBufferWithStringCompactionKnownAttributesNode)] */ && arg1Value instanceof MutableTruffleString) {
                        MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                        assert InlineSupport.validate(arg0Value, this.state_1_, this.state_0_);
                        return InternalAsTruffleStringNode.fromMutableString(arg0Value, arg1Value_, arg2Value, this.fromMutableString_fromBufferWithStringCompactionNode_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
            }

            private TruffleString executeAndSpecialize(Node arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if (arg1Value instanceof TruffleString) {
                    TruffleString arg1Value_ = (TruffleString) arg1Value;
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.InternalAsTruffleStringNode.immutable(TruffleString, Encoding)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return InternalAsTruffleStringNode.immutable(arg1Value_, arg2Value);
                }
                if (arg1Value instanceof MutableTruffleString) {
                    MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.InternalAsTruffleStringNode.fromMutableString(Node, MutableTruffleString, Encoding, FromBufferWithStringCompactionKnownAttributesNode)] */;
                    this.state_0_.set(arg0Value, state_0);
                    assert InlineSupport.validate(arg0Value, this.state_1_, this.state_0_);
                    return InternalAsTruffleStringNode.fromMutableString(arg0Value, arg1Value_, arg2Value, this.fromMutableString_fromBufferWithStringCompactionNode_);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(InternalAsTruffleStringNode.class)
        @DenyReplace
        private static final class Uncached extends InternalAsTruffleStringNode {

            @TruffleBoundary
            @Override
            TruffleString execute(Node arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
                if (arg1Value instanceof TruffleString) {
                    TruffleString arg1Value_ = (TruffleString) arg1Value;
                    return InternalAsTruffleStringNode.immutable(arg1Value_, arg2Value);
                }
                if (arg1Value instanceof MutableTruffleString) {
                    MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                    return InternalAsTruffleStringNode.fromMutableString(arg0Value, arg1Value_, arg2Value, (FromBufferWithStringCompactionKnownAttributesNode.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AsManagedNode#managedImmutable}
     *     Activation probability: 0.48333
     *     With/without class size: 9/0 bytes
     *   Specialization {@link AsManagedNode#nativeImmutable}
     *     Activation probability: 0.33333
     *     With/without class size: 10/1 bytes
     *   Specialization {@link AsManagedNode#mutable}
     *     Activation probability: 0.18333
     *     With/without class size: 6/0 bytes
     * </pre>
     */
    @GeneratedBy(AsManagedNode.class)
    @SuppressWarnings("javadoc")
    static final class AsManagedNodeGen extends AsManagedNode {

        private static final StateField STATE_1_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_0_AsManagedNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsManagedNode#nativeImmutable}
         *   Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} attributesNode
         *   Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}</pre>
         */
        private static final FromBufferWithStringCompactionKnownAttributesNode INLINED_ATTRIBUTES_NODE = FromBufferWithStringCompactionKnownAttributesNodeGen.inline(InlineTarget.create(FromBufferWithStringCompactionKnownAttributesNode.class, STATE_1_UPDATER.subUpdater(0, 31), STATE_2_UPDATER.subUpdater(0, 29)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsManagedNode#nativeImmutable}
         *   Parameter: {@link InlinedConditionProfile} cacheHit
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_NATIVE_IMMUTABLE_CACHE_HIT_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_AsManagedNode_UPDATER.subUpdater(3, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AsManagedNode#managedImmutable}
         *   1: SpecializationActive {@link AsManagedNode#nativeImmutable}
         *   2: SpecializationActive {@link AsManagedNode#mutable}
         *   3-4: InlinedCache
         *        Specialization: {@link AsManagedNode#nativeImmutable}
         *        Parameter: {@link InlinedConditionProfile} cacheHit
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link AsManagedNode#nativeImmutable}
         *        Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} attributesNode
         *        Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-28: InlinedCache
         *        Specialization: {@link AsManagedNode#nativeImmutable}
         *        Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} attributesNode
         *        Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;

        private AsManagedNodeGen() {
        }

        @Override
        public TruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, boolean arg2Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b111) != 0 /* is SpecializationActive[TruffleString.AsManagedNode.managedImmutable(TruffleString, Encoding, boolean)] || SpecializationActive[TruffleString.AsManagedNode.nativeImmutable(TruffleString, Encoding, boolean, InlinedConditionProfile, FromBufferWithStringCompactionKnownAttributesNode)] || SpecializationActive[TruffleString.AsManagedNode.mutable(MutableTruffleString, Encoding, boolean, FromBufferWithStringCompactionKnownAttributesNode)] */) {
                if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.AsManagedNode.managedImmutable(TruffleString, Encoding, boolean)] || SpecializationActive[TruffleString.AsManagedNode.nativeImmutable(TruffleString, Encoding, boolean, InlinedConditionProfile, FromBufferWithStringCompactionKnownAttributesNode)] */ && arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.AsManagedNode.managedImmutable(TruffleString, Encoding, boolean)] */) {
                        if ((!(arg0Value_.isNative()))) {
                            return AsManagedNode.managedImmutable(arg0Value_, arg1Value, arg2Value);
                        }
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.AsManagedNode.nativeImmutable(TruffleString, Encoding, boolean, InlinedConditionProfile, FromBufferWithStringCompactionKnownAttributesNode)] */) {
                        if ((arg0Value_.isNative())) {
                            return nativeImmutable(arg0Value_, arg1Value, arg2Value, INLINED_NATIVE_IMMUTABLE_CACHE_HIT_, INLINED_ATTRIBUTES_NODE);
                        }
                    }
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleString.AsManagedNode.mutable(MutableTruffleString, Encoding, boolean, FromBufferWithStringCompactionKnownAttributesNode)] */ && arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    return mutable(arg0Value_, arg1Value, arg2Value, INLINED_ATTRIBUTES_NODE);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private TruffleString executeAndSpecialize(AbstractTruffleString arg0Value, Encoding arg1Value, boolean arg2Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof TruffleString) {
                TruffleString arg0Value_ = (TruffleString) arg0Value;
                if ((!(arg0Value_.isNative()))) {
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.AsManagedNode.managedImmutable(TruffleString, Encoding, boolean)] */;
                    this.state_0_ = state_0;
                    return AsManagedNode.managedImmutable(arg0Value_, arg1Value, arg2Value);
                }
                if ((arg0Value_.isNative())) {
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.AsManagedNode.nativeImmutable(TruffleString, Encoding, boolean, InlinedConditionProfile, FromBufferWithStringCompactionKnownAttributesNode)] */;
                    this.state_0_ = state_0;
                    return nativeImmutable(arg0Value_, arg1Value, arg2Value, INLINED_NATIVE_IMMUTABLE_CACHE_HIT_, INLINED_ATTRIBUTES_NODE);
                }
            }
            if (arg0Value instanceof MutableTruffleString) {
                MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleString.AsManagedNode.mutable(MutableTruffleString, Encoding, boolean, FromBufferWithStringCompactionKnownAttributesNode)] */;
                this.state_0_ = state_0;
                return mutable(arg0Value_, arg1Value, arg2Value, INLINED_ATTRIBUTES_NODE);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b111) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount((state_0 & 0b111));
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static AsManagedNode create() {
            return new AsManagedNodeGen();
        }

        @NeverDefault
        public static AsManagedNode getUncached() {
            return AsManagedNodeGen.UNCACHED;
        }

        @GeneratedBy(AsManagedNode.class)
        @DenyReplace
        private static final class Uncached extends AsManagedNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, boolean arg2Value) {
                if (arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    if ((!(arg0Value_.isNative()))) {
                        return AsManagedNode.managedImmutable(arg0Value_, arg1Value, arg2Value);
                    }
                    if ((arg0Value_.isNative())) {
                        return nativeImmutable(arg0Value_, arg1Value, arg2Value, (InlinedConditionProfile.getUncached()), (FromBufferWithStringCompactionKnownAttributesNode.getUncached()));
                    }
                }
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    return mutable(arg0Value_, arg1Value, arg2Value, (FromBufferWithStringCompactionKnownAttributesNode.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ToIndexableNode#doByteArray}
     *     Activation probability: 0.32000
     *     With/without class size: 7/0 bytes
     *   Specialization {@link ToIndexableNode#doNativeSupported}
     *     Activation probability: 0.26000
     *     With/without class size: 7/0 bytes
     *   Specialization {@link ToIndexableNode#doNativeUnsupported}
     *     Activation probability: 0.20000
     *     With/without class size: 7/0 bytes
     *   Specialization {@link ToIndexableNode#doLazyConcat}
     *     Activation probability: 0.14000
     *     With/without class size: 5/0 bytes
     *   Specialization {@link ToIndexableNode#doLazyLong}
     *     Activation probability: 0.08000
     *     With/without class size: 5/0 bytes
     * </pre>
     */
    @GeneratedBy(ToIndexableNode.class)
    @SuppressWarnings("javadoc")
    static final class ToIndexableNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static ToIndexableNode getUncached() {
            return ToIndexableNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * </ul>
         */
        @NeverDefault
        public static ToIndexableNode inline(@RequiredField(bits = 7, value = StateField.class) InlineTarget target) {
            return new ToIndexableNodeGen.Inlined(target);
        }

        @GeneratedBy(ToIndexableNode.class)
        @DenyReplace
        private static final class Inlined extends ToIndexableNode {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link ToIndexableNode#doByteArray}
             *   1: SpecializationActive {@link ToIndexableNode#doNativeSupported}
             *   2: SpecializationActive {@link ToIndexableNode#doNativeUnsupported}
             *   3: SpecializationActive {@link ToIndexableNode#doLazyConcat}
             *   4: SpecializationActive {@link ToIndexableNode#doLazyLong}
             *   5-6: InlinedCache
             *        Specialization: {@link ToIndexableNode#doNativeUnsupported}
             *        Parameter: {@link InlinedConditionProfile} materializeProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ToIndexableNode#doNativeUnsupported}
             *   Parameter: {@link InlinedConditionProfile} materializeProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile materializeProfile;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(ToIndexableNode.class);
                this.state_0_ = target.getState(0, 7);
                this.materializeProfile = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(5, 2)));
            }

            @Override
            Object execute(Node arg0Value, AbstractTruffleString arg1Value, Object arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((state_0 & 0b11111) != 0 /* is SpecializationActive[TruffleString.ToIndexableNode.doByteArray(AbstractTruffleString, byte[])] || SpecializationActive[TruffleString.ToIndexableNode.doNativeSupported(AbstractTruffleString, NativePointer)] || SpecializationActive[TruffleString.ToIndexableNode.doNativeUnsupported(Node, AbstractTruffleString, NativePointer, InlinedConditionProfile)] || SpecializationActive[TruffleString.ToIndexableNode.doLazyConcat(AbstractTruffleString, LazyConcat)] || SpecializationActive[TruffleString.ToIndexableNode.doLazyLong(Node, AbstractTruffleString, LazyLong, InlinedConditionProfile)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.ToIndexableNode.doByteArray(AbstractTruffleString, byte[])] */ && arg2Value instanceof byte[]) {
                        byte[] arg2Value_ = (byte[]) arg2Value;
                        return ToIndexableNode.doByteArray(arg1Value, arg2Value_);
                    }
                    if ((state_0 & 0b110) != 0 /* is SpecializationActive[TruffleString.ToIndexableNode.doNativeSupported(AbstractTruffleString, NativePointer)] || SpecializationActive[TruffleString.ToIndexableNode.doNativeUnsupported(Node, AbstractTruffleString, NativePointer, InlinedConditionProfile)] */ && arg2Value instanceof NativePointer) {
                        NativePointer arg2Value_ = (NativePointer) arg2Value;
                        if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.ToIndexableNode.doNativeSupported(AbstractTruffleString, NativePointer)] */) {
                            if ((TStringGuards.isSupportedEncoding(arg1Value.encoding()))) {
                                return ToIndexableNode.doNativeSupported(arg1Value, arg2Value_);
                            }
                        }
                        if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleString.ToIndexableNode.doNativeUnsupported(Node, AbstractTruffleString, NativePointer, InlinedConditionProfile)] */) {
                            if ((!(TStringGuards.isSupportedEncoding(arg1Value.encoding())))) {
                                return ToIndexableNode.doNativeUnsupported(arg0Value, arg1Value, arg2Value_, this.materializeProfile);
                            }
                        }
                    }
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleString.ToIndexableNode.doLazyConcat(AbstractTruffleString, LazyConcat)] */ && arg2Value instanceof LazyConcat) {
                        LazyConcat arg2Value_ = (LazyConcat) arg2Value;
                        return doLazyConcat(arg1Value, arg2Value_);
                    }
                    if ((state_0 & 0b10000) != 0 /* is SpecializationActive[TruffleString.ToIndexableNode.doLazyLong(Node, AbstractTruffleString, LazyLong, InlinedConditionProfile)] */ && arg2Value instanceof LazyLong) {
                        LazyLong arg2Value_ = (LazyLong) arg2Value;
                        return ToIndexableNode.doLazyLong(arg0Value, arg1Value, arg2Value_, this.materializeProfile);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
            }

            private Object executeAndSpecialize(Node arg0Value, AbstractTruffleString arg1Value, Object arg2Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if (arg2Value instanceof byte[]) {
                    byte[] arg2Value_ = (byte[]) arg2Value;
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.ToIndexableNode.doByteArray(AbstractTruffleString, byte[])] */;
                    this.state_0_.set(arg0Value, state_0);
                    return ToIndexableNode.doByteArray(arg1Value, arg2Value_);
                }
                if (arg2Value instanceof NativePointer) {
                    NativePointer arg2Value_ = (NativePointer) arg2Value;
                    if ((TStringGuards.isSupportedEncoding(arg1Value.encoding()))) {
                        state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.ToIndexableNode.doNativeSupported(AbstractTruffleString, NativePointer)] */;
                        this.state_0_.set(arg0Value, state_0);
                        return ToIndexableNode.doNativeSupported(arg1Value, arg2Value_);
                    }
                    if ((!(TStringGuards.isSupportedEncoding(arg1Value.encoding())))) {
                        state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleString.ToIndexableNode.doNativeUnsupported(Node, AbstractTruffleString, NativePointer, InlinedConditionProfile)] */;
                        this.state_0_.set(arg0Value, state_0);
                        return ToIndexableNode.doNativeUnsupported(arg0Value, arg1Value, arg2Value_, this.materializeProfile);
                    }
                }
                if (arg2Value instanceof LazyConcat) {
                    LazyConcat arg2Value_ = (LazyConcat) arg2Value;
                    state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleString.ToIndexableNode.doLazyConcat(AbstractTruffleString, LazyConcat)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return doLazyConcat(arg1Value, arg2Value_);
                }
                if (arg2Value instanceof LazyLong) {
                    LazyLong arg2Value_ = (LazyLong) arg2Value;
                    state_0 = state_0 | 0b10000 /* add SpecializationActive[TruffleString.ToIndexableNode.doLazyLong(Node, AbstractTruffleString, LazyLong, InlinedConditionProfile)] */;
                    this.state_0_.set(arg0Value, state_0);
                    return ToIndexableNode.doLazyLong(arg0Value, arg1Value, arg2Value_, this.materializeProfile);
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(ToIndexableNode.class)
        @DenyReplace
        private static final class Uncached extends ToIndexableNode {

            @TruffleBoundary
            @Override
            Object execute(Node arg0Value, AbstractTruffleString arg1Value, Object arg2Value) {
                if (arg2Value instanceof byte[]) {
                    byte[] arg2Value_ = (byte[]) arg2Value;
                    return ToIndexableNode.doByteArray(arg1Value, arg2Value_);
                }
                if (arg2Value instanceof NativePointer) {
                    NativePointer arg2Value_ = (NativePointer) arg2Value;
                    if ((TStringGuards.isSupportedEncoding(arg1Value.encoding()))) {
                        return ToIndexableNode.doNativeSupported(arg1Value, arg2Value_);
                    }
                    if ((!(TStringGuards.isSupportedEncoding(arg1Value.encoding())))) {
                        return ToIndexableNode.doNativeUnsupported(arg0Value, arg1Value, arg2Value_, (InlinedConditionProfile.getUncached()));
                    }
                }
                if (arg2Value instanceof LazyConcat) {
                    LazyConcat arg2Value_ = (LazyConcat) arg2Value;
                    return doLazyConcat(arg1Value, arg2Value_);
                }
                if (arg2Value instanceof LazyLong) {
                    LazyLong arg2Value_ = (LazyLong) arg2Value;
                    return ToIndexableNode.doLazyLong(arg0Value, arg1Value, arg2Value_, (InlinedConditionProfile.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link MaterializeNode#doMaterialize}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(MaterializeNode.class)
    @SuppressWarnings("javadoc")
    static final class MaterializeNodeGen extends MaterializeNode {

        private static final StateField STATE_0_MaterializeNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link MaterializeNode#doMaterialize}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_MaterializeNode_UPDATER.subUpdater(0, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link MaterializeNode#doMaterialize}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private MaterializeNodeGen() {
        }

        @Override
        public void execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            doMaterialize(arg0Value, arg1Value, INLINED_TO_INDEXABLE_NODE_);
            return;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static MaterializeNode create() {
            return new MaterializeNodeGen();
        }

        @NeverDefault
        public static MaterializeNode getUncached() {
            return MaterializeNodeGen.UNCACHED;
        }

        @GeneratedBy(MaterializeNode.class)
        @DenyReplace
        private static final class Uncached extends MaterializeNode {

            @TruffleBoundary
            @Override
            public void execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                doMaterialize(arg0Value, arg1Value, (ToIndexableNodeGen.getUncached()));
                return;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link GetCodeRangeNode#getCodeRange}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(GetCodeRangeNode.class)
    @SuppressWarnings("javadoc")
    static final class GetCodeRangeNodeGen extends GetCodeRangeNode {

        private static final StateField STATE_0_GetCodeRangeNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetCodeRangeNode#getCodeRange}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_GET_PRECISE_CODE_RANGE_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_0_GetCodeRangeNode_UPDATER.subUpdater(0, 25)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link GetCodeRangeNode#getCodeRange}
         *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private GetCodeRangeNodeGen() {
        }

        @Override
        public CodeRange execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return getCodeRange(arg0Value, arg1Value, INLINED_GET_PRECISE_CODE_RANGE_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static GetCodeRangeNode create() {
            return new GetCodeRangeNodeGen();
        }

        @NeverDefault
        public static GetCodeRangeNode getUncached() {
            return GetCodeRangeNodeGen.UNCACHED;
        }

        @GeneratedBy(GetCodeRangeNode.class)
        @DenyReplace
        private static final class Uncached extends GetCodeRangeNode {

            @TruffleBoundary
            @Override
            public CodeRange execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return getCodeRange(arg0Value, arg1Value, (GetPreciseCodeRangeNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link GetCodeRangeImpreciseNode#getCodeRange}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(GetCodeRangeImpreciseNode.class)
    @SuppressWarnings("javadoc")
    static final class GetCodeRangeImpreciseNodeGen extends GetCodeRangeImpreciseNode {

        private static final Uncached UNCACHED = new Uncached();

        private GetCodeRangeImpreciseNodeGen() {
        }

        @Override
        public CodeRange execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return GetCodeRangeImpreciseNode.getCodeRange(arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static GetCodeRangeImpreciseNode create() {
            return new GetCodeRangeImpreciseNodeGen();
        }

        @NeverDefault
        public static GetCodeRangeImpreciseNode getUncached() {
            return GetCodeRangeImpreciseNodeGen.UNCACHED;
        }

        @GeneratedBy(GetCodeRangeImpreciseNode.class)
        @DenyReplace
        private static final class Uncached extends GetCodeRangeImpreciseNode {

            @TruffleBoundary
            @Override
            public CodeRange execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return GetCodeRangeImpreciseNode.getCodeRange(arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link GetByteCodeRangeNode#getCodeRange}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(GetByteCodeRangeNode.class)
    @SuppressWarnings("javadoc")
    static final class GetByteCodeRangeNodeGen extends GetByteCodeRangeNode {

        private static final StateField STATE_0_GetByteCodeRangeNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetByteCodeRangeNode#getCodeRange}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_GET_PRECISE_CODE_RANGE_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_0_GetByteCodeRangeNode_UPDATER.subUpdater(0, 25)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link GetByteCodeRangeNode#getCodeRange}
         *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private GetByteCodeRangeNodeGen() {
        }

        @Override
        public CodeRange execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return getCodeRange(arg0Value, arg1Value, INLINED_GET_PRECISE_CODE_RANGE_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static GetByteCodeRangeNode create() {
            return new GetByteCodeRangeNodeGen();
        }

        @NeverDefault
        public static GetByteCodeRangeNode getUncached() {
            return GetByteCodeRangeNodeGen.UNCACHED;
        }

        @GeneratedBy(GetByteCodeRangeNode.class)
        @DenyReplace
        private static final class Uncached extends GetByteCodeRangeNode {

            @TruffleBoundary
            @Override
            public CodeRange execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return getCodeRange(arg0Value, arg1Value, (GetPreciseCodeRangeNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CodeRangeEqualsNode#codeRangeEquals}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(CodeRangeEqualsNode.class)
    @SuppressWarnings("javadoc")
    static final class CodeRangeEqualsNodeGen extends CodeRangeEqualsNode {

        private static final StateField STATE_0_CodeRangeEqualsNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodeRangeEqualsNode#codeRangeEquals}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_GET_PRECISE_CODE_RANGE_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_0_CodeRangeEqualsNode_UPDATER.subUpdater(0, 25)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link CodeRangeEqualsNode#codeRangeEquals}
         *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private CodeRangeEqualsNodeGen() {
        }

        @Override
        public boolean execute(AbstractTruffleString arg0Value, CodeRange arg1Value) {
            return codeRangeEquals(arg0Value, arg1Value, INLINED_GET_PRECISE_CODE_RANGE_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CodeRangeEqualsNode create() {
            return new CodeRangeEqualsNodeGen();
        }

        @NeverDefault
        public static CodeRangeEqualsNode getUncached() {
            return CodeRangeEqualsNodeGen.UNCACHED;
        }

        @GeneratedBy(CodeRangeEqualsNode.class)
        @DenyReplace
        private static final class Uncached extends CodeRangeEqualsNode {

            @TruffleBoundary
            @Override
            public boolean execute(AbstractTruffleString arg0Value, CodeRange arg1Value) {
                return codeRangeEquals(arg0Value, arg1Value, (GetPreciseCodeRangeNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IsValidNode#isValid}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(IsValidNode.class)
    @SuppressWarnings("javadoc")
    static final class IsValidNodeGen extends IsValidNode {

        private static final StateField STATE_0_IsValidNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IsValidNode#isValid}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_GET_PRECISE_CODE_RANGE_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_0_IsValidNode_UPDATER.subUpdater(0, 25)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link IsValidNode#isValid}
         *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IsValidNodeGen() {
        }

        @Override
        public boolean execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return isValid(arg0Value, arg1Value, INLINED_GET_PRECISE_CODE_RANGE_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IsValidNode create() {
            return new IsValidNodeGen();
        }

        @NeverDefault
        public static IsValidNode getUncached() {
            return IsValidNodeGen.UNCACHED;
        }

        @GeneratedBy(IsValidNode.class)
        @DenyReplace
        private static final class Uncached extends IsValidNode {

            @TruffleBoundary
            @Override
            public boolean execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return isValid(arg0Value, arg1Value, (GetPreciseCodeRangeNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link GetStringCompactionLevelNode#getStringCompactionLevel}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(GetStringCompactionLevelNode.class)
    @SuppressWarnings("javadoc")
    static final class GetStringCompactionLevelNodeGen extends GetStringCompactionLevelNode {

        private static final Uncached UNCACHED = new Uncached();

        private GetStringCompactionLevelNodeGen() {
        }

        @Override
        public CompactionLevel execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return GetStringCompactionLevelNode.getStringCompactionLevel(arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static GetStringCompactionLevelNode create() {
            return new GetStringCompactionLevelNodeGen();
        }

        @NeverDefault
        public static GetStringCompactionLevelNode getUncached() {
            return GetStringCompactionLevelNodeGen.UNCACHED;
        }

        @GeneratedBy(GetStringCompactionLevelNode.class)
        @DenyReplace
        private static final class Uncached extends GetStringCompactionLevelNode {

            @TruffleBoundary
            @Override
            public CompactionLevel execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return GetStringCompactionLevelNode.getStringCompactionLevel(arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CodePointLengthNode#get}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(CodePointLengthNode.class)
    @SuppressWarnings("javadoc")
    static final class CodePointLengthNodeGen extends CodePointLengthNode {

        private static final StateField STATE_0_CodePointLengthNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointLengthNode#get}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_0_CodePointLengthNode_UPDATER.subUpdater(0, 25)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link CodePointLengthNode#get}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private CodePointLengthNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return get(arg0Value, arg1Value, INLINED_GET_CODE_POINT_LENGTH_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CodePointLengthNode create() {
            return new CodePointLengthNodeGen();
        }

        @NeverDefault
        public static CodePointLengthNode getUncached() {
            return CodePointLengthNodeGen.UNCACHED;
        }

        @GeneratedBy(CodePointLengthNode.class)
        @DenyReplace
        private static final class Uncached extends CodePointLengthNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return get(arg0Value, arg1Value, (GetCodePointLengthNode.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link HashCodeNode#calculateHash}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(HashCodeNode.class)
    @SuppressWarnings("javadoc")
    static final class HashCodeNodeGen extends HashCodeNode {

        private static final StateField STATE_0_HashCodeNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link HashCodeNode#calculateHash}
         *   Parameter: {@link InlinedConditionProfile} cacheMiss
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_CACHE_MISS_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_HashCodeNode_UPDATER.subUpdater(0, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link HashCodeNode#calculateHash}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_HashCodeNode_UPDATER.subUpdater(2, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link HashCodeNode#calculateHash}
         *   Parameter: {@link CalculateHashCodeNode} calculateHashCodeNode
         *   Inline method: {@link CalculateHashCodeNodeGen#inline}</pre>
         */
        private static final CalculateHashCodeNode INLINED_CALCULATE_HASH_CODE_NODE_ = CalculateHashCodeNodeGen.inline(InlineTarget.create(CalculateHashCodeNode.class, STATE_0_HashCodeNode_UPDATER.subUpdater(9, 12)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-1: InlinedCache
         *        Specialization: {@link HashCodeNode#calculateHash}
         *        Parameter: {@link InlinedConditionProfile} cacheMiss
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   2-8: InlinedCache
         *        Specialization: {@link HashCodeNode#calculateHash}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   9-20: InlinedCache
         *        Specialization: {@link HashCodeNode#calculateHash}
         *        Parameter: {@link CalculateHashCodeNode} calculateHashCodeNode
         *        Inline method: {@link CalculateHashCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private HashCodeNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return calculateHash(arg0Value, arg1Value, INLINED_CACHE_MISS_, INLINED_TO_INDEXABLE_NODE_, INLINED_CALCULATE_HASH_CODE_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static HashCodeNode create() {
            return new HashCodeNodeGen();
        }

        @NeverDefault
        public static HashCodeNode getUncached() {
            return HashCodeNodeGen.UNCACHED;
        }

        @GeneratedBy(HashCodeNode.class)
        @DenyReplace
        private static final class Uncached extends HashCodeNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return calculateHash(arg0Value, arg1Value, (InlinedConditionProfile.getUncached()), (ToIndexableNodeGen.getUncached()), (CalculateHashCodeNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.ReadByteNode#doRead}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ReadByteNode.class)
    @SuppressWarnings("javadoc")
    static final class ReadByteNodeGen extends com.oracle.truffle.api.strings.TruffleString.ReadByteNode {

        private static final StateField STATE_0_ReadByteNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ReadByteNode#doRead}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ReadByteNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ReadByteNode#doRead}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ReadByteNode} readByteNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ReadByteNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.ReadByteNode INLINED_READ_BYTE_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.ReadByteNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.ReadByteNode.class, STATE_0_ReadByteNode_UPDATER.subUpdater(7, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ReadByteNode#doRead}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ReadByteNode#doRead}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ReadByteNode} readByteNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ReadByteNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private ReadByteNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value) {
            return doRead(arg0Value, arg1Value, arg2Value, INLINED_TO_INDEXABLE_NODE_, INLINED_READ_BYTE_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ReadByteNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.ReadByteNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ReadByteNode getUncached() {
            return ReadByteNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ReadByteNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.ReadByteNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value) {
                return doRead(arg0Value, arg1Value, arg2Value, (ToIndexableNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.ReadByteNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ReadCharUTF16Node#doRead}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(ReadCharUTF16Node.class)
    @SuppressWarnings("javadoc")
    static final class ReadCharUTF16NodeGen extends ReadCharUTF16Node {

        private static final StateField STATE_0_ReadCharUTF16Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ReadCharUTF16Node#doRead}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ReadCharUTF16Node_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ReadCharUTF16Node#doRead}
         *   Parameter: {@link InlinedConditionProfile} utf16S0Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF16_S0_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_ReadCharUTF16Node_UPDATER.subUpdater(7, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link ReadCharUTF16Node#doRead}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-8: InlinedCache
         *        Specialization: {@link ReadCharUTF16Node#doRead}
         *        Parameter: {@link InlinedConditionProfile} utf16S0Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private ReadCharUTF16NodeGen() {
        }

        @Override
        public char execute(AbstractTruffleString arg0Value, int arg1Value) {
            return doRead(arg0Value, arg1Value, INLINED_TO_INDEXABLE_NODE_, INLINED_UTF16_S0_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static ReadCharUTF16Node create() {
            return new ReadCharUTF16NodeGen();
        }

        @NeverDefault
        public static ReadCharUTF16Node getUncached() {
            return ReadCharUTF16NodeGen.UNCACHED;
        }

        @GeneratedBy(ReadCharUTF16Node.class)
        @DenyReplace
        private static final class Uncached extends ReadCharUTF16Node {

            @TruffleBoundary
            @Override
            public char execute(AbstractTruffleString arg0Value, int arg1Value) {
                return doRead(arg0Value, arg1Value, (ToIndexableNodeGen.getUncached()), (InlinedConditionProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode#translate}
     *     Activation probability: 1.00000
     *     With/without class size: 28/8 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode.class)
    @SuppressWarnings("javadoc")
    static final class ByteLengthOfCodePointNodeGen extends com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode {

        private static final StateField STATE_0_ByteLengthOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_ByteLengthOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode#translate}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ByteLengthOfCodePointNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode#translate}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_ByteLengthOfCodePointNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode#translate}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ByteLengthOfCodePointNode} byteLengthOfCodePointNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ByteLengthOfCodePointNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.ByteLengthOfCodePointNode INLINED_BYTE_LENGTH_OF_CODE_POINT_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.ByteLengthOfCodePointNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.ByteLengthOfCodePointNode.class, STATE_1_ByteLengthOfCodePointNode_UPDATER.subUpdater(0, 27)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode#translate}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode#translate}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-26: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode#translate}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ByteLengthOfCodePointNode} byteLengthOfCodePointNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ByteLengthOfCodePointNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;

        private ByteLengthOfCodePointNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value, ErrorHandling arg3Value) {
            return translate(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_BYTE_LENGTH_OF_CODE_POINT_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.ByteLengthOfCodePointNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode getUncached() {
            return ByteLengthOfCodePointNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.ByteLengthOfCodePointNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value, ErrorHandling arg3Value) {
                return translate(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.ByteLengthOfCodePointNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ByteIndexToCodePointIndexNode#translate}
     *     Activation probability: 1.00000
     *     With/without class size: 28/6 bytes
     * </pre>
     */
    @GeneratedBy(ByteIndexToCodePointIndexNode.class)
    @SuppressWarnings("javadoc")
    static final class ByteIndexToCodePointIndexNodeGen extends ByteIndexToCodePointIndexNode {

        private static final StateField STATE_0_ByteIndexToCodePointIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_ByteIndexToCodePointIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexToCodePointIndexNode#translate}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ByteIndexToCodePointIndexNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexToCodePointIndexNode#translate}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_ByteIndexToCodePointIndexNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexToCodePointIndexNode#translate}
         *   Parameter: {@link RawIndexToCodePointIndexNode} rawIndexToCodePointIndexNode
         *   Inline method: {@link RawIndexToCodePointIndexNodeGen#inline}</pre>
         */
        private static final RawIndexToCodePointIndexNode INLINED_RAW_INDEX_TO_CODE_POINT_INDEX_NODE_ = RawIndexToCodePointIndexNodeGen.inline(InlineTarget.create(RawIndexToCodePointIndexNode.class, STATE_1_ByteIndexToCodePointIndexNode_UPDATER.subUpdater(0, 10)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link ByteIndexToCodePointIndexNode#translate}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link ByteIndexToCodePointIndexNode#translate}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-9: InlinedCache
         *        Specialization: {@link ByteIndexToCodePointIndexNode#translate}
         *        Parameter: {@link RawIndexToCodePointIndexNode} rawIndexToCodePointIndexNode
         *        Inline method: {@link RawIndexToCodePointIndexNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;

        private ByteIndexToCodePointIndexNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
            return translate(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_RAW_INDEX_TO_CODE_POINT_INDEX_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static ByteIndexToCodePointIndexNode create() {
            return new ByteIndexToCodePointIndexNodeGen();
        }

        @NeverDefault
        public static ByteIndexToCodePointIndexNode getUncached() {
            return ByteIndexToCodePointIndexNodeGen.UNCACHED;
        }

        @GeneratedBy(ByteIndexToCodePointIndexNode.class)
        @DenyReplace
        private static final class Uncached extends ByteIndexToCodePointIndexNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
                return translate(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (RawIndexToCodePointIndexNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CodePointIndexToByteIndexNode#translate}
     *     Activation probability: 1.00000
     *     With/without class size: 28/8 bytes
     * </pre>
     */
    @GeneratedBy(CodePointIndexToByteIndexNode.class)
    @SuppressWarnings("javadoc")
    static final class CodePointIndexToByteIndexNodeGen extends CodePointIndexToByteIndexNode {

        private static final StateField STATE_0_CodePointIndexToByteIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_CodePointIndexToByteIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointIndexToByteIndexNode#translate}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CodePointIndexToByteIndexNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointIndexToByteIndexNode#translate}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_0_CodePointIndexToByteIndexNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointIndexToByteIndexNode#translate}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_1_CodePointIndexToByteIndexNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointIndexToByteIndexNode#translate}
         *   Parameter: {@link CodePointIndexToRawNode} codePointIndexToRawNode
         *   Inline method: {@link CodePointIndexToRawNodeGen#inline}</pre>
         */
        private static final CodePointIndexToRawNode INLINED_CODE_POINT_INDEX_TO_RAW_NODE_ = CodePointIndexToRawNodeGen.inline(InlineTarget.create(CodePointIndexToRawNode.class, STATE_1_CodePointIndexToByteIndexNode_UPDATER.subUpdater(25, 6)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CodePointIndexToByteIndexNode#translate}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link CodePointIndexToByteIndexNode#translate}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link CodePointIndexToByteIndexNode#translate}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         *   25-30: InlinedCache
         *        Specialization: {@link CodePointIndexToByteIndexNode#translate}
         *        Parameter: {@link CodePointIndexToRawNode} codePointIndexToRawNode
         *        Inline method: {@link CodePointIndexToRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;

        private CodePointIndexToByteIndexNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
            return translate(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_CODE_POINT_INDEX_TO_RAW_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CodePointIndexToByteIndexNode create() {
            return new CodePointIndexToByteIndexNodeGen();
        }

        @NeverDefault
        public static CodePointIndexToByteIndexNode getUncached() {
            return CodePointIndexToByteIndexNodeGen.UNCACHED;
        }

        @GeneratedBy(CodePointIndexToByteIndexNode.class)
        @DenyReplace
        private static final class Uncached extends CodePointIndexToByteIndexNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value) {
                return translate(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (CodePointIndexToRawNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CodePointAtIndexNode#readCodePoint}
     *     Activation probability: 1.00000
     *     With/without class size: 32/10 bytes
     * </pre>
     */
    @GeneratedBy(CodePointAtIndexNode.class)
    @SuppressWarnings("javadoc")
    static final class CodePointAtIndexNodeGen extends CodePointAtIndexNode {

        private static final StateField STATE_0_CodePointAtIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_CodePointAtIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_CodePointAtIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointAtIndexNode#readCodePoint}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CodePointAtIndexNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointAtIndexNode#readCodePoint}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_0_CodePointAtIndexNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointAtIndexNode#readCodePoint}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_1_CodePointAtIndexNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointAtIndexNode#readCodePoint}
         *   Parameter: {@link CodePointAtNode} readCodePointNode
         *   Inline method: {@link CodePointAtNodeGen#inline}</pre>
         */
        private static final CodePointAtNode INLINED_READ_CODE_POINT_NODE_ = CodePointAtNodeGen.inline(InlineTarget.create(CodePointAtNode.class, STATE_2_CodePointAtIndexNode_UPDATER.subUpdater(0, 16)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CodePointAtIndexNode#readCodePoint}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link CodePointAtIndexNode#readCodePoint}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link CodePointAtIndexNode#readCodePoint}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-15: InlinedCache
         *        Specialization: {@link CodePointAtIndexNode#readCodePoint}
         *        Parameter: {@link CodePointAtNode} readCodePointNode
         *        Inline method: {@link CodePointAtNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;

        private CodePointAtIndexNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value, ErrorHandling arg3Value) {
            return readCodePoint(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_READ_CODE_POINT_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CodePointAtIndexNode create() {
            return new CodePointAtIndexNodeGen();
        }

        @NeverDefault
        public static CodePointAtIndexNode getUncached() {
            return CodePointAtIndexNodeGen.UNCACHED;
        }

        @GeneratedBy(CodePointAtIndexNode.class)
        @DenyReplace
        private static final class Uncached extends CodePointAtIndexNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value, ErrorHandling arg3Value) {
                return readCodePoint(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (CodePointAtNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CodePointAtByteIndexNode#readCodePoint}
     *     Activation probability: 1.00000
     *     With/without class size: 28/7 bytes
     * </pre>
     */
    @GeneratedBy(CodePointAtByteIndexNode.class)
    @SuppressWarnings("javadoc")
    static final class CodePointAtByteIndexNodeGen extends CodePointAtByteIndexNode {

        private static final StateField STATE_0_CodePointAtByteIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_CodePointAtByteIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointAtByteIndexNode#readCodePoint}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CodePointAtByteIndexNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointAtByteIndexNode#readCodePoint}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_CodePointAtByteIndexNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CodePointAtByteIndexNode#readCodePoint}
         *   Parameter: {@link CodePointAtRawNode} readCodePointNode
         *   Inline method: {@link CodePointAtRawNodeGen#inline}</pre>
         */
        private static final CodePointAtRawNode INLINED_READ_CODE_POINT_NODE_ = CodePointAtRawNodeGen.inline(InlineTarget.create(CodePointAtRawNode.class, STATE_1_CodePointAtByteIndexNode_UPDATER.subUpdater(0, 18)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CodePointAtByteIndexNode#readCodePoint}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link CodePointAtByteIndexNode#readCodePoint}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-17: InlinedCache
         *        Specialization: {@link CodePointAtByteIndexNode#readCodePoint}
         *        Parameter: {@link CodePointAtRawNode} readCodePointNode
         *        Inline method: {@link CodePointAtRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;

        private CodePointAtByteIndexNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value, ErrorHandling arg3Value) {
            return readCodePoint(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_READ_CODE_POINT_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CodePointAtByteIndexNode create() {
            return new CodePointAtByteIndexNodeGen();
        }

        @NeverDefault
        public static CodePointAtByteIndexNode getUncached() {
            return CodePointAtByteIndexNodeGen.UNCACHED;
        }

        @GeneratedBy(CodePointAtByteIndexNode.class)
        @DenyReplace
        private static final class Uncached extends CodePointAtByteIndexNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value, ErrorHandling arg3Value) {
                return readCodePoint(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (CodePointAtRawNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ByteIndexOfAnyByteNode#indexOfRaw}
     *     Activation probability: 1.00000
     *     With/without class size: 24/1 bytes
     * </pre>
     */
    @GeneratedBy(ByteIndexOfAnyByteNode.class)
    @SuppressWarnings("javadoc")
    static final class ByteIndexOfAnyByteNodeGen extends ByteIndexOfAnyByteNode {

        private static final StateField STATE_0_ByteIndexOfAnyByteNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfAnyByteNode#indexOfRaw}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ByteIndexOfAnyByteNode_UPDATER.subUpdater(0, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link ByteIndexOfAnyByteNode#indexOfRaw}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private ByteIndexOfAnyByteNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, byte[] arg3Value, Encoding arg4Value) {
            return indexOfRaw(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_TO_INDEXABLE_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static ByteIndexOfAnyByteNode create() {
            return new ByteIndexOfAnyByteNodeGen();
        }

        @NeverDefault
        public static ByteIndexOfAnyByteNode getUncached() {
            return ByteIndexOfAnyByteNodeGen.UNCACHED;
        }

        @GeneratedBy(ByteIndexOfAnyByteNode.class)
        @DenyReplace
        private static final class Uncached extends ByteIndexOfAnyByteNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, byte[] arg3Value, Encoding arg4Value) {
                return indexOfRaw(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CharIndexOfAnyCharUTF16Node#indexOfRaw}
     *     Activation probability: 1.00000
     *     With/without class size: 28/5 bytes
     * </pre>
     */
    @GeneratedBy(CharIndexOfAnyCharUTF16Node.class)
    @SuppressWarnings("javadoc")
    static final class CharIndexOfAnyCharUTF16NodeGen extends CharIndexOfAnyCharUTF16Node {

        private static final StateField STATE_0_CharIndexOfAnyCharUTF16Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_CharIndexOfAnyCharUTF16Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CharIndexOfAnyCharUTF16Node#indexOfRaw}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CharIndexOfAnyCharUTF16Node_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CharIndexOfAnyCharUTF16Node#indexOfRaw}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_CharIndexOfAnyCharUTF16Node_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CharIndexOfAnyCharUTF16Node#indexOfRaw}
         *   Parameter: {@link IndexOfAnyCharNode} indexOfNode
         *   Inline method: {@link IndexOfAnyCharNodeGen#inline}</pre>
         */
        private static final IndexOfAnyCharNode INLINED_INDEX_OF_NODE_ = IndexOfAnyCharNodeGen.inline(InlineTarget.create(IndexOfAnyCharNode.class, STATE_1_CharIndexOfAnyCharUTF16Node_UPDATER.subUpdater(0, 3)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CharIndexOfAnyCharUTF16Node#indexOfRaw}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link CharIndexOfAnyCharUTF16Node#indexOfRaw}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-2: InlinedCache
         *        Specialization: {@link CharIndexOfAnyCharUTF16Node#indexOfRaw}
         *        Parameter: {@link IndexOfAnyCharNode} indexOfNode
         *        Inline method: {@link IndexOfAnyCharNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;

        private CharIndexOfAnyCharUTF16NodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, char[] arg3Value) {
            return indexOfRaw(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_INDEX_OF_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CharIndexOfAnyCharUTF16Node create() {
            return new CharIndexOfAnyCharUTF16NodeGen();
        }

        @NeverDefault
        public static CharIndexOfAnyCharUTF16Node getUncached() {
            return CharIndexOfAnyCharUTF16NodeGen.UNCACHED;
        }

        @GeneratedBy(CharIndexOfAnyCharUTF16Node.class)
        @DenyReplace
        private static final class Uncached extends CharIndexOfAnyCharUTF16Node {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, char[] arg3Value) {
                return indexOfRaw(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (IndexOfAnyCharNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IntIndexOfAnyIntUTF32Node#indexOfRaw}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(IntIndexOfAnyIntUTF32Node.class)
    @SuppressWarnings("javadoc")
    static final class IntIndexOfAnyIntUTF32NodeGen extends IntIndexOfAnyIntUTF32Node {

        private static final StateField STATE_0_IntIndexOfAnyIntUTF32Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IntIndexOfAnyIntUTF32Node#indexOfRaw}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_IntIndexOfAnyIntUTF32Node_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link IntIndexOfAnyIntUTF32Node#indexOfRaw}
         *   Parameter: {@link IndexOfAnyIntNode} indexOfNode
         *   Inline method: {@link IndexOfAnyIntNodeGen#inline}</pre>
         */
        private static final IndexOfAnyIntNode INLINED_INDEX_OF_NODE_ = IndexOfAnyIntNodeGen.inline(InlineTarget.create(IndexOfAnyIntNode.class, STATE_0_IntIndexOfAnyIntUTF32Node_UPDATER.subUpdater(7, 5)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link IntIndexOfAnyIntUTF32Node#indexOfRaw}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-11: InlinedCache
         *        Specialization: {@link IntIndexOfAnyIntUTF32Node#indexOfRaw}
         *        Parameter: {@link IndexOfAnyIntNode} indexOfNode
         *        Inline method: {@link IndexOfAnyIntNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private IntIndexOfAnyIntUTF32NodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int[] arg3Value) {
            return indexOfRaw(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE_, INLINED_INDEX_OF_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IntIndexOfAnyIntUTF32Node create() {
            return new IntIndexOfAnyIntUTF32NodeGen();
        }

        @NeverDefault
        public static IntIndexOfAnyIntUTF32Node getUncached() {
            return IntIndexOfAnyIntUTF32NodeGen.UNCACHED;
        }

        @GeneratedBy(IntIndexOfAnyIntUTF32Node.class)
        @DenyReplace
        private static final class Uncached extends IntIndexOfAnyIntUTF32Node {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int[] arg3Value) {
                return indexOfRaw(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (IndexOfAnyIntNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
     *     Activation probability: 0.65000
     *     With/without class size: 22/12 bytes
     *   Specialization {@link ByteIndexOfCodePointSetNode#indexOfUncached}
     *     Activation probability: 0.35000
     *     With/without class size: 12/6 bytes
     * </pre>
     */
    @GeneratedBy(ByteIndexOfCodePointSetNode.class)
    @SuppressWarnings("javadoc")
    static final class ByteIndexOfCodePointSetNodeGen extends ByteIndexOfCodePointSetNode {

        private static final StateField STATE_0_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_0_ByteIndexOfCodePointSetNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField INDEX_OF_SPECIALIZED__BYTE_INDEX_OF_CODE_POINT_SET_NODE_INDEX_OF_SPECIALIZED_STATE_0_UPDATER = StateField.create(IndexOfSpecializedData.lookup_(), "indexOfSpecialized_state_0_");
        private static final StateField STATE_1_ByteIndexOfCodePointSetNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        static final ReferenceField<IndexOfSpecializedData> INDEX_OF_SPECIALIZED_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "indexOfSpecialized_cache", IndexOfSpecializedData.class);
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_UPDATER.subUpdater(2, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_INDEX_OF_SPECIALIZED_TO_INDEXABLE_NODE = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ByteIndexOfCodePointSetNode_UPDATER.subUpdater(2, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_INDEX_OF_SPECIALIZED_GET_PRECISE_CODE_RANGE_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, INDEX_OF_SPECIALIZED__BYTE_INDEX_OF_CODE_POINT_SET_NODE_INDEX_OF_SPECIALIZED_STATE_0_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfCodePointSetNode#indexOfUncached}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_INDEX_OF_UNCACHED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_1_ByteIndexOfCodePointSetNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfCodePointSetNode#indexOfUncached}
         *   Parameter: {@link InternalNextNode} nextNode
         *   Inline method: {@link InternalNextNodeGen#inline}</pre>
         */
        private static final InternalNextNode INLINED_INDEX_OF_UNCACHED_NEXT_NODE_ = InternalNextNodeGen.inline(InlineTarget.create(InternalNextNode.class, STATE_0_ByteIndexOfCodePointSetNode_UPDATER.subUpdater(9, 21)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
         *   1: SpecializationActive {@link ByteIndexOfCodePointSetNode#indexOfUncached}
         *   2-8: InlinedCache
         *        Specialization: {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   9-29: InlinedCache
         *        Specialization: {@link ByteIndexOfCodePointSetNode#indexOfUncached}
         *        Parameter: {@link InternalNextNode} nextNode
         *        Inline method: {@link InternalNextNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ByteIndexOfCodePointSetNode#indexOfUncached}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        @UnsafeAccessedField @Child private IndexOfSpecializedData indexOfSpecialized_cache;

        private ByteIndexOfCodePointSetNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, CodePointSet arg3Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.ByteIndexOfCodePointSetNode.indexOfSpecialized(AbstractTruffleString, int, int, CodePointSet, Node, ToIndexableNode, GetPreciseCodeRangeNode, CodePointSet, IndexOfCodePointSetNode)] || SpecializationActive[TruffleString.ByteIndexOfCodePointSetNode.indexOfUncached(AbstractTruffleString, int, int, CodePointSet, ToIndexableNode, GetCodeRangeForIndexCalculationNode, InternalNextNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.ByteIndexOfCodePointSetNode.indexOfSpecialized(AbstractTruffleString, int, int, CodePointSet, Node, ToIndexableNode, GetPreciseCodeRangeNode, CodePointSet, IndexOfCodePointSetNode)] */) {
                    IndexOfSpecializedData s0_ = this.indexOfSpecialized_cache;
                    if (s0_ != null) {
                        if ((arg3Value == s0_.cachedCodePointSet_)) {
                            Node node__ = (s0_);
                            return ByteIndexOfCodePointSetNode.indexOfSpecialized(arg0Value, arg1Value, arg2Value, arg3Value, node__, INLINED_INDEX_OF_SPECIALIZED_TO_INDEXABLE_NODE, INLINED_INDEX_OF_SPECIALIZED_GET_PRECISE_CODE_RANGE_NODE_, s0_.cachedCodePointSet_, s0_.internalNode_);
                        }
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.ByteIndexOfCodePointSetNode.indexOfUncached(AbstractTruffleString, int, int, CodePointSet, ToIndexableNode, GetCodeRangeForIndexCalculationNode, InternalNextNode)] */) {
                    return indexOfUncached(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE, INLINED_INDEX_OF_UNCACHED_GET_CODE_RANGE_NODE_, INLINED_INDEX_OF_UNCACHED_NEXT_NODE_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
        }

        private int executeAndSpecialize(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, CodePointSet arg3Value) {
            int state_0 = this.state_0_;
            {
                Node node__ = null;
                if (((state_0 & 0b10)) == 0 /* is-not SpecializationActive[TruffleString.ByteIndexOfCodePointSetNode.indexOfUncached(AbstractTruffleString, int, int, CodePointSet, ToIndexableNode, GetCodeRangeForIndexCalculationNode, InternalNextNode)] */) {
                    while (true) {
                        int count0_ = 0;
                        IndexOfSpecializedData s0_ = INDEX_OF_SPECIALIZED_CACHE_UPDATER.getVolatile(this);
                        IndexOfSpecializedData s0_original = s0_;
                        while (s0_ != null) {
                            if ((arg3Value == s0_.cachedCodePointSet_)) {
                                node__ = (s0_);
                                break;
                            }
                            count0_++;
                            s0_ = null;
                            break;
                        }
                        if (s0_ == null && count0_ < 1) {
                            // assert (arg3Value == s0_.cachedCodePointSet_);
                            s0_ = this.insert(new IndexOfSpecializedData());
                            node__ = (s0_);
                            s0_.cachedCodePointSet_ = (arg3Value);
                            s0_.internalNode_ = s0_.insert((s0_.cachedCodePointSet_.createNode()));
                            if (!INDEX_OF_SPECIALIZED_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                continue;
                            }
                            state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.ByteIndexOfCodePointSetNode.indexOfSpecialized(AbstractTruffleString, int, int, CodePointSet, Node, ToIndexableNode, GetPreciseCodeRangeNode, CodePointSet, IndexOfCodePointSetNode)] */;
                            this.state_0_ = state_0;
                        }
                        if (s0_ != null) {
                            return ByteIndexOfCodePointSetNode.indexOfSpecialized(arg0Value, arg1Value, arg2Value, arg3Value, node__, INLINED_INDEX_OF_SPECIALIZED_TO_INDEXABLE_NODE, INLINED_INDEX_OF_SPECIALIZED_GET_PRECISE_CODE_RANGE_NODE_, s0_.cachedCodePointSet_, s0_.internalNode_);
                        }
                        break;
                    }
                }
            }
            this.indexOfSpecialized_cache = null;
            state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[TruffleString.ByteIndexOfCodePointSetNode.indexOfSpecialized(AbstractTruffleString, int, int, CodePointSet, Node, ToIndexableNode, GetPreciseCodeRangeNode, CodePointSet, IndexOfCodePointSetNode)] */;
            state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.ByteIndexOfCodePointSetNode.indexOfUncached(AbstractTruffleString, int, int, CodePointSet, ToIndexableNode, GetCodeRangeForIndexCalculationNode, InternalNextNode)] */;
            this.state_0_ = state_0;
            return indexOfUncached(arg0Value, arg1Value, arg2Value, arg3Value, INLINED_TO_INDEXABLE_NODE, INLINED_INDEX_OF_UNCACHED_GET_CODE_RANGE_NODE_, INLINED_INDEX_OF_UNCACHED_NEXT_NODE_);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount((state_0 & 0b11));
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static ByteIndexOfCodePointSetNode create() {
            return new ByteIndexOfCodePointSetNodeGen();
        }

        @NeverDefault
        public static ByteIndexOfCodePointSetNode getUncached() {
            return ByteIndexOfCodePointSetNodeGen.UNCACHED;
        }

        @GeneratedBy(ByteIndexOfCodePointSetNode.class)
        @DenyReplace
        private static final class IndexOfSpecializedData extends Node implements SpecializationDataNode {

            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
             *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int indexOfSpecialized_state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
             *   Parameter: {@link CodePointSet} cachedCodePointSet</pre>
             */
            @CompilationFinal CodePointSet cachedCodePointSet_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ByteIndexOfCodePointSetNode#indexOfSpecialized}
             *   Parameter: {@link IndexOfCodePointSetNode} internalNode</pre>
             */
            @Child IndexOfCodePointSetNode internalNode_;

            IndexOfSpecializedData() {
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

            private static Lookup lookup_() {
                return MethodHandles.lookup();
            }

        }
        @GeneratedBy(ByteIndexOfCodePointSetNode.class)
        @DenyReplace
        private static final class Uncached extends ByteIndexOfCodePointSetNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, CodePointSet arg3Value) {
                return indexOfUncached(arg0Value, arg1Value, arg2Value, arg3Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (InternalNextNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
     *     Activation probability: 1.00000
     *     With/without class size: 32/12 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfCodePointNodeGen extends com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode {

        private static final StateField STATE_0_IndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_IndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_IndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_IndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_IndexOfCodePointNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_0_IndexOfCodePointNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_1_IndexOfCodePointNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.IndexOfCodePointNode} indexOfNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.IndexOfCodePointNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.IndexOfCodePointNode INLINED_INDEX_OF_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.IndexOfCodePointNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.IndexOfCodePointNode.class, STATE_2_IndexOfCodePointNode_UPDATER.subUpdater(0, 14), STATE_3_IndexOfCodePointNode_UPDATER.subUpdater(0, 21)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-13: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.IndexOfCodePointNode} indexOfNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.IndexOfCodePointNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.IndexOfCodePointNode} indexOfNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.IndexOfCodePointNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;

        private IndexOfCodePointNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
            return doIndexOf(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_INDEX_OF_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.IndexOfCodePointNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode getUncached() {
            return IndexOfCodePointNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.IndexOfCodePointNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
                return doIndexOf(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.IndexOfCodePointNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ByteIndexOfCodePointNode#doIndexOf}
     *     Activation probability: 1.00000
     *     With/without class size: 32/9 bytes
     * </pre>
     */
    @GeneratedBy(ByteIndexOfCodePointNode.class)
    @SuppressWarnings("javadoc")
    static final class ByteIndexOfCodePointNodeGen extends ByteIndexOfCodePointNode {

        private static final StateField STATE_0_ByteIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_ByteIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_ByteIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ByteIndexOfCodePointNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_ByteIndexOfCodePointNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link IndexOfCodePointRawNode} indexOfNode
         *   Inline method: {@link IndexOfCodePointRawNodeGen#inline}</pre>
         */
        private static final IndexOfCodePointRawNode INLINED_INDEX_OF_NODE_ = IndexOfCodePointRawNodeGen.inline(InlineTarget.create(IndexOfCodePointRawNode.class, STATE_1_ByteIndexOfCodePointNode_UPDATER.subUpdater(0, 16), STATE_2_ByteIndexOfCodePointNode_UPDATER.subUpdater(0, 21)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link ByteIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link ByteIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-15: InlinedCache
         *        Specialization: {@link ByteIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link IndexOfCodePointRawNode} indexOfNode
         *        Inline method: {@link IndexOfCodePointRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link ByteIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link IndexOfCodePointRawNode} indexOfNode
         *        Inline method: {@link IndexOfCodePointRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;

        private ByteIndexOfCodePointNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
            return doIndexOf(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_INDEX_OF_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static ByteIndexOfCodePointNode create() {
            return new ByteIndexOfCodePointNodeGen();
        }

        @NeverDefault
        public static ByteIndexOfCodePointNode getUncached() {
            return ByteIndexOfCodePointNodeGen.UNCACHED;
        }

        @GeneratedBy(ByteIndexOfCodePointNode.class)
        @DenyReplace
        private static final class Uncached extends ByteIndexOfCodePointNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
                return doIndexOf(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (IndexOfCodePointRawNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
     *     Activation probability: 1.00000
     *     With/without class size: 32/12 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode.class)
    @SuppressWarnings("javadoc")
    static final class LastIndexOfCodePointNodeGen extends com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode {

        private static final StateField STATE_0_LastIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_LastIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_LastIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_LastIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_LastIndexOfCodePointNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_0_LastIndexOfCodePointNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_1_LastIndexOfCodePointNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfCodePointNode} lastIndexOfNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfCodePointNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfCodePointNode INLINED_LAST_INDEX_OF_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfCodePointNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfCodePointNode.class, STATE_2_LastIndexOfCodePointNode_UPDATER.subUpdater(0, 14), STATE_3_LastIndexOfCodePointNode_UPDATER.subUpdater(0, 21)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-13: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfCodePointNode} lastIndexOfNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfCodePointNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfCodePointNode} lastIndexOfNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfCodePointNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;

        private LastIndexOfCodePointNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
            return doIndexOf(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_LAST_INDEX_OF_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.LastIndexOfCodePointNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode getUncached() {
            return LastIndexOfCodePointNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.LastIndexOfCodePointNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
                return doIndexOf(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfCodePointNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link LastByteIndexOfCodePointNode#doIndexOf}
     *     Activation probability: 1.00000
     *     With/without class size: 32/9 bytes
     * </pre>
     */
    @GeneratedBy(LastByteIndexOfCodePointNode.class)
    @SuppressWarnings("javadoc")
    static final class LastByteIndexOfCodePointNodeGen extends LastByteIndexOfCodePointNode {

        private static final StateField STATE_0_LastByteIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_LastByteIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_LastByteIndexOfCodePointNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_LastByteIndexOfCodePointNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_LastByteIndexOfCodePointNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfCodePointNode#doIndexOf}
         *   Parameter: {@link LastIndexOfCodePointRawNode} lastIndexOfNode
         *   Inline method: {@link LastIndexOfCodePointRawNodeGen#inline}</pre>
         */
        private static final LastIndexOfCodePointRawNode INLINED_LAST_INDEX_OF_NODE_ = LastIndexOfCodePointRawNodeGen.inline(InlineTarget.create(LastIndexOfCodePointRawNode.class, STATE_1_LastByteIndexOfCodePointNode_UPDATER.subUpdater(0, 16), STATE_2_LastByteIndexOfCodePointNode_UPDATER.subUpdater(0, 21)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link LastByteIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link LastByteIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-15: InlinedCache
         *        Specialization: {@link LastByteIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link LastIndexOfCodePointRawNode} lastIndexOfNode
         *        Inline method: {@link LastIndexOfCodePointRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link LastByteIndexOfCodePointNode#doIndexOf}
         *        Parameter: {@link LastIndexOfCodePointRawNode} lastIndexOfNode
         *        Inline method: {@link LastIndexOfCodePointRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;

        private LastByteIndexOfCodePointNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
            return doIndexOf(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_NODE_, INLINED_LAST_INDEX_OF_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static LastByteIndexOfCodePointNode create() {
            return new LastByteIndexOfCodePointNodeGen();
        }

        @NeverDefault
        public static LastByteIndexOfCodePointNode getUncached() {
            return LastByteIndexOfCodePointNodeGen.UNCACHED;
        }

        @GeneratedBy(LastByteIndexOfCodePointNode.class)
        @DenyReplace
        private static final class Uncached extends LastByteIndexOfCodePointNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
                return doIndexOf(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (LastIndexOfCodePointRawNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfStringNode#indexOfString}
     *     Activation probability: 1.00000
     *     With/without class size: 44/24 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfStringNode.class)
    @SuppressWarnings("javadoc")
    static final class IndexOfStringNodeGen extends IndexOfStringNode {

        private static final StateField STATE_0_IndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_IndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_IndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_IndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        private static final StateField STATE_4_IndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_4_");
        private static final StateField STATE_5_IndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_5_");
        private static final StateField STATE_6_IndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_6_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfStringNode#indexOfString}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_IndexOfStringNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfStringNode#indexOfString}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_IndexOfStringNode_UPDATER.subUpdater(7, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfStringNode#indexOfString}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthANode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_A_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_1_IndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfStringNode#indexOfString}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthBNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_B_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_2_IndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfStringNode#indexOfString}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_3_IndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfStringNode#indexOfString}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_B_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_4_IndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfStringNode#indexOfString}
         *   Parameter: {@link InternalIndexOfStringNode} indexOfStringNode
         *   Inline method: {@link InternalIndexOfStringNodeGen#inline}</pre>
         */
        private static final InternalIndexOfStringNode INLINED_INDEX_OF_STRING_NODE_ = InternalIndexOfStringNodeGen.inline(InlineTarget.create(InternalIndexOfStringNode.class, STATE_5_IndexOfStringNode_UPDATER.subUpdater(0, 24), STATE_6_IndexOfStringNode_UPDATER.subUpdater(0, 21), ReferenceField.create(MethodHandles.lookup(), "indexOfStringNode__field2_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link IndexOfStringNode#indexOfString}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link IndexOfStringNode#indexOfString}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link IndexOfStringNode#indexOfString}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthANode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link IndexOfStringNode#indexOfString}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthBNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link IndexOfStringNode#indexOfString}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link IndexOfStringNode#indexOfString}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_4_;
        /**
         * State Info: <pre>
         *   0-23: InlinedCache
         *        Specialization: {@link IndexOfStringNode#indexOfString}
         *        Parameter: {@link InternalIndexOfStringNode} indexOfStringNode
         *        Inline method: {@link InternalIndexOfStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_5_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link IndexOfStringNode#indexOfString}
         *        Parameter: {@link InternalIndexOfStringNode} indexOfStringNode
         *        Inline method: {@link InternalIndexOfStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_6_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link IndexOfStringNode#indexOfString}
         *   Parameter: {@link InternalIndexOfStringNode} indexOfStringNode
         *   Inline method: {@link InternalIndexOfStringNodeGen#inline}
         *   Inline field: {@link Node} field2</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node indexOfStringNode__field2_;

        private IndexOfStringNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
            return indexOfString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_, INLINED_GET_CODE_POINT_LENGTH_A_NODE_, INLINED_GET_CODE_POINT_LENGTH_B_NODE_, INLINED_GET_CODE_RANGE_A_NODE_, INLINED_GET_CODE_RANGE_B_NODE_, INLINED_INDEX_OF_STRING_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfStringNode create() {
            return new IndexOfStringNodeGen();
        }

        @NeverDefault
        public static IndexOfStringNode getUncached() {
            return IndexOfStringNodeGen.UNCACHED;
        }

        @GeneratedBy(IndexOfStringNode.class)
        @DenyReplace
        private static final class Uncached extends IndexOfStringNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
                return indexOfString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (InternalIndexOfStringNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ByteIndexOfStringNode#indexOfString}
     *     Activation probability: 1.00000
     *     With/without class size: 40/18 bytes
     * </pre>
     */
    @GeneratedBy(ByteIndexOfStringNode.class)
    @SuppressWarnings("javadoc")
    static final class ByteIndexOfStringNodeGen extends ByteIndexOfStringNode {

        private static final StateField STATE_0_ByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_ByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_ByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_ByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        private static final StateField STATE_4_ByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_4_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ByteIndexOfStringNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ByteIndexOfStringNode_UPDATER.subUpdater(7, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_1_ByteIndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_B_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_2_ByteIndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *   Parameter: {@link IndexOfStringRawNode} indexOfStringNode
         *   Inline method: {@link IndexOfStringRawNodeGen#inline}</pre>
         */
        private static final IndexOfStringRawNode INLINED_INDEX_OF_STRING_NODE_ = IndexOfStringRawNodeGen.inline(InlineTarget.create(IndexOfStringRawNode.class, STATE_3_ByteIndexOfStringNode_UPDATER.subUpdater(0, 24), STATE_4_ByteIndexOfStringNode_UPDATER.subUpdater(0, 21), ReferenceField.create(MethodHandles.lookup(), "indexOfStringNode__field2_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-23: InlinedCache
         *        Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *        Parameter: {@link IndexOfStringRawNode} indexOfStringNode
         *        Inline method: {@link IndexOfStringRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *        Parameter: {@link IndexOfStringRawNode} indexOfStringNode
         *        Inline method: {@link IndexOfStringRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_4_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link ByteIndexOfStringNode#indexOfString}
         *   Parameter: {@link IndexOfStringRawNode} indexOfStringNode
         *   Inline method: {@link IndexOfStringRawNodeGen#inline}
         *   Inline field: {@link Node} field2</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node indexOfStringNode__field2_;

        private ByteIndexOfStringNodeGen() {
        }

        @Override
        int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value, byte[] arg4Value, Encoding arg5Value) {
            return indexOfString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_, INLINED_GET_CODE_RANGE_A_NODE_, INLINED_GET_CODE_RANGE_B_NODE_, INLINED_INDEX_OF_STRING_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static ByteIndexOfStringNode create() {
            return new ByteIndexOfStringNodeGen();
        }

        @NeverDefault
        public static ByteIndexOfStringNode getUncached() {
            return ByteIndexOfStringNodeGen.UNCACHED;
        }

        @GeneratedBy(ByteIndexOfStringNode.class)
        @DenyReplace
        private static final class Uncached extends ByteIndexOfStringNode {

            @TruffleBoundary
            @Override
            int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value, byte[] arg4Value, Encoding arg5Value) {
                return indexOfString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (IndexOfStringRawNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
     *     Activation probability: 1.00000
     *     With/without class size: 48/27 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode.class)
    @SuppressWarnings("javadoc")
    static final class LastIndexOfStringNodeGen extends com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode {

        private static final StateField STATE_0_LastIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_LastIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_LastIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_LastIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        private static final StateField STATE_4_LastIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_4_");
        private static final StateField STATE_5_LastIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_5_");
        private static final StateField STATE_6_LastIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_6_");
        private static final StateField STATE_7_LastIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_7_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_LastIndexOfStringNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_LastIndexOfStringNode_UPDATER.subUpdater(7, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthANode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_A_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_1_LastIndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthBNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_B_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_2_LastIndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_3_LastIndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_B_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_4_LastIndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfStringNode} indexOfStringNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfStringNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfStringNode INLINED_INDEX_OF_STRING_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfStringNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfStringNode.class, STATE_5_LastIndexOfStringNode_UPDATER.subUpdater(0, 24), STATE_6_LastIndexOfStringNode_UPDATER.subUpdater(0, 21), STATE_7_LastIndexOfStringNode_UPDATER.subUpdater(0, 21), ReferenceField.create(MethodHandles.lookup(), "indexOfStringNode__field3_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthANode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthBNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_4_;
        /**
         * State Info: <pre>
         *   0-23: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfStringNode} indexOfStringNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_5_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfStringNode} indexOfStringNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_6_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfStringNode} indexOfStringNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_7_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode#lastIndexOfString}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.LastIndexOfStringNode} indexOfStringNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfStringNodeGen#inline}
         *   Inline field: {@link Node} field3</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node indexOfStringNode__field3_;

        private LastIndexOfStringNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
            return lastIndexOfString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_, INLINED_GET_CODE_POINT_LENGTH_A_NODE_, INLINED_GET_CODE_POINT_LENGTH_B_NODE_, INLINED_GET_CODE_RANGE_A_NODE_, INLINED_GET_CODE_RANGE_B_NODE_, INLINED_INDEX_OF_STRING_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.LastIndexOfStringNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode getUncached() {
            return LastIndexOfStringNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.LastIndexOfStringNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value, Encoding arg4Value) {
                return lastIndexOfString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.LastIndexOfStringNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link LastByteIndexOfStringNode#lastByteIndexOfString}
     *     Activation probability: 1.00000
     *     With/without class size: 44/21 bytes
     * </pre>
     */
    @GeneratedBy(LastByteIndexOfStringNode.class)
    @SuppressWarnings("javadoc")
    static final class LastByteIndexOfStringNodeGen extends LastByteIndexOfStringNode {

        private static final StateField STATE_0_LastByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_LastByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_LastByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_LastByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        private static final StateField STATE_4_LastByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_4_");
        private static final StateField STATE_5_LastByteIndexOfStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_5_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_LastByteIndexOfStringNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_LastByteIndexOfStringNode_UPDATER.subUpdater(7, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_1_LastByteIndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_B_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_2_LastByteIndexOfStringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *   Parameter: {@link LastIndexOfStringRawNode} indexOfStringNode
         *   Inline method: {@link LastIndexOfStringRawNodeGen#inline}</pre>
         */
        private static final LastIndexOfStringRawNode INLINED_INDEX_OF_STRING_NODE_ = LastIndexOfStringRawNodeGen.inline(InlineTarget.create(LastIndexOfStringRawNode.class, STATE_3_LastByteIndexOfStringNode_UPDATER.subUpdater(0, 24), STATE_4_LastByteIndexOfStringNode_UPDATER.subUpdater(0, 21), STATE_5_LastByteIndexOfStringNode_UPDATER.subUpdater(0, 21), ReferenceField.create(MethodHandles.lookup(), "indexOfStringNode__field3_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-23: InlinedCache
         *        Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *        Parameter: {@link LastIndexOfStringRawNode} indexOfStringNode
         *        Inline method: {@link LastIndexOfStringRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *        Parameter: {@link LastIndexOfStringRawNode} indexOfStringNode
         *        Inline method: {@link LastIndexOfStringRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_4_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *        Parameter: {@link LastIndexOfStringRawNode} indexOfStringNode
         *        Inline method: {@link LastIndexOfStringRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_5_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link LastByteIndexOfStringNode#lastByteIndexOfString}
         *   Parameter: {@link LastIndexOfStringRawNode} indexOfStringNode
         *   Inline method: {@link LastIndexOfStringRawNodeGen#inline}
         *   Inline field: {@link Node} field3</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node indexOfStringNode__field3_;

        private LastByteIndexOfStringNodeGen() {
        }

        @Override
        int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value, byte[] arg4Value, Encoding arg5Value) {
            return lastByteIndexOfString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_, INLINED_GET_CODE_RANGE_A_NODE_, INLINED_GET_CODE_RANGE_B_NODE_, INLINED_INDEX_OF_STRING_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static LastByteIndexOfStringNode create() {
            return new LastByteIndexOfStringNodeGen();
        }

        @NeverDefault
        public static LastByteIndexOfStringNode getUncached() {
            return LastByteIndexOfStringNodeGen.UNCACHED;
        }

        @GeneratedBy(LastByteIndexOfStringNode.class)
        @DenyReplace
        private static final class Uncached extends LastByteIndexOfStringNode {

            @TruffleBoundary
            @Override
            int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, int arg2Value, int arg3Value, byte[] arg4Value, Encoding arg5Value) {
                return lastByteIndexOfString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (LastIndexOfStringRawNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CompareBytesNode#compare}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(CompareBytesNode.class)
    @SuppressWarnings("javadoc")
    static final class CompareBytesNodeGen extends CompareBytesNode {

        private static final StateField STATE_0_CompareBytesNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CompareBytesNode#compare}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CompareBytesNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CompareBytesNode#compare}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CompareBytesNode_UPDATER.subUpdater(7, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CompareBytesNode#compare}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link CompareBytesNode#compare}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private CompareBytesNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
            return compare(arg0Value, arg1Value, arg2Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CompareBytesNode create() {
            return new CompareBytesNodeGen();
        }

        @NeverDefault
        public static CompareBytesNode getUncached() {
            return CompareBytesNodeGen.UNCACHED;
        }

        @GeneratedBy(CompareBytesNode.class)
        @DenyReplace
        private static final class Uncached extends CompareBytesNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
                return compare(arg0Value, arg1Value, arg2Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CompareCharsUTF16Node#compare}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(CompareCharsUTF16Node.class)
    @SuppressWarnings("javadoc")
    static final class CompareCharsUTF16NodeGen extends CompareCharsUTF16Node {

        private static final StateField STATE_0_CompareCharsUTF16Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CompareCharsUTF16Node#compare}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CompareCharsUTF16Node_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CompareCharsUTF16Node#compare}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CompareCharsUTF16Node_UPDATER.subUpdater(7, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CompareCharsUTF16Node#compare}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link CompareCharsUTF16Node#compare}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private CompareCharsUTF16NodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value) {
            return compare(arg0Value, arg1Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CompareCharsUTF16Node create() {
            return new CompareCharsUTF16NodeGen();
        }

        @NeverDefault
        public static CompareCharsUTF16Node getUncached() {
            return CompareCharsUTF16NodeGen.UNCACHED;
        }

        @GeneratedBy(CompareCharsUTF16Node.class)
        @DenyReplace
        private static final class Uncached extends CompareCharsUTF16Node {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value) {
                return compare(arg0Value, arg1Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CompareIntsUTF32Node#compare}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(CompareIntsUTF32Node.class)
    @SuppressWarnings("javadoc")
    static final class CompareIntsUTF32NodeGen extends CompareIntsUTF32Node {

        private static final StateField STATE_0_CompareIntsUTF32Node_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CompareIntsUTF32Node#compare}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CompareIntsUTF32Node_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CompareIntsUTF32Node#compare}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CompareIntsUTF32Node_UPDATER.subUpdater(7, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CompareIntsUTF32Node#compare}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link CompareIntsUTF32Node#compare}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private CompareIntsUTF32NodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value) {
            return compare(arg0Value, arg1Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CompareIntsUTF32Node create() {
            return new CompareIntsUTF32NodeGen();
        }

        @NeverDefault
        public static CompareIntsUTF32Node getUncached() {
            return CompareIntsUTF32NodeGen.UNCACHED;
        }

        @GeneratedBy(CompareIntsUTF32Node.class)
        @DenyReplace
        private static final class Uncached extends CompareIntsUTF32Node {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value) {
                return compare(arg0Value, arg1Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link RegionEqualNode#regionEquals}
     *     Activation probability: 1.00000
     *     With/without class size: 40/20 bytes
     * </pre>
     */
    @GeneratedBy(RegionEqualNode.class)
    @SuppressWarnings("javadoc")
    static final class RegionEqualNodeGen extends RegionEqualNode {

        private static final StateField STATE_0_RegionEqualNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_RegionEqualNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_RegionEqualNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_RegionEqualNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        private static final StateField STATE_4_RegionEqualNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_4_");
        private static final StateField STATE_5_RegionEqualNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_5_");
        private static final StateField STATE_6_RegionEqualNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_6_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualNode#regionEquals}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_RegionEqualNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualNode#regionEquals}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_RegionEqualNode_UPDATER.subUpdater(7, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualNode#regionEquals}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthANode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_A_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_1_RegionEqualNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualNode#regionEquals}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthBNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_B_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_2_RegionEqualNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualNode#regionEquals}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_3_RegionEqualNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualNode#regionEquals}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_B_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_4_RegionEqualNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualNode#regionEquals}
         *   Parameter: {@link RegionEqualsNode} regionEqualsNode
         *   Inline method: {@link RegionEqualsNodeGen#inline}</pre>
         */
        private static final RegionEqualsNode INLINED_REGION_EQUALS_NODE_ = RegionEqualsNodeGen.inline(InlineTarget.create(RegionEqualsNode.class, STATE_5_RegionEqualNode_UPDATER.subUpdater(0, 23), STATE_6_RegionEqualNode_UPDATER.subUpdater(0, 21)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link RegionEqualNode#regionEquals}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link RegionEqualNode#regionEquals}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link RegionEqualNode#regionEquals}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthANode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link RegionEqualNode#regionEquals}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthBNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link RegionEqualNode#regionEquals}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link RegionEqualNode#regionEquals}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeBNode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_4_;
        /**
         * State Info: <pre>
         *   0-22: InlinedCache
         *        Specialization: {@link RegionEqualNode#regionEquals}
         *        Parameter: {@link RegionEqualsNode} regionEqualsNode
         *        Inline method: {@link RegionEqualsNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_5_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link RegionEqualNode#regionEquals}
         *        Parameter: {@link RegionEqualsNode} regionEqualsNode
         *        Inline method: {@link RegionEqualsNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_6_;

        private RegionEqualNodeGen() {
        }

        @Override
        public boolean execute(AbstractTruffleString arg0Value, int arg1Value, AbstractTruffleString arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            return regionEquals(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_, INLINED_GET_CODE_POINT_LENGTH_A_NODE_, INLINED_GET_CODE_POINT_LENGTH_B_NODE_, INLINED_GET_CODE_RANGE_A_NODE_, INLINED_GET_CODE_RANGE_B_NODE_, INLINED_REGION_EQUALS_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static RegionEqualNode create() {
            return new RegionEqualNodeGen();
        }

        @NeverDefault
        public static RegionEqualNode getUncached() {
            return RegionEqualNodeGen.UNCACHED;
        }

        @GeneratedBy(RegionEqualNode.class)
        @DenyReplace
        private static final class Uncached extends RegionEqualNode {

            @TruffleBoundary
            @Override
            public boolean execute(AbstractTruffleString arg0Value, int arg1Value, AbstractTruffleString arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
                return regionEquals(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodePointLengthNode.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (RegionEqualsNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link RegionEqualByteIndexNode#regionEquals}
     *     Activation probability: 1.00000
     *     With/without class size: 24/2 bytes
     * </pre>
     */
    @GeneratedBy(RegionEqualByteIndexNode.class)
    @SuppressWarnings("javadoc")
    static final class RegionEqualByteIndexNodeGen extends RegionEqualByteIndexNode {

        private static final StateField STATE_0_RegionEqualByteIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualByteIndexNode#regionEquals}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_RegionEqualByteIndexNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegionEqualByteIndexNode#regionEquals}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_RegionEqualByteIndexNode_UPDATER.subUpdater(7, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link RegionEqualByteIndexNode#regionEquals}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link RegionEqualByteIndexNode#regionEquals}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private RegionEqualByteIndexNodeGen() {
        }

        @Override
        boolean execute(AbstractTruffleString arg0Value, int arg1Value, AbstractTruffleString arg2Value, int arg3Value, int arg4Value, byte[] arg5Value, Encoding arg6Value) {
            return regionEquals(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, INLINED_TO_INDEXABLE_NODE_A_, INLINED_TO_INDEXABLE_NODE_B_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static RegionEqualByteIndexNode create() {
            return new RegionEqualByteIndexNodeGen();
        }

        @NeverDefault
        public static RegionEqualByteIndexNode getUncached() {
            return RegionEqualByteIndexNodeGen.UNCACHED;
        }

        @GeneratedBy(RegionEqualByteIndexNode.class)
        @DenyReplace
        private static final class Uncached extends RegionEqualByteIndexNode {

            @TruffleBoundary
            @Override
            boolean execute(AbstractTruffleString arg0Value, int arg1Value, AbstractTruffleString arg2Value, int arg3Value, int arg4Value, byte[] arg5Value, Encoding arg6Value) {
                return regionEquals(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ConcatNode#aEmpty}
     *     Activation probability: 0.32000
     *     With/without class size: 7/0 bytes
     *   Specialization {@link ConcatNode#aEmptyMutable}
     *     Activation probability: 0.26000
     *     With/without class size: 8/0 bytes
     *   Specialization {@link ConcatNode#bEmpty}
     *     Activation probability: 0.20000
     *     With/without class size: 6/0 bytes
     *   Specialization {@link ConcatNode#bEmptyMutable}
     *     Activation probability: 0.14000
     *     With/without class size: 6/0 bytes
     *   Specialization {@link ConcatNode#doConcat}
     *     Activation probability: 0.08000
     *     With/without class size: 7/26 bytes
     * </pre>
     */
    @GeneratedBy(ConcatNode.class)
    @SuppressWarnings("javadoc")
    static final class ConcatNodeGen extends ConcatNode {

        private static final StateField STATE_1_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField CONCAT__CONCAT_NODE_CONCAT_STATE_0_UPDATER = StateField.create(ConcatData.lookup_(), "concat_state_0_");
        private static final StateField CONCAT__CONCAT_NODE_CONCAT_STATE_1_UPDATER = StateField.create(ConcatData.lookup_(), "concat_state_1_");
        private static final StateField CONCAT__CONCAT_NODE_CONCAT_STATE_2_UPDATER = StateField.create(ConcatData.lookup_(), "concat_state_2_");
        private static final StateField CONCAT__CONCAT_NODE_CONCAT_STATE_3_UPDATER = StateField.create(ConcatData.lookup_(), "concat_state_3_");
        private static final StateField CONCAT__CONCAT_NODE_CONCAT_STATE_4_UPDATER = StateField.create(ConcatData.lookup_(), "concat_state_4_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#aEmptyMutable}
         *   Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} attributesNode
         *   Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}</pre>
         */
        private static final FromBufferWithStringCompactionKnownAttributesNode INLINED_ATTRIBUTES_NODE = FromBufferWithStringCompactionKnownAttributesNodeGen.inline(InlineTarget.create(FromBufferWithStringCompactionKnownAttributesNode.class, STATE_1_UPDATER.subUpdater(0, 31), STATE_2_UPDATER.subUpdater(0, 29)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#doConcat}
         *   Parameter: {@link GetPreciseCodeRangeNode} getCodeRangeANode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_CONCAT_GET_CODE_RANGE_A_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, CONCAT__CONCAT_NODE_CONCAT_STATE_0_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#doConcat}
         *   Parameter: {@link GetPreciseCodeRangeNode} getCodeRangeBNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_CONCAT_GET_CODE_RANGE_B_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, CONCAT__CONCAT_NODE_CONCAT_STATE_1_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#doConcat}
         *   Parameter: {@link StrideFromCodeRangeNode} getStrideNode
         *   Inline method: {@link StrideFromCodeRangeNodeGen#inline}</pre>
         */
        private static final StrideFromCodeRangeNode INLINED_CONCAT_GET_STRIDE_NODE_ = StrideFromCodeRangeNodeGen.inline(InlineTarget.create(StrideFromCodeRangeNode.class, CONCAT__CONCAT_NODE_CONCAT_STATE_0_UPDATER.subUpdater(25, 3)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#doConcat}
         *   Parameter: {@link ConcatEagerNode} concatEagerNode
         *   Inline method: {@link ConcatEagerNodeGen#inline}</pre>
         */
        private static final ConcatEagerNode INLINED_CONCAT_CONCAT_EAGER_NODE_ = ConcatEagerNodeGen.inline(InlineTarget.create(ConcatEagerNode.class, CONCAT__CONCAT_NODE_CONCAT_STATE_2_UPDATER.subUpdater(0, 32), CONCAT__CONCAT_NODE_CONCAT_STATE_3_UPDATER.subUpdater(0, 27), CONCAT__CONCAT_NODE_CONCAT_STATE_4_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#doConcat}
         *   Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_CONCAT_OUT_OF_MEMORY_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, CONCAT__CONCAT_NODE_CONCAT_STATE_0_UPDATER.subUpdater(28, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ConcatNode#doConcat}
         *   Parameter: {@link InlinedConditionProfile} lazyProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_CONCAT_LAZY_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, CONCAT__CONCAT_NODE_CONCAT_STATE_0_UPDATER.subUpdater(29, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link ConcatNode#aEmpty}
         *   1: SpecializationActive {@link ConcatNode#aEmptyMutable}
         *   2: SpecializationActive {@link ConcatNode#bEmpty}
         *   3: SpecializationActive {@link ConcatNode#bEmptyMutable}
         *   4: SpecializationActive {@link ConcatNode#doConcat}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link ConcatNode#aEmptyMutable}
         *        Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} attributesNode
         *        Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-28: InlinedCache
         *        Specialization: {@link ConcatNode#aEmptyMutable}
         *        Parameter: {@link FromBufferWithStringCompactionKnownAttributesNode} attributesNode
         *        Inline method: {@link FromBufferWithStringCompactionKnownAttributesNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        @Child private ConcatData concat_cache;

        private ConcatNodeGen() {
        }

        @Override
        public TruffleString execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value, boolean arg3Value) {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[TruffleString.ConcatNode.aEmpty(AbstractTruffleString, TruffleString, Encoding, boolean)] || SpecializationActive[TruffleString.ConcatNode.aEmptyMutable(AbstractTruffleString, MutableTruffleString, Encoding, boolean, FromBufferWithStringCompactionKnownAttributesNode)] || SpecializationActive[TruffleString.ConcatNode.bEmpty(TruffleString, AbstractTruffleString, Encoding, boolean)] || SpecializationActive[TruffleString.ConcatNode.bEmptyMutable(MutableTruffleString, AbstractTruffleString, Encoding, boolean, Node, FromBufferWithStringCompactionKnownAttributesNode)] || SpecializationActive[TruffleString.ConcatNode.doConcat(AbstractTruffleString, AbstractTruffleString, Encoding, boolean, Node, GetPreciseCodeRangeNode, GetPreciseCodeRangeNode, StrideFromCodeRangeNode, ConcatEagerNode, AsTruffleStringNode, AsTruffleStringNode, InlinedBranchProfile, InlinedConditionProfile)] */) {
                if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.ConcatNode.aEmpty(AbstractTruffleString, TruffleString, Encoding, boolean)] || SpecializationActive[TruffleString.ConcatNode.aEmptyMutable(AbstractTruffleString, MutableTruffleString, Encoding, boolean, FromBufferWithStringCompactionKnownAttributesNode)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.ConcatNode.aEmpty(AbstractTruffleString, TruffleString, Encoding, boolean)] */ && arg1Value instanceof TruffleString) {
                        TruffleString arg1Value_ = (TruffleString) arg1Value;
                        if ((TStringGuards.isEmpty(arg0Value))) {
                            return ConcatNode.aEmpty(arg0Value, arg1Value_, arg2Value, arg3Value);
                        }
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.ConcatNode.aEmptyMutable(AbstractTruffleString, MutableTruffleString, Encoding, boolean, FromBufferWithStringCompactionKnownAttributesNode)] */ && arg1Value instanceof MutableTruffleString) {
                        MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                        if ((TStringGuards.isEmpty(arg0Value))) {
                            return aEmptyMutable(arg0Value, arg1Value_, arg2Value, arg3Value, INLINED_ATTRIBUTES_NODE);
                        }
                    }
                }
                if ((state_0 & 0b11100) != 0 /* is SpecializationActive[TruffleString.ConcatNode.bEmpty(TruffleString, AbstractTruffleString, Encoding, boolean)] || SpecializationActive[TruffleString.ConcatNode.bEmptyMutable(MutableTruffleString, AbstractTruffleString, Encoding, boolean, Node, FromBufferWithStringCompactionKnownAttributesNode)] || SpecializationActive[TruffleString.ConcatNode.doConcat(AbstractTruffleString, AbstractTruffleString, Encoding, boolean, Node, GetPreciseCodeRangeNode, GetPreciseCodeRangeNode, StrideFromCodeRangeNode, ConcatEagerNode, AsTruffleStringNode, AsTruffleStringNode, InlinedBranchProfile, InlinedConditionProfile)] */) {
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleString.ConcatNode.bEmpty(TruffleString, AbstractTruffleString, Encoding, boolean)] */ && arg0Value instanceof TruffleString) {
                        TruffleString arg0Value_ = (TruffleString) arg0Value;
                        if ((TStringGuards.isEmpty(arg1Value))) {
                            return ConcatNode.bEmpty(arg0Value_, arg1Value, arg2Value, arg3Value);
                        }
                    }
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleString.ConcatNode.bEmptyMutable(MutableTruffleString, AbstractTruffleString, Encoding, boolean, Node, FromBufferWithStringCompactionKnownAttributesNode)] */ && arg0Value instanceof MutableTruffleString) {
                        MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                        if ((TStringGuards.isEmpty(arg1Value))) {
                            Node node__ = (this);
                            return ConcatNode.bEmptyMutable(arg0Value_, arg1Value, arg2Value, arg3Value, node__, INLINED_ATTRIBUTES_NODE);
                        }
                    }
                    if ((state_0 & 0b10000) != 0 /* is SpecializationActive[TruffleString.ConcatNode.doConcat(AbstractTruffleString, AbstractTruffleString, Encoding, boolean, Node, GetPreciseCodeRangeNode, GetPreciseCodeRangeNode, StrideFromCodeRangeNode, ConcatEagerNode, AsTruffleStringNode, AsTruffleStringNode, InlinedBranchProfile, InlinedConditionProfile)] */) {
                        ConcatData s4_ = this.concat_cache;
                        if (s4_ != null) {
                            if ((!(TStringGuards.isEmpty(arg0Value))) && (!(TStringGuards.isEmpty(arg1Value)))) {
                                Node node__1 = (s4_);
                                return ConcatNode.doConcat(arg0Value, arg1Value, arg2Value, arg3Value, node__1, INLINED_CONCAT_GET_CODE_RANGE_A_NODE_, INLINED_CONCAT_GET_CODE_RANGE_B_NODE_, INLINED_CONCAT_GET_STRIDE_NODE_, INLINED_CONCAT_CONCAT_EAGER_NODE_, s4_.asTruffleStringANode_, s4_.asTruffleStringBNode_, INLINED_CONCAT_OUT_OF_MEMORY_PROFILE_, INLINED_CONCAT_LAZY_PROFILE_);
                            }
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
        }

        private TruffleString executeAndSpecialize(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value, boolean arg3Value) {
            int state_0 = this.state_0_;
            if (arg1Value instanceof TruffleString) {
                TruffleString arg1Value_ = (TruffleString) arg1Value;
                if ((TStringGuards.isEmpty(arg0Value))) {
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.ConcatNode.aEmpty(AbstractTruffleString, TruffleString, Encoding, boolean)] */;
                    this.state_0_ = state_0;
                    return ConcatNode.aEmpty(arg0Value, arg1Value_, arg2Value, arg3Value);
                }
            }
            if (arg1Value instanceof MutableTruffleString) {
                MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                if ((TStringGuards.isEmpty(arg0Value))) {
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.ConcatNode.aEmptyMutable(AbstractTruffleString, MutableTruffleString, Encoding, boolean, FromBufferWithStringCompactionKnownAttributesNode)] */;
                    this.state_0_ = state_0;
                    return aEmptyMutable(arg0Value, arg1Value_, arg2Value, arg3Value, INLINED_ATTRIBUTES_NODE);
                }
            }
            if (arg0Value instanceof TruffleString) {
                TruffleString arg0Value_ = (TruffleString) arg0Value;
                if ((TStringGuards.isEmpty(arg1Value))) {
                    state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleString.ConcatNode.bEmpty(TruffleString, AbstractTruffleString, Encoding, boolean)] */;
                    this.state_0_ = state_0;
                    return ConcatNode.bEmpty(arg0Value_, arg1Value, arg2Value, arg3Value);
                }
            }
            {
                Node node__ = null;
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((TStringGuards.isEmpty(arg1Value))) {
                        node__ = (this);
                        state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleString.ConcatNode.bEmptyMutable(MutableTruffleString, AbstractTruffleString, Encoding, boolean, Node, FromBufferWithStringCompactionKnownAttributesNode)] */;
                        this.state_0_ = state_0;
                        return ConcatNode.bEmptyMutable(arg0Value_, arg1Value, arg2Value, arg3Value, node__, INLINED_ATTRIBUTES_NODE);
                    }
                }
            }
            {
                Node node__1 = null;
                if ((!(TStringGuards.isEmpty(arg0Value))) && (!(TStringGuards.isEmpty(arg1Value)))) {
                    ConcatData s4_ = this.insert(new ConcatData());
                    node__1 = (s4_);
                    AsTruffleStringNode asTruffleStringANode__ = s4_.insert((AsTruffleStringNode.create()));
                    Objects.requireNonNull(asTruffleStringANode__, "Specialization 'doConcat(AbstractTruffleString, AbstractTruffleString, Encoding, boolean, Node, GetPreciseCodeRangeNode, GetPreciseCodeRangeNode, StrideFromCodeRangeNode, ConcatEagerNode, AsTruffleStringNode, AsTruffleStringNode, InlinedBranchProfile, InlinedConditionProfile)' cache 'asTruffleStringANode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                    s4_.asTruffleStringANode_ = asTruffleStringANode__;
                    AsTruffleStringNode asTruffleStringBNode__ = s4_.insert((AsTruffleStringNode.create()));
                    Objects.requireNonNull(asTruffleStringBNode__, "Specialization 'doConcat(AbstractTruffleString, AbstractTruffleString, Encoding, boolean, Node, GetPreciseCodeRangeNode, GetPreciseCodeRangeNode, StrideFromCodeRangeNode, ConcatEagerNode, AsTruffleStringNode, AsTruffleStringNode, InlinedBranchProfile, InlinedConditionProfile)' cache 'asTruffleStringBNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                    s4_.asTruffleStringBNode_ = asTruffleStringBNode__;
                    VarHandle.storeStoreFence();
                    this.concat_cache = s4_;
                    state_0 = state_0 | 0b10000 /* add SpecializationActive[TruffleString.ConcatNode.doConcat(AbstractTruffleString, AbstractTruffleString, Encoding, boolean, Node, GetPreciseCodeRangeNode, GetPreciseCodeRangeNode, StrideFromCodeRangeNode, ConcatEagerNode, AsTruffleStringNode, AsTruffleStringNode, InlinedBranchProfile, InlinedConditionProfile)] */;
                    this.state_0_ = state_0;
                    return ConcatNode.doConcat(arg0Value, arg1Value, arg2Value, arg3Value, node__1, INLINED_CONCAT_GET_CODE_RANGE_A_NODE_, INLINED_CONCAT_GET_CODE_RANGE_B_NODE_, INLINED_CONCAT_GET_STRIDE_NODE_, INLINED_CONCAT_CONCAT_EAGER_NODE_, asTruffleStringANode__, asTruffleStringBNode__, INLINED_CONCAT_OUT_OF_MEMORY_PROFILE_, INLINED_CONCAT_LAZY_PROFILE_);
                }
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount(state_0);
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static ConcatNode create() {
            return new ConcatNodeGen();
        }

        @NeverDefault
        public static ConcatNode getUncached() {
            return ConcatNodeGen.UNCACHED;
        }

        @GeneratedBy(ConcatNode.class)
        @DenyReplace
        private static final class ConcatData extends Node implements SpecializationDataNode {

            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link ConcatNode#doConcat}
             *        Parameter: {@link GetPreciseCodeRangeNode} getCodeRangeANode
             *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
             *   25-27: InlinedCache
             *        Specialization: {@link ConcatNode#doConcat}
             *        Parameter: {@link StrideFromCodeRangeNode} getStrideNode
             *        Inline method: {@link StrideFromCodeRangeNodeGen#inline}
             *   28: InlinedCache
             *        Specialization: {@link ConcatNode#doConcat}
             *        Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
             *        Inline method: {@link InlinedBranchProfile#inline}
             *   29-30: InlinedCache
             *        Specialization: {@link ConcatNode#doConcat}
             *        Parameter: {@link InlinedConditionProfile} lazyProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int concat_state_0_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link ConcatNode#doConcat}
             *        Parameter: {@link GetPreciseCodeRangeNode} getCodeRangeBNode
             *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int concat_state_1_;
            /**
             * State Info: <pre>
             *   0-31: InlinedCache
             *        Specialization: {@link ConcatNode#doConcat}
             *        Parameter: {@link ConcatEagerNode} concatEagerNode
             *        Inline method: {@link ConcatEagerNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int concat_state_2_;
            /**
             * State Info: <pre>
             *   0-26: InlinedCache
             *        Specialization: {@link ConcatNode#doConcat}
             *        Parameter: {@link ConcatEagerNode} concatEagerNode
             *        Inline method: {@link ConcatEagerNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int concat_state_3_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link ConcatNode#doConcat}
             *        Parameter: {@link ConcatEagerNode} concatEagerNode
             *        Inline method: {@link ConcatEagerNodeGen#inline}
             * </pre>
             */
            @CompilationFinal @UnsafeAccessedField private int concat_state_4_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ConcatNode#doConcat}
             *   Parameter: {@link AsTruffleStringNode} asTruffleStringANode</pre>
             */
            @Child AsTruffleStringNode asTruffleStringANode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ConcatNode#doConcat}
             *   Parameter: {@link AsTruffleStringNode} asTruffleStringBNode</pre>
             */
            @Child AsTruffleStringNode asTruffleStringBNode_;

            ConcatData() {
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

            private static Lookup lookup_() {
                return MethodHandles.lookup();
            }

        }
        @GeneratedBy(ConcatNode.class)
        @DenyReplace
        private static final class Uncached extends ConcatNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value, boolean arg3Value) {
                if (arg1Value instanceof TruffleString) {
                    TruffleString arg1Value_ = (TruffleString) arg1Value;
                    if ((TStringGuards.isEmpty(arg0Value))) {
                        return ConcatNode.aEmpty(arg0Value, arg1Value_, arg2Value, arg3Value);
                    }
                }
                if (arg1Value instanceof MutableTruffleString) {
                    MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                    if ((TStringGuards.isEmpty(arg0Value))) {
                        return aEmptyMutable(arg0Value, arg1Value_, arg2Value, arg3Value, (FromBufferWithStringCompactionKnownAttributesNode.getUncached()));
                    }
                }
                if (arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    if ((TStringGuards.isEmpty(arg1Value))) {
                        return ConcatNode.bEmpty(arg0Value_, arg1Value, arg2Value, arg3Value);
                    }
                }
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((TStringGuards.isEmpty(arg1Value))) {
                        return ConcatNode.bEmptyMutable(arg0Value_, arg1Value, arg2Value, arg3Value, (this), (FromBufferWithStringCompactionKnownAttributesNode.getUncached()));
                    }
                }
                if ((!(TStringGuards.isEmpty(arg0Value))) && (!(TStringGuards.isEmpty(arg1Value)))) {
                    return ConcatNode.doConcat(arg0Value, arg1Value, arg2Value, arg3Value, (this), (GetPreciseCodeRangeNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (StrideFromCodeRangeNodeGen.getUncached()), (ConcatEagerNodeGen.getUncached()), (AsTruffleStringNode.getUncached()), (AsTruffleStringNode.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedConditionProfile.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link RepeatNode#repeat}
     *     Activation probability: 1.00000
     *     With/without class size: 36/14 bytes
     * </pre>
     */
    @GeneratedBy(RepeatNode.class)
    @SuppressWarnings("javadoc")
    static final class RepeatNodeGen extends RepeatNode {

        private static final StateField STATE_0_RepeatNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_RepeatNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_RepeatNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link RepeatNode#repeat}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_RepeatNode_UPDATER.subUpdater(1, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RepeatNode#repeat}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_GET_PRECISE_CODE_RANGE_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_1_RepeatNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RepeatNode#repeat}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_2_RepeatNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RepeatNode#repeat}
         *   Parameter: {@link CalcStringAttributesNode} calcStringAttributesNode
         *   Inline method: {@link CalcStringAttributesNodeGen#inline}</pre>
         */
        private static final CalcStringAttributesNode INLINED_CALC_STRING_ATTRIBUTES_NODE_ = CalcStringAttributesNodeGen.inline(InlineTarget.create(CalcStringAttributesNode.class, STATE_0_RepeatNode_UPDATER.subUpdater(8, 16)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RepeatNode#repeat}
         *   Parameter: {@link InlinedConditionProfile} brokenProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_BROKEN_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_RepeatNode_UPDATER.subUpdater(24, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RepeatNode#repeat}
         *   Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_OUT_OF_MEMORY_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_RepeatNode_UPDATER.subUpdater(26, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RepeatNode#repeat}
         *   Parameter: {@link InlinedBranchProfile} compactProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_COMPACT_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_RepeatNode_UPDATER.subUpdater(27, 1)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link RepeatNode#repeat}
         *   1-7: InlinedCache
         *        Specialization: {@link RepeatNode#repeat}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   8-23: InlinedCache
         *        Specialization: {@link RepeatNode#repeat}
         *        Parameter: {@link CalcStringAttributesNode} calcStringAttributesNode
         *        Inline method: {@link CalcStringAttributesNodeGen#inline}
         *   24-25: InlinedCache
         *        Specialization: {@link RepeatNode#repeat}
         *        Parameter: {@link InlinedConditionProfile} brokenProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   26: InlinedCache
         *        Specialization: {@link RepeatNode#repeat}
         *        Parameter: {@link InlinedBranchProfile} outOfMemoryProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   27: InlinedCache
         *        Specialization: {@link RepeatNode#repeat}
         *        Parameter: {@link InlinedBranchProfile} compactProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link RepeatNode#repeat}
         *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link RepeatNode#repeat}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link RepeatNode#repeat}
         *   Parameter: {@link AsTruffleStringNode} asTruffleStringNode</pre>
         */
        @Child private AsTruffleStringNode asTruffleStringNode_;

        private RepeatNodeGen() {
        }

        @Override
        public TruffleString execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.RepeatNode.repeat(AbstractTruffleString, int, Encoding, AsTruffleStringNode, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */) {
                {
                    AsTruffleStringNode asTruffleStringNode__ = this.asTruffleStringNode_;
                    if (asTruffleStringNode__ != null) {
                        return repeat(arg0Value, arg1Value, arg2Value, asTruffleStringNode__, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_PRECISE_CODE_RANGE_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_CALC_STRING_ATTRIBUTES_NODE_, INLINED_BROKEN_PROFILE_, INLINED_OUT_OF_MEMORY_PROFILE_, INLINED_COMPACT_PROFILE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private TruffleString executeAndSpecialize(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value) {
            int state_0 = this.state_0_;
            AsTruffleStringNode asTruffleStringNode__ = this.insert((AsTruffleStringNode.create()));
            Objects.requireNonNull(asTruffleStringNode__, "Specialization 'repeat(AbstractTruffleString, int, Encoding, AsTruffleStringNode, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)' cache 'asTruffleStringNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.asTruffleStringNode_ = asTruffleStringNode__;
            state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.RepeatNode.repeat(AbstractTruffleString, int, Encoding, AsTruffleStringNode, ToIndexableNode, GetPreciseCodeRangeNode, GetCodePointLengthNode, CalcStringAttributesNode, InlinedConditionProfile, InlinedBranchProfile, InlinedBranchProfile)] */;
            this.state_0_ = state_0;
            return repeat(arg0Value, arg1Value, arg2Value, asTruffleStringNode__, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_PRECISE_CODE_RANGE_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_CALC_STRING_ATTRIBUTES_NODE_, INLINED_BROKEN_PROFILE_, INLINED_OUT_OF_MEMORY_PROFILE_, INLINED_COMPACT_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static RepeatNode create() {
            return new RepeatNodeGen();
        }

        @NeverDefault
        public static RepeatNode getUncached() {
            return RepeatNodeGen.UNCACHED;
        }

        @GeneratedBy(RepeatNode.class)
        @DenyReplace
        private static final class Uncached extends RepeatNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(AbstractTruffleString arg0Value, int arg1Value, Encoding arg2Value) {
                return repeat(arg0Value, arg1Value, arg2Value, (AsTruffleStringNode.getUncached()), (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (CalcStringAttributesNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedBranchProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
     *     Activation probability: 1.00000
     *     With/without class size: 32/12 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.SubstringNode.class)
    @SuppressWarnings("javadoc")
    static final class SubstringNodeGen extends com.oracle.truffle.api.strings.TruffleString.SubstringNode {

        private static final StateField STATE_0_SubstringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_SubstringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_SubstringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_SubstringNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_SubstringNode_UPDATER.subUpdater(7, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_1_SubstringNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *   Parameter: {@link CodePointIndexToRawNode} translateIndexNode
         *   Inline method: {@link CodePointIndexToRawNodeGen#inline}</pre>
         */
        private static final CodePointIndexToRawNode INLINED_TRANSLATE_INDEX_NODE_ = CodePointIndexToRawNodeGen.inline(InlineTarget.create(CodePointIndexToRawNode.class, STATE_1_SubstringNode_UPDATER.subUpdater(25, 6)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.SubstringNode} substringNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.SubstringNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.SubstringNode INLINED_SUBSTRING_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.SubstringNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.SubstringNode.class, STATE_2_SubstringNode_UPDATER.subUpdater(0, 28)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         *   25-30: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *        Parameter: {@link CodePointIndexToRawNode} translateIndexNode
         *        Inline method: {@link CodePointIndexToRawNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-27: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.SubstringNode#substring}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.SubstringNode} substringNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.SubstringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;

        private SubstringNodeGen() {
        }

        @Override
        public TruffleString execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            return substring(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_A_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE_, INLINED_TRANSLATE_INDEX_NODE_, INLINED_SUBSTRING_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.SubstringNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.SubstringNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.SubstringNode getUncached() {
            return SubstringNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.SubstringNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.SubstringNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
                return substring(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (CodePointIndexToRawNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.SubstringNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link SubstringByteIndexNode#substringEmpty}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link SubstringByteIndexNode#substringRaw}
     *     Activation probability: 0.35000
     *     With/without class size: 12/5 bytes
     * </pre>
     */
    @GeneratedBy(SubstringByteIndexNode.class)
    @SuppressWarnings("javadoc")
    static final class SubstringByteIndexNodeGen extends SubstringByteIndexNode {

        private static final StateField STATE_0_SubstringByteIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_SubstringByteIndexNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link SubstringByteIndexNode#substringRaw}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_SUBSTRING_RAW_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_SubstringByteIndexNode_UPDATER.subUpdater(2, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link SubstringByteIndexNode#substringRaw}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.SubstringNode} substringNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.SubstringNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.SubstringNode INLINED_SUBSTRING_RAW_SUBSTRING_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.SubstringNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.SubstringNode.class, STATE_1_SubstringByteIndexNode_UPDATER.subUpdater(0, 28)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link SubstringByteIndexNode#substringEmpty}
         *   1: SpecializationActive {@link SubstringByteIndexNode#substringRaw}
         *   2-8: InlinedCache
         *        Specialization: {@link SubstringByteIndexNode#substringRaw}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-27: InlinedCache
         *        Specialization: {@link SubstringByteIndexNode#substringRaw}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.SubstringNode} substringNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.SubstringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;

        private SubstringByteIndexNodeGen() {
        }

        @Override
        public TruffleString execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.SubstringByteIndexNode.substringEmpty(AbstractTruffleString, int, int, Encoding, boolean)] || SpecializationActive[TruffleString.SubstringByteIndexNode.substringRaw(AbstractTruffleString, int, int, Encoding, boolean, ToIndexableNode, SubstringNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.SubstringByteIndexNode.substringEmpty(AbstractTruffleString, int, int, Encoding, boolean)] */) {
                    if ((SubstringByteIndexNode.isSame(arg2Value, 0))) {
                        return SubstringByteIndexNode.substringEmpty(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.SubstringByteIndexNode.substringRaw(AbstractTruffleString, int, int, Encoding, boolean, ToIndexableNode, SubstringNode)] */) {
                    if ((arg2Value != 0)) {
                        return substringRaw(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_SUBSTRING_RAW_TO_INDEXABLE_NODE_, INLINED_SUBSTRING_RAW_SUBSTRING_NODE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
        }

        private TruffleString executeAndSpecialize(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
            int state_0 = this.state_0_;
            if ((SubstringByteIndexNode.isSame(arg2Value, 0))) {
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.SubstringByteIndexNode.substringEmpty(AbstractTruffleString, int, int, Encoding, boolean)] */;
                this.state_0_ = state_0;
                return SubstringByteIndexNode.substringEmpty(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
            }
            if ((arg2Value != 0)) {
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.SubstringByteIndexNode.substringRaw(AbstractTruffleString, int, int, Encoding, boolean, ToIndexableNode, SubstringNode)] */;
                this.state_0_ = state_0;
                return substringRaw(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, INLINED_SUBSTRING_RAW_TO_INDEXABLE_NODE_, INLINED_SUBSTRING_RAW_SUBSTRING_NODE_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount((state_0 & 0b11));
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static SubstringByteIndexNode create() {
            return new SubstringByteIndexNodeGen();
        }

        @NeverDefault
        public static SubstringByteIndexNode getUncached() {
            return SubstringByteIndexNodeGen.UNCACHED;
        }

        @GeneratedBy(SubstringByteIndexNode.class)
        @DenyReplace
        private static final class Uncached extends SubstringByteIndexNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(AbstractTruffleString arg0Value, int arg1Value, int arg2Value, Encoding arg3Value, boolean arg4Value) {
                if ((SubstringByteIndexNode.isSame(arg2Value, 0))) {
                    return SubstringByteIndexNode.substringEmpty(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
                }
                if ((arg2Value != 0)) {
                    return substringRaw(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (ToIndexableNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.SubstringNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link EqualNode#sameObject}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link EqualNode#check}
     *     Activation probability: 0.35000
     *     With/without class size: 11/3 bytes
     * </pre>
     */
    @GeneratedBy(EqualNode.class)
    @SuppressWarnings("javadoc")
    static final class EqualNodeGen extends EqualNode {

        private static final StateField STATE_0_EqualNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link EqualNode#check}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeA
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_CHECK_TO_INDEXABLE_NODE_A_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_EqualNode_UPDATER.subUpdater(2, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link EqualNode#check}
         *   Parameter: {@link ToIndexableNode} toIndexableNodeB
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_CHECK_TO_INDEXABLE_NODE_B_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_EqualNode_UPDATER.subUpdater(9, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link EqualNode#check}
         *   Parameter: {@link InlinedConditionProfile} lengthAndCodeRangeCheckProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_CHECK_LENGTH_AND_CODE_RANGE_CHECK_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_EqualNode_UPDATER.subUpdater(16, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link EqualNode#check}
         *   Parameter: {@link InlinedBranchProfile} compareHashProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_CHECK_COMPARE_HASH_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_EqualNode_UPDATER.subUpdater(18, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link EqualNode#check}
         *   Parameter: {@link InlinedConditionProfile} checkFirstByteProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_CHECK_CHECK_FIRST_BYTE_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_EqualNode_UPDATER.subUpdater(19, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link EqualNode#sameObject}
         *   1: SpecializationActive {@link EqualNode#check}
         *   2-8: InlinedCache
         *        Specialization: {@link EqualNode#check}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeA
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   9-15: InlinedCache
         *        Specialization: {@link EqualNode#check}
         *        Parameter: {@link ToIndexableNode} toIndexableNodeB
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   16-17: InlinedCache
         *        Specialization: {@link EqualNode#check}
         *        Parameter: {@link InlinedConditionProfile} lengthAndCodeRangeCheckProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   18: InlinedCache
         *        Specialization: {@link EqualNode#check}
         *        Parameter: {@link InlinedBranchProfile} compareHashProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   19-20: InlinedCache
         *        Specialization: {@link EqualNode#check}
         *        Parameter: {@link InlinedConditionProfile} checkFirstByteProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private EqualNodeGen() {
        }

        @Override
        public boolean execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.EqualNode.sameObject(AbstractTruffleString, AbstractTruffleString, Encoding)] || SpecializationActive[TruffleString.EqualNode.check(AbstractTruffleString, AbstractTruffleString, Encoding, ToIndexableNode, ToIndexableNode, InlinedConditionProfile, InlinedBranchProfile, InlinedConditionProfile)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.EqualNode.sameObject(AbstractTruffleString, AbstractTruffleString, Encoding)] */) {
                    if ((TStringGuards.identical(arg0Value, arg1Value))) {
                        return EqualNode.sameObject(arg0Value, arg1Value, arg2Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.EqualNode.check(AbstractTruffleString, AbstractTruffleString, Encoding, ToIndexableNode, ToIndexableNode, InlinedConditionProfile, InlinedBranchProfile, InlinedConditionProfile)] */) {
                    if ((!(TStringGuards.identical(arg0Value, arg1Value)))) {
                        return check(arg0Value, arg1Value, arg2Value, INLINED_CHECK_TO_INDEXABLE_NODE_A_, INLINED_CHECK_TO_INDEXABLE_NODE_B_, INLINED_CHECK_LENGTH_AND_CODE_RANGE_CHECK_PROFILE_, INLINED_CHECK_COMPARE_HASH_PROFILE_, INLINED_CHECK_CHECK_FIRST_BYTE_PROFILE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private boolean executeAndSpecialize(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
            int state_0 = this.state_0_;
            if ((TStringGuards.identical(arg0Value, arg1Value))) {
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.EqualNode.sameObject(AbstractTruffleString, AbstractTruffleString, Encoding)] */;
                this.state_0_ = state_0;
                return EqualNode.sameObject(arg0Value, arg1Value, arg2Value);
            }
            if ((!(TStringGuards.identical(arg0Value, arg1Value)))) {
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.EqualNode.check(AbstractTruffleString, AbstractTruffleString, Encoding, ToIndexableNode, ToIndexableNode, InlinedConditionProfile, InlinedBranchProfile, InlinedConditionProfile)] */;
                this.state_0_ = state_0;
                return check(arg0Value, arg1Value, arg2Value, INLINED_CHECK_TO_INDEXABLE_NODE_A_, INLINED_CHECK_TO_INDEXABLE_NODE_B_, INLINED_CHECK_LENGTH_AND_CODE_RANGE_CHECK_PROFILE_, INLINED_CHECK_COMPARE_HASH_PROFILE_, INLINED_CHECK_CHECK_FIRST_BYTE_PROFILE_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if (((state_0 & 0b11) & ((state_0 & 0b11) - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static EqualNode create() {
            return new EqualNodeGen();
        }

        @NeverDefault
        public static EqualNode getUncached() {
            return EqualNodeGen.UNCACHED;
        }

        @GeneratedBy(EqualNode.class)
        @DenyReplace
        private static final class Uncached extends EqualNode {

            @TruffleBoundary
            @Override
            public boolean execute(AbstractTruffleString arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value) {
                if ((TStringGuards.identical(arg0Value, arg1Value))) {
                    return EqualNode.sameObject(arg0Value, arg1Value, arg2Value);
                }
                if ((!(TStringGuards.identical(arg0Value, arg1Value)))) {
                    return check(arg0Value, arg1Value, arg2Value, (ToIndexableNodeGen.getUncached()), (ToIndexableNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedBranchProfile.getUncached()), (InlinedConditionProfile.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doLazyLong}
     *     Activation probability: 0.65000
     *     With/without class size: 17/1 bytes
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
     *     Activation probability: 0.35000
     *     With/without class size: 15/13 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ParseIntNode.class)
    @SuppressWarnings("javadoc")
    static final class ParseIntNodeGen extends com.oracle.truffle.api.strings.TruffleString.ParseIntNode {

        private static final StateField STATE_0_ParseIntNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_ParseIntNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_ParseIntNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doLazyLong}
         *   Parameter: {@link InlinedBranchProfile} errorProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_LAZY_LONG_ERROR_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_ParseIntNode_UPDATER.subUpdater(2, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_PARSE_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ParseIntNode_UPDATER.subUpdater(3, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *   Parameter: {@link GetPreciseCodeRangeNode} getCodeRangeANode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_PARSE_GET_CODE_RANGE_A_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_1_ParseIntNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ParseIntNode} parseIntNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseIntNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.ParseIntNode INLINED_PARSE_PARSE_INT_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseIntNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.ParseIntNode.class, STATE_0_ParseIntNode_UPDATER.subUpdater(10, 17), STATE_2_ParseIntNode_UPDATER.subUpdater(0, 21)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *   Parameter: {@link InlinedIntValueProfile} radixProfile
         *   Inline method: {@link InlinedIntValueProfile#inline}</pre>
         */
        private static final InlinedIntValueProfile INLINED_PARSE_RADIX_PROFILE_ = InlinedIntValueProfile.inline(InlineTarget.create(InlinedIntValueProfile.class, STATE_0_ParseIntNode_UPDATER.subUpdater(27, 2), IntField.create(MethodHandles.lookup(), "parse_radixProfile__field1_")));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doLazyLong}
         *   1: SpecializationActive {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *   2: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doLazyLong}
         *        Parameter: {@link InlinedBranchProfile} errorProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   3-9: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   10-26: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ParseIntNode} parseIntNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseIntNodeGen#inline}
         *   27-28: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *        Parameter: {@link InlinedIntValueProfile} radixProfile
         *        Inline method: {@link InlinedIntValueProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *        Parameter: {@link GetPreciseCodeRangeNode} getCodeRangeANode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-20: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ParseIntNode} parseIntNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseIntNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseIntNode#doParse}
         *   Parameter: {@link InlinedIntValueProfile} radixProfile
         *   Inline method: {@link InlinedIntValueProfile#inline}
         *   Inline field: int field1</pre>
         */
        @CompilationFinal @UnsafeAccessedField @SuppressWarnings("unused") private int parse_radixProfile__field1_;

        private ParseIntNodeGen() {
        }

        @Override
        public int execute(AbstractTruffleString arg0Value, int arg1Value) throws NumberFormatException {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.ParseIntNode.doLazyLong(AbstractTruffleString, int, InlinedBranchProfile)] || SpecializationActive[TruffleString.ParseIntNode.doParse(AbstractTruffleString, int, ToIndexableNode, GetPreciseCodeRangeNode, ParseIntNode, InlinedIntValueProfile)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.ParseIntNode.doLazyLong(AbstractTruffleString, int, InlinedBranchProfile)] */) {
                    if ((arg0Value.isLazyLong()) && (arg1Value == 10)) {
                        return doLazyLong(arg0Value, arg1Value, INLINED_LAZY_LONG_ERROR_PROFILE_);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.ParseIntNode.doParse(AbstractTruffleString, int, ToIndexableNode, GetPreciseCodeRangeNode, ParseIntNode, InlinedIntValueProfile)] */) {
                    if ((!(arg0Value.isLazyLong()) || arg1Value != 10)) {
                        return doParse(arg0Value, arg1Value, INLINED_PARSE_TO_INDEXABLE_NODE_, INLINED_PARSE_GET_CODE_RANGE_A_NODE_, INLINED_PARSE_PARSE_INT_NODE_, INLINED_PARSE_RADIX_PROFILE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private int executeAndSpecialize(AbstractTruffleString arg0Value, int arg1Value) throws NumberFormatException {
            int state_0 = this.state_0_;
            if ((arg0Value.isLazyLong()) && (arg1Value == 10)) {
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.ParseIntNode.doLazyLong(AbstractTruffleString, int, InlinedBranchProfile)] */;
                this.state_0_ = state_0;
                return doLazyLong(arg0Value, arg1Value, INLINED_LAZY_LONG_ERROR_PROFILE_);
            }
            if ((!(arg0Value.isLazyLong()) || arg1Value != 10)) {
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.ParseIntNode.doParse(AbstractTruffleString, int, ToIndexableNode, GetPreciseCodeRangeNode, ParseIntNode, InlinedIntValueProfile)] */;
                this.state_0_ = state_0;
                return doParse(arg0Value, arg1Value, INLINED_PARSE_TO_INDEXABLE_NODE_, INLINED_PARSE_GET_CODE_RANGE_A_NODE_, INLINED_PARSE_PARSE_INT_NODE_, INLINED_PARSE_RADIX_PROFILE_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount((state_0 & 0b11));
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ParseIntNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.ParseIntNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ParseIntNode getUncached() {
            return ParseIntNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ParseIntNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.ParseIntNode {

            @TruffleBoundary
            @Override
            public int execute(AbstractTruffleString arg0Value, int arg1Value) throws NumberFormatException {
                if ((arg0Value.isLazyLong()) && (arg1Value == 10)) {
                    return doLazyLong(arg0Value, arg1Value, (InlinedBranchProfile.getUncached()));
                }
                if ((!(arg0Value.isLazyLong()) || arg1Value != 10)) {
                    return doParse(arg0Value, arg1Value, (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseIntNodeGen.getUncached()), (InlinedIntValueProfile.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doLazyLong}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
     *     Activation probability: 0.35000
     *     With/without class size: 15/13 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ParseLongNode.class)
    @SuppressWarnings("javadoc")
    static final class ParseLongNodeGen extends com.oracle.truffle.api.strings.TruffleString.ParseLongNode {

        private static final StateField STATE_0_ParseLongNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_ParseLongNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_ParseLongNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_PARSE_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ParseLongNode_UPDATER.subUpdater(2, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *   Parameter: {@link GetPreciseCodeRangeNode} getCodeRangeANode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_PARSE_GET_CODE_RANGE_A_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_1_ParseLongNode_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ParseLongNode} parseLongNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseLongNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.ParseLongNode INLINED_PARSE_PARSE_LONG_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseLongNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.ParseLongNode.class, STATE_2_ParseLongNode_UPDATER.subUpdater(0, 17), STATE_0_ParseLongNode_UPDATER.subUpdater(9, 21)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *   Parameter: {@link InlinedIntValueProfile} radixProfile
         *   Inline method: {@link InlinedIntValueProfile#inline}</pre>
         */
        private static final InlinedIntValueProfile INLINED_PARSE_RADIX_PROFILE_ = InlinedIntValueProfile.inline(InlineTarget.create(InlinedIntValueProfile.class, STATE_0_ParseLongNode_UPDATER.subUpdater(30, 2), IntField.create(MethodHandles.lookup(), "parse_radixProfile__field1_")));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doLazyLong}
         *   1: SpecializationActive {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *   2-8: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   9-29: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ParseLongNode} parseLongNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseLongNodeGen#inline}
         *   30-31: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *        Parameter: {@link InlinedIntValueProfile} radixProfile
         *        Inline method: {@link InlinedIntValueProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *        Parameter: {@link GetPreciseCodeRangeNode} getCodeRangeANode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-16: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ParseLongNode} parseLongNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseLongNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseLongNode#doParse}
         *   Parameter: {@link InlinedIntValueProfile} radixProfile
         *   Inline method: {@link InlinedIntValueProfile#inline}
         *   Inline field: int field1</pre>
         */
        @CompilationFinal @UnsafeAccessedField @SuppressWarnings("unused") private int parse_radixProfile__field1_;

        private ParseLongNodeGen() {
        }

        @Override
        public long execute(AbstractTruffleString arg0Value, int arg1Value) throws NumberFormatException {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.ParseLongNode.doLazyLong(AbstractTruffleString, int)] || SpecializationActive[TruffleString.ParseLongNode.doParse(AbstractTruffleString, int, ToIndexableNode, GetPreciseCodeRangeNode, ParseLongNode, InlinedIntValueProfile)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.ParseLongNode.doLazyLong(AbstractTruffleString, int)] */) {
                    if ((arg0Value.isLazyLong()) && (arg1Value == 10)) {
                        return com.oracle.truffle.api.strings.TruffleString.ParseLongNode.doLazyLong(arg0Value, arg1Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.ParseLongNode.doParse(AbstractTruffleString, int, ToIndexableNode, GetPreciseCodeRangeNode, ParseLongNode, InlinedIntValueProfile)] */) {
                    if ((!(arg0Value.isLazyLong()) || arg1Value != 10)) {
                        return doParse(arg0Value, arg1Value, INLINED_PARSE_TO_INDEXABLE_NODE_, INLINED_PARSE_GET_CODE_RANGE_A_NODE_, INLINED_PARSE_PARSE_LONG_NODE_, INLINED_PARSE_RADIX_PROFILE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private long executeAndSpecialize(AbstractTruffleString arg0Value, int arg1Value) throws NumberFormatException {
            int state_0 = this.state_0_;
            if ((arg0Value.isLazyLong()) && (arg1Value == 10)) {
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.ParseLongNode.doLazyLong(AbstractTruffleString, int)] */;
                this.state_0_ = state_0;
                return com.oracle.truffle.api.strings.TruffleString.ParseLongNode.doLazyLong(arg0Value, arg1Value);
            }
            if ((!(arg0Value.isLazyLong()) || arg1Value != 10)) {
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.ParseLongNode.doParse(AbstractTruffleString, int, ToIndexableNode, GetPreciseCodeRangeNode, ParseLongNode, InlinedIntValueProfile)] */;
                this.state_0_ = state_0;
                return doParse(arg0Value, arg1Value, INLINED_PARSE_TO_INDEXABLE_NODE_, INLINED_PARSE_GET_CODE_RANGE_A_NODE_, INLINED_PARSE_PARSE_LONG_NODE_, INLINED_PARSE_RADIX_PROFILE_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount((state_0 & 0b11));
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ParseLongNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.ParseLongNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ParseLongNode getUncached() {
            return ParseLongNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ParseLongNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.ParseLongNode {

            @TruffleBoundary
            @Override
            public long execute(AbstractTruffleString arg0Value, int arg1Value) throws NumberFormatException {
                if ((arg0Value.isLazyLong()) && (arg1Value == 10)) {
                    return com.oracle.truffle.api.strings.TruffleString.ParseLongNode.doLazyLong(arg0Value, arg1Value);
                }
                if ((!(arg0Value.isLazyLong()) || arg1Value != 10)) {
                    return doParse(arg0Value, arg1Value, (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseLongNodeGen.getUncached()), (InlinedIntValueProfile.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode#doLazyLong}
     *     Activation probability: 0.65000
     *     With/without class size: 11/0 bytes
     *   Specialization {@link com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode#parseDouble}
     *     Activation probability: 0.35000
     *     With/without class size: 11/3 bytes
     * </pre>
     */
    @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.class)
    @SuppressWarnings("javadoc")
    static final class ParseDoubleNodeGen extends com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode {

        private static final StateField STATE_0_ParseDoubleNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode#parseDouble}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_PARSE_DOUBLE_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ParseDoubleNode_UPDATER.subUpdater(2, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode#parseDouble}
         *   Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ParseDoubleNode} parseDoubleNode
         *   Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseDoubleNodeGen#inline}</pre>
         */
        private static final com.oracle.truffle.api.strings.TStringInternalNodes.ParseDoubleNode INLINED_PARSE_DOUBLE_PARSE_DOUBLE_NODE_ = com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseDoubleNodeGen.inline(InlineTarget.create(com.oracle.truffle.api.strings.TStringInternalNodes.ParseDoubleNode.class, STATE_0_ParseDoubleNode_UPDATER.subUpdater(9, 15)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode#doLazyLong}
         *   1: SpecializationActive {@link com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode#parseDouble}
         *   2-8: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode#parseDouble}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   9-23: InlinedCache
         *        Specialization: {@link com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode#parseDouble}
         *        Parameter: {@link com.oracle.truffle.api.strings.TStringInternalNodes.ParseDoubleNode} parseDoubleNode
         *        Inline method: {@link com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseDoubleNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private ParseDoubleNodeGen() {
        }

        @Override
        public double execute(AbstractTruffleString arg0Value) throws NumberFormatException {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.ParseDoubleNode.doLazyLong(AbstractTruffleString)] || SpecializationActive[TruffleString.ParseDoubleNode.parseDouble(AbstractTruffleString, ToIndexableNode, ParseDoubleNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.ParseDoubleNode.doLazyLong(AbstractTruffleString)] */) {
                    if ((com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.isLazyLongSafeInteger(arg0Value))) {
                        return com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.doLazyLong(arg0Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.ParseDoubleNode.parseDouble(AbstractTruffleString, ToIndexableNode, ParseDoubleNode)] */) {
                    if ((!(com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.isLazyLongSafeInteger(arg0Value)))) {
                        return parseDouble(arg0Value, INLINED_PARSE_DOUBLE_TO_INDEXABLE_NODE_, INLINED_PARSE_DOUBLE_PARSE_DOUBLE_NODE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private double executeAndSpecialize(AbstractTruffleString arg0Value) throws NumberFormatException {
            int state_0 = this.state_0_;
            if ((com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.isLazyLongSafeInteger(arg0Value))) {
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.ParseDoubleNode.doLazyLong(AbstractTruffleString)] */;
                this.state_0_ = state_0;
                return com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.doLazyLong(arg0Value);
            }
            if ((!(com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.isLazyLongSafeInteger(arg0Value)))) {
                state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.ParseDoubleNode.parseDouble(AbstractTruffleString, ToIndexableNode, ParseDoubleNode)] */;
                this.state_0_ = state_0;
                return parseDouble(arg0Value, INLINED_PARSE_DOUBLE_TO_INDEXABLE_NODE_, INLINED_PARSE_DOUBLE_PARSE_DOUBLE_NODE_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if (((state_0 & 0b11) & ((state_0 & 0b11) - 1)) == 0 /* is-single  */) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode create() {
            return new com.oracle.truffle.api.strings.TruffleStringFactory.ParseDoubleNodeGen();
        }

        @NeverDefault
        public static com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode getUncached() {
            return ParseDoubleNodeGen.UNCACHED;
        }

        @GeneratedBy(com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.class)
        @DenyReplace
        private static final class Uncached extends com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode {

            @TruffleBoundary
            @Override
            public double execute(AbstractTruffleString arg0Value) throws NumberFormatException {
                if ((com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.isLazyLongSafeInteger(arg0Value))) {
                    return com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.doLazyLong(arg0Value);
                }
                if ((!(com.oracle.truffle.api.strings.TruffleString.ParseDoubleNode.isLazyLongSafeInteger(arg0Value)))) {
                    return parseDouble(arg0Value, (ToIndexableNodeGen.getUncached()), (com.oracle.truffle.api.strings.TStringInternalNodesFactory.ParseDoubleNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link GetInternalByteArrayNode#getInternalByteArray}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(GetInternalByteArrayNode.class)
    @SuppressWarnings("javadoc")
    static final class GetInternalByteArrayNodeGen extends GetInternalByteArrayNode {

        private static final StateField STATE_0_GetInternalByteArrayNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_GetInternalByteArrayNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *   Parameter: {@link InlinedConditionProfile} utf16Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF16_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_GetInternalByteArrayNode_UPDATER.subUpdater(7, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *   Parameter: {@link InlinedConditionProfile} utf16S0Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF16_S0_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_GetInternalByteArrayNode_UPDATER.subUpdater(9, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *   Parameter: {@link InlinedConditionProfile} utf32Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_GetInternalByteArrayNode_UPDATER.subUpdater(11, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *   Parameter: {@link InlinedConditionProfile} utf32S0Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_S0_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_GetInternalByteArrayNode_UPDATER.subUpdater(13, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *   Parameter: {@link InlinedConditionProfile} utf32S1Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_S1_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_GetInternalByteArrayNode_UPDATER.subUpdater(15, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *   Parameter: {@link InlinedConditionProfile} isByteArrayProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_IS_BYTE_ARRAY_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_GetInternalByteArrayNode_UPDATER.subUpdater(17, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-8: InlinedCache
         *        Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *        Parameter: {@link InlinedConditionProfile} utf16Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   9-10: InlinedCache
         *        Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *        Parameter: {@link InlinedConditionProfile} utf16S0Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   11-12: InlinedCache
         *        Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *        Parameter: {@link InlinedConditionProfile} utf32Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   13-14: InlinedCache
         *        Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *        Parameter: {@link InlinedConditionProfile} utf32S0Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   15-16: InlinedCache
         *        Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *        Parameter: {@link InlinedConditionProfile} utf32S1Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   17-18: InlinedCache
         *        Specialization: {@link GetInternalByteArrayNode#getInternalByteArray}
         *        Parameter: {@link InlinedConditionProfile} isByteArrayProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private GetInternalByteArrayNodeGen() {
        }

        @Override
        public InternalByteArray execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return getInternalByteArray(arg0Value, arg1Value, INLINED_TO_INDEXABLE_NODE_, INLINED_UTF16_PROFILE_, INLINED_UTF16_S0_PROFILE_, INLINED_UTF32_PROFILE_, INLINED_UTF32_S0_PROFILE_, INLINED_UTF32_S1_PROFILE_, INLINED_IS_BYTE_ARRAY_PROFILE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static GetInternalByteArrayNode create() {
            return new GetInternalByteArrayNodeGen();
        }

        @NeverDefault
        public static GetInternalByteArrayNode getUncached() {
            return GetInternalByteArrayNodeGen.UNCACHED;
        }

        @GeneratedBy(GetInternalByteArrayNode.class)
        @DenyReplace
        private static final class Uncached extends GetInternalByteArrayNode {

            @TruffleBoundary
            @Override
            public InternalByteArray execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return getInternalByteArray(arg0Value, arg1Value, (ToIndexableNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link GetInternalNativePointerNode#getNativePointer}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(GetInternalNativePointerNode.class)
    @SuppressWarnings("javadoc")
    static final class GetInternalNativePointerNodeGen extends GetInternalNativePointerNode {

        private static final Uncached UNCACHED = new Uncached();

        private GetInternalNativePointerNodeGen() {
        }

        @Override
        public Object execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
            return GetInternalNativePointerNode.getNativePointer(arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static GetInternalNativePointerNode create() {
            return new GetInternalNativePointerNodeGen();
        }

        @NeverDefault
        public static GetInternalNativePointerNode getUncached() {
            return GetInternalNativePointerNodeGen.UNCACHED;
        }

        @GeneratedBy(GetInternalNativePointerNode.class)
        @DenyReplace
        private static final class Uncached extends GetInternalNativePointerNode {

            @TruffleBoundary
            @Override
            public Object execute(AbstractTruffleString arg0Value, Encoding arg1Value) {
                return GetInternalNativePointerNode.getNativePointer(arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CopyToByteArrayNode#doCopy}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(CopyToByteArrayNode.class)
    @SuppressWarnings("javadoc")
    static final class CopyToByteArrayNodeGen extends CopyToByteArrayNode {

        private static final StateField STATE_0_CopyToByteArrayNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CopyToByteArrayNode#doCopy}
         *   Parameter: {@link InternalCopyToByteArrayNode} internalNode
         *   Inline method: {@link InternalCopyToByteArrayNodeGen#inline}</pre>
         */
        private static final InternalCopyToByteArrayNode INLINED_INTERNAL_NODE_ = InternalCopyToByteArrayNodeGen.inline(InlineTarget.create(InternalCopyToByteArrayNode.class, STATE_0_CopyToByteArrayNode_UPDATER.subUpdater(0, 17)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-16: InlinedCache
         *        Specialization: {@link CopyToByteArrayNode#doCopy}
         *        Parameter: {@link InternalCopyToByteArrayNode} internalNode
         *        Inline method: {@link InternalCopyToByteArrayNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private CopyToByteArrayNodeGen() {
        }

        @Override
        public void execute(AbstractTruffleString arg0Value, int arg1Value, byte[] arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            doCopy(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, INLINED_INTERNAL_NODE_);
            return;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CopyToByteArrayNode create() {
            return new CopyToByteArrayNodeGen();
        }

        @NeverDefault
        public static CopyToByteArrayNode getUncached() {
            return CopyToByteArrayNodeGen.UNCACHED;
        }

        @GeneratedBy(CopyToByteArrayNode.class)
        @DenyReplace
        private static final class Uncached extends CopyToByteArrayNode {

            @TruffleBoundary
            @Override
            public void execute(AbstractTruffleString arg0Value, int arg1Value, byte[] arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
                doCopy(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, (InternalCopyToByteArrayNodeGen.getUncached()));
                return;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link InternalCopyToByteArrayNode#doCopy}
     *     Activation probability: 1.00000
     *     With/without class size: 24/3 bytes
     * </pre>
     */
    @GeneratedBy(InternalCopyToByteArrayNode.class)
    @SuppressWarnings("javadoc")
    static final class InternalCopyToByteArrayNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static InternalCopyToByteArrayNode getUncached() {
            return InternalCopyToByteArrayNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * </ul>
         */
        @NeverDefault
        public static InternalCopyToByteArrayNode inline(@RequiredField(bits = 17, value = StateField.class) InlineTarget target) {
            return new InternalCopyToByteArrayNodeGen.Inlined(target);
        }

        @GeneratedBy(InternalCopyToByteArrayNode.class)
        @DenyReplace
        private static final class Inlined extends InternalCopyToByteArrayNode {

            /**
             * State Info: <pre>
             *   0-6: InlinedCache
             *        Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *        Parameter: {@link ToIndexableNode} toIndexableNode
             *        Inline method: {@link ToIndexableNodeGen#inline}
             *   7-8: InlinedCache
             *        Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *        Parameter: {@link InlinedConditionProfile} utf16Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   9-10: InlinedCache
             *        Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *        Parameter: {@link InlinedConditionProfile} utf16S0Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   11-12: InlinedCache
             *        Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *        Parameter: {@link InlinedConditionProfile} utf32Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   13-14: InlinedCache
             *        Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *        Parameter: {@link InlinedConditionProfile} utf32S0Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   15-16: InlinedCache
             *        Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *        Parameter: {@link InlinedConditionProfile} utf32S1Profile
             *        Inline method: {@link InlinedConditionProfile#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *   Parameter: {@link ToIndexableNode} toIndexableNode
             *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
             */
            private final ToIndexableNode toIndexableNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *   Parameter: {@link InlinedConditionProfile} utf16Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf16Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *   Parameter: {@link InlinedConditionProfile} utf16S0Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf16S0Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *   Parameter: {@link InlinedConditionProfile} utf32Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf32Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *   Parameter: {@link InlinedConditionProfile} utf32S0Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf32S0Profile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalCopyToByteArrayNode#doCopy}
             *   Parameter: {@link InlinedConditionProfile} utf32S1Profile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile utf32S1Profile_;

            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(InternalCopyToByteArrayNode.class);
                this.state_0_ = target.getState(0, 17);
                this.toIndexableNode_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, state_0_.subUpdater(0, 7)));
                this.utf16Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(7, 2)));
                this.utf16S0Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(9, 2)));
                this.utf32Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(11, 2)));
                this.utf32S0Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(13, 2)));
                this.utf32S1Profile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(15, 2)));
            }

            @Override
            void execute(Node arg0Value, AbstractTruffleString arg1Value, int arg2Value, byte[] arg3Value, int arg4Value, int arg5Value, Encoding arg6Value) {
                assert InlineSupport.validate(arg0Value, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_, this.state_0_);
                InternalCopyToByteArrayNode.doCopy(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, this.toIndexableNode_, this.utf16Profile_, this.utf16S0Profile_, this.utf32Profile_, this.utf32S0Profile_, this.utf32S1Profile_);
                return;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(InternalCopyToByteArrayNode.class)
        @DenyReplace
        private static final class Uncached extends InternalCopyToByteArrayNode {

            @TruffleBoundary
            @Override
            void execute(Node arg0Value, AbstractTruffleString arg1Value, int arg2Value, byte[] arg3Value, int arg4Value, int arg5Value, Encoding arg6Value) {
                InternalCopyToByteArrayNode.doCopy(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, (ToIndexableNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()));
                return;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CopyToNativeMemoryNode#doCopy}
     *     Activation probability: 1.00000
     *     With/without class size: 28/7 bytes
     * </pre>
     */
    @GeneratedBy(CopyToNativeMemoryNode.class)
    @SuppressWarnings("javadoc")
    static final class CopyToNativeMemoryNodeGen extends CopyToNativeMemoryNode {

        private static final StateField STATE_0_CopyToNativeMemoryNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CopyToNativeMemoryNode_UPDATER.subUpdater(1, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *   Parameter: {@link InlinedConditionProfile} utf16Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF16_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_CopyToNativeMemoryNode_UPDATER.subUpdater(8, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *   Parameter: {@link InlinedConditionProfile} utf16S0Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF16_S0_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_CopyToNativeMemoryNode_UPDATER.subUpdater(10, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *   Parameter: {@link InlinedConditionProfile} utf32Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_CopyToNativeMemoryNode_UPDATER.subUpdater(12, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *   Parameter: {@link InlinedConditionProfile} utf32S0Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_S0_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_CopyToNativeMemoryNode_UPDATER.subUpdater(14, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *   Parameter: {@link InlinedConditionProfile} utf32S1Profile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_UTF32_S1_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_CopyToNativeMemoryNode_UPDATER.subUpdater(16, 2)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link CopyToNativeMemoryNode#doCopy}
         *   1-7: InlinedCache
         *        Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   8-9: InlinedCache
         *        Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *        Parameter: {@link InlinedConditionProfile} utf16Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   10-11: InlinedCache
         *        Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *        Parameter: {@link InlinedConditionProfile} utf16S0Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   12-13: InlinedCache
         *        Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *        Parameter: {@link InlinedConditionProfile} utf32Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   14-15: InlinedCache
         *        Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *        Parameter: {@link InlinedConditionProfile} utf32S0Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   16-17: InlinedCache
         *        Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *        Parameter: {@link InlinedConditionProfile} utf32S1Profile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link CopyToNativeMemoryNode#doCopy}
         *   Parameter: {@link Node} interopLibrary</pre>
         */
        @Child private Node interopLibrary_;

        private CopyToNativeMemoryNodeGen() {
        }

        @Override
        public void execute(AbstractTruffleString arg0Value, int arg1Value, Object arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.CopyToNativeMemoryNode.doCopy(AbstractTruffleString, int, Object, int, int, Encoding, Node, ToIndexableNode, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile)] */) {
                {
                    Node interopLibrary__ = this.interopLibrary_;
                    if (interopLibrary__ != null) {
                        doCopy(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, interopLibrary__, INLINED_TO_INDEXABLE_NODE_, INLINED_UTF16_PROFILE_, INLINED_UTF16_S0_PROFILE_, INLINED_UTF32_PROFILE_, INLINED_UTF32_S0_PROFILE_, INLINED_UTF32_S1_PROFILE_);
                        return;
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
            return;
        }

        private void executeAndSpecialize(AbstractTruffleString arg0Value, int arg1Value, Object arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            int state_0 = this.state_0_;
            Node interopLibrary__ = this.insert((TStringAccessor.createInteropLibrary()));
            Objects.requireNonNull(interopLibrary__, "Specialization 'doCopy(AbstractTruffleString, int, Object, int, int, Encoding, Node, ToIndexableNode, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile)' cache 'interopLibrary' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.interopLibrary_ = interopLibrary__;
            state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.CopyToNativeMemoryNode.doCopy(AbstractTruffleString, int, Object, int, int, Encoding, Node, ToIndexableNode, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile, InlinedConditionProfile)] */;
            this.state_0_ = state_0;
            doCopy(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, interopLibrary__, INLINED_TO_INDEXABLE_NODE_, INLINED_UTF16_PROFILE_, INLINED_UTF16_S0_PROFILE_, INLINED_UTF32_PROFILE_, INLINED_UTF32_S0_PROFILE_, INLINED_UTF32_S1_PROFILE_);
            return;
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static CopyToNativeMemoryNode create() {
            return new CopyToNativeMemoryNodeGen();
        }

        @NeverDefault
        public static CopyToNativeMemoryNode getUncached() {
            return CopyToNativeMemoryNodeGen.UNCACHED;
        }

        @GeneratedBy(CopyToNativeMemoryNode.class)
        @DenyReplace
        private static final class Uncached extends CopyToNativeMemoryNode {

            @TruffleBoundary
            @Override
            public void execute(AbstractTruffleString arg0Value, int arg1Value, Object arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
                doCopy(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, (TStringAccessor.getUncachedInteropLibrary()), (ToIndexableNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()));
                return;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ToJavaStringNode#doUTF16}
     *     Activation probability: 0.65000
     *     With/without class size: 17/2 bytes
     *   Specialization {@link ToJavaStringNode#doMutable}
     *     Activation probability: 0.35000
     *     With/without class size: 9/0 bytes
     * </pre>
     */
    @GeneratedBy(ToJavaStringNode.class)
    @SuppressWarnings("javadoc")
    static final class ToJavaStringNodeGen extends ToJavaStringNode {

        private static final StateField STATE_1_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        private static final StateField STATE_4_UPDATER = StateField.create(MethodHandles.lookup(), "state_4_");
        private static final StateField STATE_5_UPDATER = StateField.create(MethodHandles.lookup(), "state_5_");
        private static final StateField STATE_6_UPDATER = StateField.create(MethodHandles.lookup(), "state_6_");
        private static final StateField STATE_7_UPDATER = StateField.create(MethodHandles.lookup(), "state_7_");
        private static final StateField STATE_8_UPDATER = StateField.create(MethodHandles.lookup(), "state_8_");
        private static final StateField STATE_9_UPDATER = StateField.create(MethodHandles.lookup(), "state_9_");
        private static final StateField STATE_10_UPDATER = StateField.create(MethodHandles.lookup(), "state_10_");
        private static final StateField STATE_0_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_0_ToJavaStringNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToJavaStringNode#doUTF16}
         *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
         */
        private static final GetCodePointLengthNode INLINED_GET_CODE_POINT_LENGTH_NODE = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, STATE_1_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToJavaStringNode#doUTF16}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_GET_PRECISE_CODE_RANGE_NODE = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_2_UPDATER.subUpdater(0, 25)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToJavaStringNode#doUTF16}
         *   Parameter: {@link TransCodeNode} transCodeNode
         *   Inline method: {@link TransCodeNodeGen#inline}</pre>
         */
        private static final TransCodeNode INLINED_TRANS_CODE_NODE = TransCodeNodeGen.inline(InlineTarget.create(TransCodeNode.class, STATE_3_UPDATER.subUpdater(0, 25), STATE_4_UPDATER.subUpdater(0, 26), STATE_5_UPDATER.subUpdater(0, 25), STATE_6_UPDATER.subUpdater(0, 25), STATE_7_UPDATER.subUpdater(0, 25), STATE_8_UPDATER.subUpdater(0, 24), STATE_9_UPDATER.subUpdater(0, 32), STATE_10_UPDATER.subUpdater(0, 25), ReferenceField.create(MethodHandles.lookup(), "transCodeNode_field8_", Node.class)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToJavaStringNode#doUTF16}
         *   Parameter: {@link CreateJavaStringNode} createJavaStringNode
         *   Inline method: {@link CreateJavaStringNodeGen#inline}</pre>
         */
        private static final CreateJavaStringNode INLINED_CREATE_JAVA_STRING_NODE = CreateJavaStringNodeGen.inline(InlineTarget.create(CreateJavaStringNode.class, STATE_0_UPDATER.subUpdater(11, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToJavaStringNode#doUTF16}
         *   Parameter: {@link InlinedConditionProfile} noTranscodeProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_NO_TRANSCODE_PROFILE = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_UPDATER.subUpdater(13, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToJavaStringNode#doUTF16}
         *   Parameter: {@link InlinedConditionProfile} cacheHit
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_U_T_F16_CACHE_HIT_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_ToJavaStringNode_UPDATER.subUpdater(2, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToJavaStringNode#doUTF16}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_U_T_F16_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ToJavaStringNode_UPDATER.subUpdater(4, 7)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link ToJavaStringNode#doUTF16}
         *   1: SpecializationActive {@link ToJavaStringNode#doMutable}
         *   2-3: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link InlinedConditionProfile} cacheHit
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   4-10: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   11-12: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link CreateJavaStringNode} createJavaStringNode
         *        Inline method: {@link CreateJavaStringNodeGen#inline}
         *   13-14: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link InlinedConditionProfile} noTranscodeProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
         *        Inline method: {@link GetCodePointLengthNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link TransCodeNode} transCodeNode
         *        Inline method: {@link TransCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * State Info: <pre>
         *   0-25: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link TransCodeNode} transCodeNode
         *        Inline method: {@link TransCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_4_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link TransCodeNode} transCodeNode
         *        Inline method: {@link TransCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_5_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link TransCodeNode} transCodeNode
         *        Inline method: {@link TransCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_6_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link TransCodeNode} transCodeNode
         *        Inline method: {@link TransCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_7_;
        /**
         * State Info: <pre>
         *   0-23: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link TransCodeNode} transCodeNode
         *        Inline method: {@link TransCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_8_;
        /**
         * State Info: <pre>
         *   0-31: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link TransCodeNode} transCodeNode
         *        Inline method: {@link TransCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_9_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link ToJavaStringNode#doUTF16}
         *        Parameter: {@link TransCodeNode} transCodeNode
         *        Inline method: {@link TransCodeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_10_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToJavaStringNode#doUTF16}
         *   Parameter: {@link TransCodeNode} transCodeNode
         *   Inline method: {@link TransCodeNodeGen#inline}
         *   Inline field: {@link Node} field8</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node transCodeNode_field8_;

        private ToJavaStringNodeGen() {
        }

        @Override
        public String execute(AbstractTruffleString arg0Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) != 0 /* is SpecializationActive[TruffleString.ToJavaStringNode.doUTF16(TruffleString, Node, InlinedConditionProfile, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, CreateJavaStringNode, InlinedConditionProfile)] || SpecializationActive[TruffleString.ToJavaStringNode.doMutable(MutableTruffleString, Node, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, CreateJavaStringNode, InlinedConditionProfile)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.ToJavaStringNode.doUTF16(TruffleString, Node, InlinedConditionProfile, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, CreateJavaStringNode, InlinedConditionProfile)] */ && arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    {
                        Node node__ = (this);
                        return ToJavaStringNode.doUTF16(arg0Value_, node__, INLINED_U_T_F16_CACHE_HIT_, INLINED_U_T_F16_TO_INDEXABLE_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE, INLINED_GET_PRECISE_CODE_RANGE_NODE, INLINED_TRANS_CODE_NODE, INLINED_CREATE_JAVA_STRING_NODE, INLINED_NO_TRANSCODE_PROFILE);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.ToJavaStringNode.doMutable(MutableTruffleString, Node, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, CreateJavaStringNode, InlinedConditionProfile)] */ && arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    {
                        Node node__1 = (this);
                        return ToJavaStringNode.doMutable(arg0Value_, node__1, INLINED_GET_CODE_POINT_LENGTH_NODE, INLINED_GET_PRECISE_CODE_RANGE_NODE, INLINED_TRANS_CODE_NODE, INLINED_CREATE_JAVA_STRING_NODE, INLINED_NO_TRANSCODE_PROFILE);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private String executeAndSpecialize(AbstractTruffleString arg0Value) {
            int state_0 = this.state_0_;
            {
                Node node__ = null;
                if (arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    node__ = (this);
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.ToJavaStringNode.doUTF16(TruffleString, Node, InlinedConditionProfile, ToIndexableNode, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, CreateJavaStringNode, InlinedConditionProfile)] */;
                    this.state_0_ = state_0;
                    return ToJavaStringNode.doUTF16(arg0Value_, node__, INLINED_U_T_F16_CACHE_HIT_, INLINED_U_T_F16_TO_INDEXABLE_NODE_, INLINED_GET_CODE_POINT_LENGTH_NODE, INLINED_GET_PRECISE_CODE_RANGE_NODE, INLINED_TRANS_CODE_NODE, INLINED_CREATE_JAVA_STRING_NODE, INLINED_NO_TRANSCODE_PROFILE);
                }
            }
            {
                Node node__1 = null;
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    node__1 = (this);
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.ToJavaStringNode.doMutable(MutableTruffleString, Node, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, CreateJavaStringNode, InlinedConditionProfile)] */;
                    this.state_0_ = state_0;
                    return ToJavaStringNode.doMutable(arg0Value_, node__1, INLINED_GET_CODE_POINT_LENGTH_NODE, INLINED_GET_PRECISE_CODE_RANGE_NODE, INLINED_TRANS_CODE_NODE, INLINED_CREATE_JAVA_STRING_NODE, INLINED_NO_TRANSCODE_PROFILE);
                }
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b11) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount((state_0 & 0b11));
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static ToJavaStringNode create() {
            return new ToJavaStringNodeGen();
        }

        @NeverDefault
        public static ToJavaStringNode getUncached() {
            return ToJavaStringNodeGen.UNCACHED;
        }

        @GeneratedBy(ToJavaStringNode.class)
        @DenyReplace
        private static final class Uncached extends ToJavaStringNode {

            @TruffleBoundary
            @Override
            public String execute(AbstractTruffleString arg0Value) {
                if (arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    return ToJavaStringNode.doUTF16(arg0Value_, (this), (InlinedConditionProfile.getUncached()), (ToIndexableNodeGen.getUncached()), (GetCodePointLengthNode.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (TransCodeNodeGen.getUncached()), (CreateJavaStringNodeGen.getUncached()), (InlinedConditionProfile.getUncached()));
                }
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    return ToJavaStringNode.doMutable(arg0Value_, (this), (GetCodePointLengthNode.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (TransCodeNodeGen.getUncached()), (CreateJavaStringNodeGen.getUncached()), (InlinedConditionProfile.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link AsNativeNode#asNative}
     *     Activation probability: 1.00000
     *     With/without class size: 36/13 bytes
     * </pre>
     */
    @GeneratedBy(AsNativeNode.class)
    @SuppressWarnings("javadoc")
    static final class AsNativeNodeGen extends AsNativeNode {

        private static final StateField STATE_0_AsNativeNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_AsNativeNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsNativeNode#asNative}
         *   Parameter: {@link InlinedConditionProfile} isNativeProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_IS_NATIVE_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_AsNativeNode_UPDATER.subUpdater(1, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsNativeNode#asNative}
         *   Parameter: {@link InlinedConditionProfile} cacheHit
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_CACHE_HIT_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_AsNativeNode_UPDATER.subUpdater(3, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsNativeNode#asNative}
         *   Parameter: {@link InlinedIntValueProfile} inflateStrideProfile
         *   Inline method: {@link InlinedIntValueProfile#inline}</pre>
         */
        private static final InlinedIntValueProfile INLINED_INFLATE_STRIDE_PROFILE_ = InlinedIntValueProfile.inline(InlineTarget.create(InlinedIntValueProfile.class, STATE_0_AsNativeNode_UPDATER.subUpdater(5, 2), IntField.create(MethodHandles.lookup(), "inflateStrideProfile__field1_")));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsNativeNode#asNative}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_AsNativeNode_UPDATER.subUpdater(7, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsNativeNode#asNative}
         *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
         */
        private static final GetPreciseCodeRangeNode INLINED_GET_PRECISE_CODE_RANGE_NODE_ = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, STATE_1_AsNativeNode_UPDATER.subUpdater(0, 25)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link AsNativeNode#asNative}
         *   1-2: InlinedCache
         *        Specialization: {@link AsNativeNode#asNative}
         *        Parameter: {@link InlinedConditionProfile} isNativeProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   3-4: InlinedCache
         *        Specialization: {@link AsNativeNode#asNative}
         *        Parameter: {@link InlinedConditionProfile} cacheHit
         *        Inline method: {@link InlinedConditionProfile#inline}
         *   5-6: InlinedCache
         *        Specialization: {@link AsNativeNode#asNative}
         *        Parameter: {@link InlinedIntValueProfile} inflateStrideProfile
         *        Inline method: {@link InlinedIntValueProfile#inline}
         *   7-13: InlinedCache
         *        Specialization: {@link AsNativeNode#asNative}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link AsNativeNode#asNative}
         *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
         *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsNativeNode#asNative}
         *   Parameter: {@link Node} interopLibrary</pre>
         */
        @Child private Node interopLibrary_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link AsNativeNode#asNative}
         *   Parameter: {@link InlinedIntValueProfile} inflateStrideProfile
         *   Inline method: {@link InlinedIntValueProfile#inline}
         *   Inline field: int field1</pre>
         */
        @CompilationFinal @UnsafeAccessedField @SuppressWarnings("unused") private int inflateStrideProfile__field1_;

        private AsNativeNodeGen() {
        }

        @Override
        public TruffleString execute(TruffleString arg0Value, NativeAllocator arg1Value, Encoding arg2Value, boolean arg3Value, boolean arg4Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.AsNativeNode.asNative(TruffleString, NativeAllocator, Encoding, boolean, boolean, Node, Node, InlinedConditionProfile, InlinedConditionProfile, InlinedIntValueProfile, ToIndexableNode, GetPreciseCodeRangeNode)] */) {
                {
                    Node interopLibrary__ = this.interopLibrary_;
                    if (interopLibrary__ != null) {
                        Node node__ = (this);
                        return AsNativeNode.asNative(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, node__, interopLibrary__, INLINED_IS_NATIVE_PROFILE_, INLINED_CACHE_HIT_, INLINED_INFLATE_STRIDE_PROFILE_, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_PRECISE_CODE_RANGE_NODE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
        }

        private TruffleString executeAndSpecialize(TruffleString arg0Value, NativeAllocator arg1Value, Encoding arg2Value, boolean arg3Value, boolean arg4Value) {
            int state_0 = this.state_0_;
            {
                Node node__ = null;
                node__ = (this);
                Node interopLibrary__ = this.insert((TStringAccessor.createInteropLibrary()));
                Objects.requireNonNull(interopLibrary__, "Specialization 'asNative(TruffleString, NativeAllocator, Encoding, boolean, boolean, Node, Node, InlinedConditionProfile, InlinedConditionProfile, InlinedIntValueProfile, ToIndexableNode, GetPreciseCodeRangeNode)' cache 'interopLibrary' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.interopLibrary_ = interopLibrary__;
                state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.AsNativeNode.asNative(TruffleString, NativeAllocator, Encoding, boolean, boolean, Node, Node, InlinedConditionProfile, InlinedConditionProfile, InlinedIntValueProfile, ToIndexableNode, GetPreciseCodeRangeNode)] */;
                this.state_0_ = state_0;
                return AsNativeNode.asNative(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, node__, interopLibrary__, INLINED_IS_NATIVE_PROFILE_, INLINED_CACHE_HIT_, INLINED_INFLATE_STRIDE_PROFILE_, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_PRECISE_CODE_RANGE_NODE_);
            }
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static AsNativeNode create() {
            return new AsNativeNodeGen();
        }

        @NeverDefault
        public static AsNativeNode getUncached() {
            return AsNativeNodeGen.UNCACHED;
        }

        @GeneratedBy(AsNativeNode.class)
        @DenyReplace
        private static final class Uncached extends AsNativeNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(TruffleString arg0Value, NativeAllocator arg1Value, Encoding arg2Value, boolean arg3Value, boolean arg4Value) {
                return AsNativeNode.asNative(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, (this), (TStringAccessor.getUncachedInteropLibrary()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedIntValueProfile.getUncached()), (ToIndexableNodeGen.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link SwitchEncodingNode#switchEncoding}
     *     Activation probability: 1.00000
     *     With/without class size: 68/46 bytes
     * </pre>
     */
    @GeneratedBy(SwitchEncodingNode.class)
    @SuppressWarnings("javadoc")
    static final class SwitchEncodingNodeGen extends SwitchEncodingNode {

        private static final StateField STATE_0_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_1_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_3_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        private static final StateField STATE_4_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_4_");
        private static final StateField STATE_5_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_5_");
        private static final StateField STATE_6_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_6_");
        private static final StateField STATE_7_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_7_");
        private static final StateField STATE_8_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_8_");
        private static final StateField STATE_9_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_9_");
        private static final StateField STATE_10_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_10_");
        private static final StateField STATE_11_SwitchEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_11_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link SwitchEncodingNode#switchEncoding}
         *   Parameter: {@link InternalSwitchEncodingNode} internalNode
         *   Inline method: {@link InternalSwitchEncodingNodeGen#inline}</pre>
         */
        private static final InternalSwitchEncodingNode INLINED_INTERNAL_NODE_ = InternalSwitchEncodingNodeGen.inline(InlineTarget.create(InternalSwitchEncodingNode.class, STATE_0_SwitchEncodingNode_UPDATER.subUpdater(0, 31), STATE_1_SwitchEncodingNode_UPDATER.subUpdater(0, 31), STATE_2_SwitchEncodingNode_UPDATER.subUpdater(0, 31), STATE_3_SwitchEncodingNode_UPDATER.subUpdater(0, 29), STATE_4_SwitchEncodingNode_UPDATER.subUpdater(0, 32), STATE_5_SwitchEncodingNode_UPDATER.subUpdater(0, 26), STATE_6_SwitchEncodingNode_UPDATER.subUpdater(0, 25), STATE_7_SwitchEncodingNode_UPDATER.subUpdater(0, 25), STATE_8_SwitchEncodingNode_UPDATER.subUpdater(0, 25), STATE_9_SwitchEncodingNode_UPDATER.subUpdater(0, 24), STATE_10_SwitchEncodingNode_UPDATER.subUpdater(0, 32), STATE_11_SwitchEncodingNode_UPDATER.subUpdater(0, 25), ReferenceField.create(MethodHandles.lookup(), "internalNode__field12_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-28: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;
        /**
         * State Info: <pre>
         *   0-31: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_4_;
        /**
         * State Info: <pre>
         *   0-25: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_5_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_6_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_7_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_8_;
        /**
         * State Info: <pre>
         *   0-23: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_9_;
        /**
         * State Info: <pre>
         *   0-31: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_10_;
        /**
         * State Info: <pre>
         *   0-24: InlinedCache
         *        Specialization: {@link SwitchEncodingNode#switchEncoding}
         *        Parameter: {@link InternalSwitchEncodingNode} internalNode
         *        Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_11_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link SwitchEncodingNode#switchEncoding}
         *   Parameter: {@link InternalSwitchEncodingNode} internalNode
         *   Inline method: {@link InternalSwitchEncodingNodeGen#inline}
         *   Inline field: {@link Node} field12</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node internalNode__field12_;

        private SwitchEncodingNodeGen() {
        }

        @Override
        public TruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, TranscodingErrorHandler arg2Value) {
            return switchEncoding(arg0Value, arg1Value, arg2Value, INLINED_INTERNAL_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static SwitchEncodingNode create() {
            return new SwitchEncodingNodeGen();
        }

        @NeverDefault
        public static SwitchEncodingNode getUncached() {
            return SwitchEncodingNodeGen.UNCACHED;
        }

        @GeneratedBy(SwitchEncodingNode.class)
        @DenyReplace
        private static final class Uncached extends SwitchEncodingNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, TranscodingErrorHandler arg2Value) {
                return switchEncoding(arg0Value, arg1Value, arg2Value, (InternalSwitchEncodingNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link InternalSwitchEncodingNode#compatibleImmutable}
     *     Activation probability: 0.38500
     *     With/without class size: 8/0 bytes
     *   Specialization {@link InternalSwitchEncodingNode#compatibleMutable}
     *     Activation probability: 0.29500
     *     With/without class size: 11/8 bytes
     *   Specialization {@link InternalSwitchEncodingNode#transCode}
     *     Activation probability: 0.20500
     *     With/without class size: 8/2 bytes
     *   Specialization {@link InternalSwitchEncodingNode#transCodeMutable}
     *     Activation probability: 0.11500
     *     With/without class size: 6/4 bytes
     * </pre>
     */
    @GeneratedBy(InternalSwitchEncodingNode.class)
    @SuppressWarnings("javadoc")
    static final class InternalSwitchEncodingNodeGen {

        private static final Uncached UNCACHED = new Uncached();

        @NeverDefault
        public static InternalSwitchEncodingNode getUncached() {
            return InternalSwitchEncodingNodeGen.UNCACHED;
        }

        /**
         * Required Fields: <ul>
         * <li>{@link Inlined#state_0_}
         * <li>{@link Inlined#state_1_}
         * <li>{@link Inlined#state_2_}
         * <li>{@link Inlined#state_3_}
         * <li>{@link Inlined#state_4_}
         * <li>{@link Inlined#state_5_}
         * <li>{@link Inlined#state_6_}
         * <li>{@link Inlined#state_7_}
         * <li>{@link Inlined#state_8_}
         * <li>{@link Inlined#state_9_}
         * <li>{@link Inlined#state_10_}
         * <li>{@link Inlined#state_11_}
         * <li>{@link Inlined#transCodeNode_field8_}
         * </ul>
         */
        @NeverDefault
        public static InternalSwitchEncodingNode inline(@RequiredField(bits = 31, value = StateField.class)@RequiredField(bits = 31, value = StateField.class)@RequiredField(bits = 31, value = StateField.class)@RequiredField(bits = 29, value = StateField.class)@RequiredField(bits = 32, value = StateField.class)@RequiredField(bits = 26, value = StateField.class)@RequiredField(bits = 25, value = StateField.class)@RequiredField(bits = 25, value = StateField.class)@RequiredField(bits = 25, value = StateField.class)@RequiredField(bits = 24, value = StateField.class)@RequiredField(bits = 32, value = StateField.class)@RequiredField(bits = 25, value = StateField.class)@RequiredField(type = Node.class, value = ReferenceField.class) InlineTarget target) {
            return new InternalSwitchEncodingNodeGen.Inlined(target);
        }

        @GeneratedBy(InternalSwitchEncodingNode.class)
        @DenyReplace
        private static final class Inlined extends InternalSwitchEncodingNode {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link InternalSwitchEncodingNode#compatibleImmutable}
             *   1: SpecializationActive {@link InternalSwitchEncodingNode#compatibleMutable}
             *   2: SpecializationActive {@link InternalSwitchEncodingNode#transCode}
             *   3: SpecializationActive {@link InternalSwitchEncodingNode#transCodeMutable}
             *   4-28: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCodeMutable}
             *        Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
             *        Inline method: {@link GetCodePointLengthNodeGen#inline}
             *   29-30: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link InlinedConditionProfile} preciseCodeRangeIsCompatibleProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             * </pre>
             */
            private final StateField state_0_;
            /**
             * State Info: <pre>
             *   0-30: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#compatibleMutable}
             *        Parameter: {@link InternalAsTruffleStringNode} asTruffleStringNode
             *        Inline method: {@link InternalAsTruffleStringNodeGen#inline}
             * </pre>
             */
            private final StateField state_1_;
            /**
             * State Info: <pre>
             *   0-30: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#compatibleMutable}
             *        Parameter: {@link InternalAsTruffleStringNode} asTruffleStringNode
             *        Inline method: {@link InternalAsTruffleStringNodeGen#inline}
             * </pre>
             */
            private final StateField state_2_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *        Inline method: {@link GetPreciseCodeRangeNodeGen#inline}
             *   25-26: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link InlinedConditionProfile} cacheHit
             *        Inline method: {@link InlinedConditionProfile#inline}
             *   27-28: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCodeMutable}
             *        Parameter: {@link InlinedConditionProfile} isCompatibleProfile
             *        Inline method: {@link InlinedConditionProfile#inline}
             * </pre>
             */
            private final StateField state_3_;
            /**
             * State Info: <pre>
             *   0-6: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link ToIndexableNode} toIndexableNode
             *        Inline method: {@link ToIndexableNodeGen#inline}
             *   7-31: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link TransCodeNode} transCodeNode
             *        Inline method: {@link TransCodeNodeGen#inline}
             * </pre>
             */
            private final StateField state_4_;
            /**
             * State Info: <pre>
             *   0-25: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link TransCodeNode} transCodeNode
             *        Inline method: {@link TransCodeNodeGen#inline}
             * </pre>
             */
            private final StateField state_5_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link TransCodeNode} transCodeNode
             *        Inline method: {@link TransCodeNodeGen#inline}
             * </pre>
             */
            private final StateField state_6_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link TransCodeNode} transCodeNode
             *        Inline method: {@link TransCodeNodeGen#inline}
             * </pre>
             */
            private final StateField state_7_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link TransCodeNode} transCodeNode
             *        Inline method: {@link TransCodeNodeGen#inline}
             * </pre>
             */
            private final StateField state_8_;
            /**
             * State Info: <pre>
             *   0-23: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link TransCodeNode} transCodeNode
             *        Inline method: {@link TransCodeNodeGen#inline}
             * </pre>
             */
            private final StateField state_9_;
            /**
             * State Info: <pre>
             *   0-31: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link TransCodeNode} transCodeNode
             *        Inline method: {@link TransCodeNodeGen#inline}
             * </pre>
             */
            private final StateField state_10_;
            /**
             * State Info: <pre>
             *   0-24: InlinedCache
             *        Specialization: {@link InternalSwitchEncodingNode#transCode}
             *        Parameter: {@link TransCodeNode} transCodeNode
             *        Inline method: {@link TransCodeNodeGen#inline}
             * </pre>
             */
            private final StateField state_11_;
            private final ReferenceField<Node> transCodeNode_field8_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalSwitchEncodingNode#transCode}
             *   Parameter: {@link GetPreciseCodeRangeNode} getPreciseCodeRangeNode
             *   Inline method: {@link GetPreciseCodeRangeNodeGen#inline}</pre>
             */
            private final GetPreciseCodeRangeNode getPreciseCodeRangeNode;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalSwitchEncodingNode#transCode}
             *   Parameter: {@link TransCodeNode} transCodeNode
             *   Inline method: {@link TransCodeNodeGen#inline}</pre>
             */
            private final TransCodeNode transCodeNode;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalSwitchEncodingNode#compatibleMutable}
             *   Parameter: {@link InternalAsTruffleStringNode} asTruffleStringNode
             *   Inline method: {@link InternalAsTruffleStringNodeGen#inline}</pre>
             */
            private final InternalAsTruffleStringNode compatibleMutable_asTruffleStringNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalSwitchEncodingNode#transCode}
             *   Parameter: {@link InlinedConditionProfile} preciseCodeRangeIsCompatibleProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile transCode_preciseCodeRangeIsCompatibleProfile_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalSwitchEncodingNode#transCode}
             *   Parameter: {@link InlinedConditionProfile} cacheHit
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile transCode_cacheHit_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalSwitchEncodingNode#transCode}
             *   Parameter: {@link ToIndexableNode} toIndexableNode
             *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
             */
            private final ToIndexableNode transCode_toIndexableNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalSwitchEncodingNode#transCodeMutable}
             *   Parameter: {@link GetCodePointLengthNode} getCodePointLengthNode
             *   Inline method: {@link GetCodePointLengthNodeGen#inline}</pre>
             */
            private final GetCodePointLengthNode transCodeMutable_getCodePointLengthNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InternalSwitchEncodingNode#transCodeMutable}
             *   Parameter: {@link InlinedConditionProfile} isCompatibleProfile
             *   Inline method: {@link InlinedConditionProfile#inline}</pre>
             */
            private final InlinedConditionProfile transCodeMutable_isCompatibleProfile_;

            @SuppressWarnings("unchecked")
            private Inlined(InlineTarget target) {
                assert target.getTargetClass().isAssignableFrom(InternalSwitchEncodingNode.class);
                this.state_0_ = target.getState(0, 31);
                this.state_1_ = target.getState(1, 31);
                this.state_2_ = target.getState(2, 31);
                this.state_3_ = target.getState(3, 29);
                this.state_4_ = target.getState(4, 32);
                this.state_5_ = target.getState(5, 26);
                this.state_6_ = target.getState(6, 25);
                this.state_7_ = target.getState(7, 25);
                this.state_8_ = target.getState(8, 25);
                this.state_9_ = target.getState(9, 24);
                this.state_10_ = target.getState(10, 32);
                this.state_11_ = target.getState(11, 25);
                this.transCodeNode_field8_ = target.getReference(12, Node.class);
                this.getPreciseCodeRangeNode = GetPreciseCodeRangeNodeGen.inline(InlineTarget.create(GetPreciseCodeRangeNode.class, state_3_.subUpdater(0, 25)));
                this.transCodeNode = TransCodeNodeGen.inline(InlineTarget.create(TransCodeNode.class, state_4_.subUpdater(7, 25), state_5_.subUpdater(0, 26), state_6_.subUpdater(0, 25), state_7_.subUpdater(0, 25), state_8_.subUpdater(0, 25), state_9_.subUpdater(0, 24), state_10_.subUpdater(0, 32), state_11_.subUpdater(0, 25), transCodeNode_field8_));
                this.compatibleMutable_asTruffleStringNode_ = InternalAsTruffleStringNodeGen.inline(InlineTarget.create(InternalAsTruffleStringNode.class, state_1_.subUpdater(0, 31), state_2_.subUpdater(0, 31)));
                this.transCode_preciseCodeRangeIsCompatibleProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_0_.subUpdater(29, 2)));
                this.transCode_cacheHit_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_3_.subUpdater(25, 2)));
                this.transCode_toIndexableNode_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, state_4_.subUpdater(0, 7)));
                this.transCodeMutable_getCodePointLengthNode_ = GetCodePointLengthNodeGen.inline(InlineTarget.create(GetCodePointLengthNode.class, state_0_.subUpdater(4, 25)));
                this.transCodeMutable_isCompatibleProfile_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, state_3_.subUpdater(27, 2)));
            }

            @Override
            public TruffleString execute(Node arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value, TranscodingErrorHandler arg3Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if ((state_0 & 0b1111) != 0 /* is SpecializationActive[TruffleString.InternalSwitchEncodingNode.compatibleImmutable(TruffleString, Encoding, TranscodingErrorHandler)] || SpecializationActive[TruffleString.InternalSwitchEncodingNode.compatibleMutable(Node, MutableTruffleString, Encoding, TranscodingErrorHandler, InternalAsTruffleStringNode)] || SpecializationActive[TruffleString.InternalSwitchEncodingNode.transCode(Node, TruffleString, Encoding, TranscodingErrorHandler, GetPreciseCodeRangeNode, InlinedConditionProfile, InlinedConditionProfile, ToIndexableNode, TransCodeNode)] || SpecializationActive[TruffleString.InternalSwitchEncodingNode.transCodeMutable(Node, MutableTruffleString, Encoding, TranscodingErrorHandler, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, InlinedConditionProfile)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.InternalSwitchEncodingNode.compatibleImmutable(TruffleString, Encoding, TranscodingErrorHandler)] */ && arg1Value instanceof TruffleString) {
                        TruffleString arg1Value_ = (TruffleString) arg1Value;
                        if ((arg1Value_.isCompatibleToIntl(arg2Value))) {
                            return InternalSwitchEncodingNode.compatibleImmutable(arg1Value_, arg2Value, arg3Value);
                        }
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.InternalSwitchEncodingNode.compatibleMutable(Node, MutableTruffleString, Encoding, TranscodingErrorHandler, InternalAsTruffleStringNode)] */ && arg1Value instanceof MutableTruffleString) {
                        MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                        if ((arg1Value_.isCompatibleToIntl(arg2Value))) {
                            assert InlineSupport.validate(arg0Value, this.state_1_, this.state_2_);
                            return InternalSwitchEncodingNode.compatibleMutable(arg0Value, arg1Value_, arg2Value, arg3Value, this.compatibleMutable_asTruffleStringNode_);
                        }
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleString.InternalSwitchEncodingNode.transCode(Node, TruffleString, Encoding, TranscodingErrorHandler, GetPreciseCodeRangeNode, InlinedConditionProfile, InlinedConditionProfile, ToIndexableNode, TransCodeNode)] */ && arg1Value instanceof TruffleString) {
                        TruffleString arg1Value_ = (TruffleString) arg1Value;
                        if ((!(arg1Value_.isCompatibleToIntl(arg2Value)))) {
                            assert InlineSupport.validate(arg0Value, this.state_0_, this.state_3_, this.state_4_);
                            return InternalSwitchEncodingNode.transCode(arg0Value, arg1Value_, arg2Value, arg3Value, this.getPreciseCodeRangeNode, this.transCode_preciseCodeRangeIsCompatibleProfile_, this.transCode_cacheHit_, this.transCode_toIndexableNode_, this.transCodeNode);
                        }
                    }
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[TruffleString.InternalSwitchEncodingNode.transCodeMutable(Node, MutableTruffleString, Encoding, TranscodingErrorHandler, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, InlinedConditionProfile)] */ && arg1Value instanceof MutableTruffleString) {
                        MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                        if ((!(arg1Value_.isCompatibleToIntl(arg2Value)))) {
                            assert InlineSupport.validate(arg0Value, this.state_0_, this.state_3_);
                            return InternalSwitchEncodingNode.transCodeMutable(arg0Value, arg1Value_, arg2Value, arg3Value, this.transCodeMutable_getCodePointLengthNode_, this.getPreciseCodeRangeNode, this.transCodeNode, this.transCodeMutable_isCompatibleProfile_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
            }

            private TruffleString executeAndSpecialize(Node arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value, TranscodingErrorHandler arg3Value) {
                int state_0 = this.state_0_.get(arg0Value);
                if (arg1Value instanceof TruffleString) {
                    TruffleString arg1Value_ = (TruffleString) arg1Value;
                    if ((arg1Value_.isCompatibleToIntl(arg2Value))) {
                        state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.InternalSwitchEncodingNode.compatibleImmutable(TruffleString, Encoding, TranscodingErrorHandler)] */;
                        this.state_0_.set(arg0Value, state_0);
                        return InternalSwitchEncodingNode.compatibleImmutable(arg1Value_, arg2Value, arg3Value);
                    }
                }
                if (arg1Value instanceof MutableTruffleString) {
                    MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                    if ((arg1Value_.isCompatibleToIntl(arg2Value))) {
                        state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.InternalSwitchEncodingNode.compatibleMutable(Node, MutableTruffleString, Encoding, TranscodingErrorHandler, InternalAsTruffleStringNode)] */;
                        this.state_0_.set(arg0Value, state_0);
                        assert InlineSupport.validate(arg0Value, this.state_1_, this.state_2_);
                        return InternalSwitchEncodingNode.compatibleMutable(arg0Value, arg1Value_, arg2Value, arg3Value, this.compatibleMutable_asTruffleStringNode_);
                    }
                }
                if (arg1Value instanceof TruffleString) {
                    TruffleString arg1Value_ = (TruffleString) arg1Value;
                    if ((!(arg1Value_.isCompatibleToIntl(arg2Value)))) {
                        state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleString.InternalSwitchEncodingNode.transCode(Node, TruffleString, Encoding, TranscodingErrorHandler, GetPreciseCodeRangeNode, InlinedConditionProfile, InlinedConditionProfile, ToIndexableNode, TransCodeNode)] */;
                        this.state_0_.set(arg0Value, state_0);
                        assert InlineSupport.validate(arg0Value, this.state_0_, this.state_3_, this.state_4_);
                        return InternalSwitchEncodingNode.transCode(arg0Value, arg1Value_, arg2Value, arg3Value, this.getPreciseCodeRangeNode, this.transCode_preciseCodeRangeIsCompatibleProfile_, this.transCode_cacheHit_, this.transCode_toIndexableNode_, this.transCodeNode);
                    }
                }
                if (arg1Value instanceof MutableTruffleString) {
                    MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                    if ((!(arg1Value_.isCompatibleToIntl(arg2Value)))) {
                        state_0 = state_0 | 0b1000 /* add SpecializationActive[TruffleString.InternalSwitchEncodingNode.transCodeMutable(Node, MutableTruffleString, Encoding, TranscodingErrorHandler, GetCodePointLengthNode, GetPreciseCodeRangeNode, TransCodeNode, InlinedConditionProfile)] */;
                        this.state_0_.set(arg0Value, state_0);
                        assert InlineSupport.validate(arg0Value, this.state_0_, this.state_3_);
                        return InternalSwitchEncodingNode.transCodeMutable(arg0Value, arg1Value_, arg2Value, arg3Value, this.transCodeMutable_getCodePointLengthNode_, this.getPreciseCodeRangeNode, this.transCodeNode, this.transCodeMutable_isCompatibleProfile_);
                    }
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
        @GeneratedBy(InternalSwitchEncodingNode.class)
        @DenyReplace
        private static final class Uncached extends InternalSwitchEncodingNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(Node arg0Value, AbstractTruffleString arg1Value, Encoding arg2Value, TranscodingErrorHandler arg3Value) {
                if (arg1Value instanceof TruffleString) {
                    TruffleString arg1Value_ = (TruffleString) arg1Value;
                    if ((arg1Value_.isCompatibleToIntl(arg2Value))) {
                        return InternalSwitchEncodingNode.compatibleImmutable(arg1Value_, arg2Value, arg3Value);
                    }
                }
                if (arg1Value instanceof MutableTruffleString) {
                    MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                    if ((arg1Value_.isCompatibleToIntl(arg2Value))) {
                        return InternalSwitchEncodingNode.compatibleMutable(arg0Value, arg1Value_, arg2Value, arg3Value, (InternalAsTruffleStringNodeGen.getUncached()));
                    }
                }
                if (arg1Value instanceof TruffleString) {
                    TruffleString arg1Value_ = (TruffleString) arg1Value;
                    if ((!(arg1Value_.isCompatibleToIntl(arg2Value)))) {
                        return InternalSwitchEncodingNode.transCode(arg0Value, arg1Value_, arg2Value, arg3Value, (GetPreciseCodeRangeNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InlinedConditionProfile.getUncached()), (ToIndexableNodeGen.getUncached()), (TransCodeNodeGen.getUncached()));
                    }
                }
                if (arg1Value instanceof MutableTruffleString) {
                    MutableTruffleString arg1Value_ = (MutableTruffleString) arg1Value;
                    if ((!(arg1Value_.isCompatibleToIntl(arg2Value)))) {
                        return InternalSwitchEncodingNode.transCodeMutable(arg0Value, arg1Value_, arg2Value, arg3Value, (GetCodePointLengthNode.getUncached()), (GetPreciseCodeRangeNodeGen.getUncached()), (TransCodeNodeGen.getUncached()), (InlinedConditionProfile.getUncached()));
                    }
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ForceEncodingNode#compatibleImmutable}
     *     Activation probability: 0.48333
     *     With/without class size: 9/0 bytes
     *   Specialization {@link ForceEncodingNode#compatibleMutable}
     *     Activation probability: 0.33333
     *     With/without class size: 12/8 bytes
     *   Specialization {@link ForceEncodingNode#reinterpret}
     *     Activation probability: 0.18333
     *     With/without class size: 8/6 bytes
     * </pre>
     */
    @GeneratedBy(ForceEncodingNode.class)
    @SuppressWarnings("javadoc")
    static final class ForceEncodingNodeGen extends ForceEncodingNode {

        private static final StateField STATE_1_ForceEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_1_");
        private static final StateField STATE_2_ForceEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_2_");
        private static final StateField STATE_0_ForceEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        private static final StateField STATE_3_ForceEncodingNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_3_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link ForceEncodingNode#compatibleMutable}
         *   Parameter: {@link InternalAsTruffleStringNode} asTruffleStringNode
         *   Inline method: {@link InternalAsTruffleStringNodeGen#inline}</pre>
         */
        private static final InternalAsTruffleStringNode INLINED_COMPATIBLE_MUTABLE_AS_TRUFFLE_STRING_NODE_ = InternalAsTruffleStringNodeGen.inline(InlineTarget.create(InternalAsTruffleStringNode.class, STATE_1_ForceEncodingNode_UPDATER.subUpdater(0, 31), STATE_2_ForceEncodingNode_UPDATER.subUpdater(0, 31)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ForceEncodingNode#reinterpret}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_REINTERPRET_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_ForceEncodingNode_UPDATER.subUpdater(23, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ForceEncodingNode#reinterpret}
         *   Parameter: {@link InlinedConditionProfile} inflateProfile
         *   Inline method: {@link InlinedConditionProfile#inline}</pre>
         */
        private static final InlinedConditionProfile INLINED_REINTERPRET_INFLATE_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_ForceEncodingNode_UPDATER.subUpdater(30, 2)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ForceEncodingNode#reinterpret}
         *   Parameter: {@link InternalCopyToByteArrayNode} copyToByteArrayNode
         *   Inline method: {@link InternalCopyToByteArrayNodeGen#inline}</pre>
         */
        private static final InternalCopyToByteArrayNode INLINED_REINTERPRET_COPY_TO_BYTE_ARRAY_NODE_ = InternalCopyToByteArrayNodeGen.inline(InlineTarget.create(InternalCopyToByteArrayNode.class, STATE_3_ForceEncodingNode_UPDATER.subUpdater(0, 17)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link ForceEncodingNode#reinterpret}
         *   Parameter: {@link FromBufferWithStringCompactionNode} fromBufferWithStringCompactionNode
         *   Inline method: {@link FromBufferWithStringCompactionNodeGen#inline}</pre>
         */
        private static final FromBufferWithStringCompactionNode INLINED_REINTERPRET_FROM_BUFFER_WITH_STRING_COMPACTION_NODE_ = FromBufferWithStringCompactionNodeGen.inline(InlineTarget.create(FromBufferWithStringCompactionNode.class, STATE_0_ForceEncodingNode_UPDATER.subUpdater(3, 20)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link ForceEncodingNode#compatibleImmutable}
         *   1: SpecializationActive {@link ForceEncodingNode#compatibleMutable}
         *   2: SpecializationActive {@link ForceEncodingNode#reinterpret}
         *   3-22: InlinedCache
         *        Specialization: {@link ForceEncodingNode#reinterpret}
         *        Parameter: {@link FromBufferWithStringCompactionNode} fromBufferWithStringCompactionNode
         *        Inline method: {@link FromBufferWithStringCompactionNodeGen#inline}
         *   23-29: InlinedCache
         *        Specialization: {@link ForceEncodingNode#reinterpret}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   30-31: InlinedCache
         *        Specialization: {@link ForceEncodingNode#reinterpret}
         *        Parameter: {@link InlinedConditionProfile} inflateProfile
         *        Inline method: {@link InlinedConditionProfile#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link ForceEncodingNode#compatibleMutable}
         *        Parameter: {@link InternalAsTruffleStringNode} asTruffleStringNode
         *        Inline method: {@link InternalAsTruffleStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_1_;
        /**
         * State Info: <pre>
         *   0-30: InlinedCache
         *        Specialization: {@link ForceEncodingNode#compatibleMutable}
         *        Parameter: {@link InternalAsTruffleStringNode} asTruffleStringNode
         *        Inline method: {@link InternalAsTruffleStringNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_2_;
        /**
         * State Info: <pre>
         *   0-16: InlinedCache
         *        Specialization: {@link ForceEncodingNode#reinterpret}
         *        Parameter: {@link InternalCopyToByteArrayNode} copyToByteArrayNode
         *        Inline method: {@link InternalCopyToByteArrayNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_3_;

        private ForceEncodingNodeGen() {
        }

        @Override
        public TruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, Encoding arg2Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b111) != 0 /* is SpecializationActive[TruffleString.ForceEncodingNode.compatibleImmutable(TruffleString, Encoding, Encoding)] || SpecializationActive[TruffleString.ForceEncodingNode.compatibleMutable(MutableTruffleString, Encoding, Encoding, InternalAsTruffleStringNode)] || SpecializationActive[TruffleString.ForceEncodingNode.reinterpret(AbstractTruffleString, Encoding, Encoding, ToIndexableNode, InlinedConditionProfile, InternalCopyToByteArrayNode, FromBufferWithStringCompactionNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[TruffleString.ForceEncodingNode.compatibleImmutable(TruffleString, Encoding, Encoding)] */ && arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    if ((ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value_, arg1Value, arg2Value))) {
                        return ForceEncodingNode.compatibleImmutable(arg0Value_, arg1Value, arg2Value);
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[TruffleString.ForceEncodingNode.compatibleMutable(MutableTruffleString, Encoding, Encoding, InternalAsTruffleStringNode)] */ && arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value_, arg1Value, arg2Value))) {
                        return compatibleMutable(arg0Value_, arg1Value, arg2Value, INLINED_COMPATIBLE_MUTABLE_AS_TRUFFLE_STRING_NODE_);
                    }
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[TruffleString.ForceEncodingNode.reinterpret(AbstractTruffleString, Encoding, Encoding, ToIndexableNode, InlinedConditionProfile, InternalCopyToByteArrayNode, FromBufferWithStringCompactionNode)] */) {
                    if ((!(ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value, arg1Value, arg2Value)))) {
                        return reinterpret(arg0Value, arg1Value, arg2Value, INLINED_REINTERPRET_TO_INDEXABLE_NODE_, INLINED_REINTERPRET_INFLATE_PROFILE_, INLINED_REINTERPRET_COPY_TO_BYTE_ARRAY_NODE_, INLINED_REINTERPRET_FROM_BUFFER_WITH_STRING_COMPACTION_NODE_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private TruffleString executeAndSpecialize(AbstractTruffleString arg0Value, Encoding arg1Value, Encoding arg2Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof TruffleString) {
                TruffleString arg0Value_ = (TruffleString) arg0Value;
                if ((ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value_, arg1Value, arg2Value))) {
                    state_0 = state_0 | 0b1 /* add SpecializationActive[TruffleString.ForceEncodingNode.compatibleImmutable(TruffleString, Encoding, Encoding)] */;
                    this.state_0_ = state_0;
                    return ForceEncodingNode.compatibleImmutable(arg0Value_, arg1Value, arg2Value);
                }
            }
            if (arg0Value instanceof MutableTruffleString) {
                MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                if ((ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value_, arg1Value, arg2Value))) {
                    state_0 = state_0 | 0b10 /* add SpecializationActive[TruffleString.ForceEncodingNode.compatibleMutable(MutableTruffleString, Encoding, Encoding, InternalAsTruffleStringNode)] */;
                    this.state_0_ = state_0;
                    return compatibleMutable(arg0Value_, arg1Value, arg2Value, INLINED_COMPATIBLE_MUTABLE_AS_TRUFFLE_STRING_NODE_);
                }
            }
            if ((!(ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value, arg1Value, arg2Value)))) {
                state_0 = state_0 | 0b100 /* add SpecializationActive[TruffleString.ForceEncodingNode.reinterpret(AbstractTruffleString, Encoding, Encoding, ToIndexableNode, InlinedConditionProfile, InternalCopyToByteArrayNode, FromBufferWithStringCompactionNode)] */;
                this.state_0_ = state_0;
                return reinterpret(arg0Value, arg1Value, arg2Value, INLINED_REINTERPRET_TO_INDEXABLE_NODE_, INLINED_REINTERPRET_INFLATE_PROFILE_, INLINED_REINTERPRET_COPY_TO_BYTE_ARRAY_NODE_, INLINED_REINTERPRET_FROM_BUFFER_WITH_STRING_COMPACTION_NODE_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b111) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                int counter = 0;
                counter += Integer.bitCount((state_0 & 0b111));
                if (counter == 1) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static ForceEncodingNode create() {
            return new ForceEncodingNodeGen();
        }

        @NeverDefault
        public static ForceEncodingNode getUncached() {
            return ForceEncodingNodeGen.UNCACHED;
        }

        @GeneratedBy(ForceEncodingNode.class)
        @DenyReplace
        private static final class Uncached extends ForceEncodingNode {

            @TruffleBoundary
            @Override
            public TruffleString execute(AbstractTruffleString arg0Value, Encoding arg1Value, Encoding arg2Value) {
                if (arg0Value instanceof TruffleString) {
                    TruffleString arg0Value_ = (TruffleString) arg0Value;
                    if ((ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value_, arg1Value, arg2Value))) {
                        return ForceEncodingNode.compatibleImmutable(arg0Value_, arg1Value, arg2Value);
                    }
                }
                if (arg0Value instanceof MutableTruffleString) {
                    MutableTruffleString arg0Value_ = (MutableTruffleString) arg0Value;
                    if ((ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value_, arg1Value, arg2Value))) {
                        return compatibleMutable(arg0Value_, arg1Value, arg2Value, (InternalAsTruffleStringNodeGen.getUncached()));
                    }
                }
                if ((!(ForceEncodingNode.isCompatibleAndNotCompacted(arg0Value, arg1Value, arg2Value)))) {
                    return reinterpret(arg0Value, arg1Value, arg2Value, (ToIndexableNodeGen.getUncached()), (InlinedConditionProfile.getUncached()), (InternalCopyToByteArrayNodeGen.getUncached()), (FromBufferWithStringCompactionNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CreateCodePointIteratorNode#createIterator}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(CreateCodePointIteratorNode.class)
    @SuppressWarnings("javadoc")
    static final class CreateCodePointIteratorNodeGen extends CreateCodePointIteratorNode {

        private static final StateField STATE_0_CreateCodePointIteratorNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CreateCodePointIteratorNode#createIterator}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CreateCodePointIteratorNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CreateCodePointIteratorNode#createIterator}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_CreateCodePointIteratorNode_UPDATER.subUpdater(7, 25)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CreateCodePointIteratorNode#createIterator}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link CreateCodePointIteratorNode#createIterator}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private CreateCodePointIteratorNodeGen() {
        }

        @Override
        public TruffleStringIterator execute(AbstractTruffleString arg0Value, Encoding arg1Value, ErrorHandling arg2Value) {
            return createIterator(arg0Value, arg1Value, arg2Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_A_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CreateCodePointIteratorNode create() {
            return new CreateCodePointIteratorNodeGen();
        }

        @NeverDefault
        public static CreateCodePointIteratorNode getUncached() {
            return CreateCodePointIteratorNodeGen.UNCACHED;
        }

        @GeneratedBy(CreateCodePointIteratorNode.class)
        @DenyReplace
        private static final class Uncached extends CreateCodePointIteratorNode {

            @TruffleBoundary
            @Override
            public TruffleStringIterator execute(AbstractTruffleString arg0Value, Encoding arg1Value, ErrorHandling arg2Value) {
                return createIterator(arg0Value, arg1Value, arg2Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link CreateBackwardCodePointIteratorNode#createIterator}
     *     Activation probability: 1.00000
     *     With/without class size: 24/4 bytes
     * </pre>
     */
    @GeneratedBy(CreateBackwardCodePointIteratorNode.class)
    @SuppressWarnings("javadoc")
    static final class CreateBackwardCodePointIteratorNodeGen extends CreateBackwardCodePointIteratorNode {

        private static final StateField STATE_0_CreateBackwardCodePointIteratorNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link CreateBackwardCodePointIteratorNode#createIterator}
         *   Parameter: {@link ToIndexableNode} toIndexableNode
         *   Inline method: {@link ToIndexableNodeGen#inline}</pre>
         */
        private static final ToIndexableNode INLINED_TO_INDEXABLE_NODE_ = ToIndexableNodeGen.inline(InlineTarget.create(ToIndexableNode.class, STATE_0_CreateBackwardCodePointIteratorNode_UPDATER.subUpdater(0, 7)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link CreateBackwardCodePointIteratorNode#createIterator}
         *   Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *   Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}</pre>
         */
        private static final GetCodeRangeForIndexCalculationNode INLINED_GET_CODE_RANGE_A_NODE_ = GetCodeRangeForIndexCalculationNodeGen.inline(InlineTarget.create(GetCodeRangeForIndexCalculationNode.class, STATE_0_CreateBackwardCodePointIteratorNode_UPDATER.subUpdater(7, 25)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0-6: InlinedCache
         *        Specialization: {@link CreateBackwardCodePointIteratorNode#createIterator}
         *        Parameter: {@link ToIndexableNode} toIndexableNode
         *        Inline method: {@link ToIndexableNodeGen#inline}
         *   7-31: InlinedCache
         *        Specialization: {@link CreateBackwardCodePointIteratorNode#createIterator}
         *        Parameter: {@link GetCodeRangeForIndexCalculationNode} getCodeRangeANode
         *        Inline method: {@link GetCodeRangeForIndexCalculationNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;

        private CreateBackwardCodePointIteratorNodeGen() {
        }

        @Override
        public TruffleStringIterator execute(AbstractTruffleString arg0Value, Encoding arg1Value, ErrorHandling arg2Value) {
            return createIterator(arg0Value, arg1Value, arg2Value, INLINED_TO_INDEXABLE_NODE_, INLINED_GET_CODE_RANGE_A_NODE_);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static CreateBackwardCodePointIteratorNode create() {
            return new CreateBackwardCodePointIteratorNodeGen();
        }

        @NeverDefault
        public static CreateBackwardCodePointIteratorNode getUncached() {
            return CreateBackwardCodePointIteratorNodeGen.UNCACHED;
        }

        @GeneratedBy(CreateBackwardCodePointIteratorNode.class)
        @DenyReplace
        private static final class Uncached extends CreateBackwardCodePointIteratorNode {

            @TruffleBoundary
            @Override
            public TruffleStringIterator execute(AbstractTruffleString arg0Value, Encoding arg1Value, ErrorHandling arg2Value) {
                return createIterator(arg0Value, arg1Value, arg2Value, (ToIndexableNodeGen.getUncached()), (GetCodeRangeForIndexCalculationNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
}
