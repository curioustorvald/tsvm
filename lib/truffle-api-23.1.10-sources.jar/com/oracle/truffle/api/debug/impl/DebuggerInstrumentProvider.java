// CheckStyle: start generated
package com.oracle.truffle.api.debug.impl;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.instrumentation.TruffleInstrument.Registration;
import com.oracle.truffle.api.instrumentation.provider.TruffleInstrumentProvider;
import java.util.Collection;
import java.util.List;

@GeneratedBy(DebuggerInstrument.class)
@Registration(id = "debugger", name = "Debugger")
public final class DebuggerInstrumentProvider extends TruffleInstrumentProvider {

    @Override
    protected String getInstrumentClassName() {
        return "com.oracle.truffle.api.debug.impl.DebuggerInstrument";
    }

    @Override
    protected Object create() {
        return new DebuggerInstrument();
    }

    @Override
    protected Collection<String> getServicesClassNames() {
        return List.of("com.oracle.truffle.api.debug.Debugger");
    }

    @Override
    protected List<String> getInternalResourceIds() {
        return List.of();
    }

    @Override
    protected Object createInternalResource(String resourceId) {
        throw new IllegalArgumentException(String.format("Unsupported internal resource id %s, supported ids are ", resourceId));
    }

}
