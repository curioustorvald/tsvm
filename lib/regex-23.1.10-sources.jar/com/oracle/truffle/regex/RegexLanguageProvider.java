// CheckStyle: start generated
package com.oracle.truffle.regex;

import com.oracle.truffle.api.TruffleLanguage.ContextPolicy;
import com.oracle.truffle.api.TruffleLanguage.Registration;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.instrumentation.ProvidedTags;
import com.oracle.truffle.api.instrumentation.StandardTags.RootTag;
import com.oracle.truffle.api.provider.TruffleLanguageProvider;
import java.util.Collection;
import java.util.List;
import org.graalvm.polyglot.SandboxPolicy;

@GeneratedBy(RegexLanguage.class)
@Registration(characterMimeTypes = "application/tregex", contextPolicy = ContextPolicy.SHARED, id = "regex", interactive = false, internal = true, name = "REGEX", sandbox = SandboxPolicy.UNTRUSTED, version = "0.1", website = "https://github.com/oracle/graal/tree/master/regex")
@ProvidedTags(RootTag.class)
public final class RegexLanguageProvider extends TruffleLanguageProvider {

    @Override
    protected String getLanguageClassName() {
        return "com.oracle.truffle.regex.RegexLanguage";
    }

    @Override
    protected Object create() {
        return new RegexLanguage();
    }

    @Override
    protected Collection<String> getServicesClassNames() {
        return List.of();
    }

    @Override
    protected List<?> createFileTypeDetectors() {
        return List.of();
    }

    @Override
    protected List<String> getInternalResourceIds() {
        return List.of();
    }

    @Override
    protected Object createInternalResource(String resourceId) {
        throw new IllegalArgumentException(String.format("Unsupported internal resource id %s, supported ids are ", resourceId));
    }

}
