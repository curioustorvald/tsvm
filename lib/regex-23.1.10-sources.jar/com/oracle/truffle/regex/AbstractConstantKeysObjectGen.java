// CheckStyle: start generated
package com.oracle.truffle.regex;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.DSLSupport;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.interop.UnknownIdentifierException;
import com.oracle.truffle.api.interop.UnsupportedMessageException;
import com.oracle.truffle.api.library.LibraryExport;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.ValueProfile;
import com.oracle.truffle.regex.AbstractConstantKeysObject.IsMemberReadable;
import com.oracle.truffle.regex.AbstractConstantKeysObject.ReadMember;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.Objects;

@GeneratedBy(AbstractConstantKeysObject.class)
@SuppressWarnings("javadoc")
public final class AbstractConstantKeysObjectGen {

    static  {
        LibraryExport.register(AbstractConstantKeysObject.class, new InteropLibraryExports());
    }

    private AbstractConstantKeysObjectGen() {
    }

    @GeneratedBy(AbstractConstantKeysObject.class)
    public static class InteropLibraryExports extends LibraryExport<InteropLibrary> {

        private InteropLibraryExports() {
            super(InteropLibrary.class, AbstractConstantKeysObject.class, false, false, 0);
        }

        @Override
        protected InteropLibrary createUncached(Object receiver) {
            assert receiver instanceof AbstractConstantKeysObject;
            InteropLibrary uncached = new Uncached(receiver);
            return uncached;
        }

        @Override
        protected InteropLibrary createCached(Object receiver) {
            assert receiver instanceof AbstractConstantKeysObject;
            return new Cached(receiver);
        }

        @GeneratedBy(AbstractConstantKeysObject.class)
        public static class Cached extends AbstractRegexObjectGen.InteropLibraryExports.Cached {

            static final ReferenceField<IsMemberReadableCacheIdentityData> IS_MEMBER_READABLE_CACHE_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "isMemberReadable_cacheIdentity_cache", IsMemberReadableCacheIdentityData.class);
            static final ReferenceField<IsMemberReadableCacheEqualsData> IS_MEMBER_READABLE_CACHE_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "isMemberReadable_cacheEquals_cache", IsMemberReadableCacheEqualsData.class);
            static final ReferenceField<ReadMemberReadIdentityData> READ_MEMBER_READ_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_readIdentity_cache", ReadMemberReadIdentityData.class);
            static final ReferenceField<ReadMemberReadEqualsData> READ_MEMBER_READ_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_readEquals_cache", ReadMemberReadEqualsData.class);

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link IsMemberReadable#cacheIdentity}
             *   1: SpecializationActive {@link IsMemberReadable#cacheEquals}
             *   2: SpecializationActive {@link IsMemberReadable#isReadable}
             *   3: SpecializationActive {@link ReadMember#readIdentity}
             *   4: SpecializationActive {@link ReadMember#readEquals}
             *   5: SpecializationActive {@link ReadMember#read}
             * </pre>
             */
            @CompilationFinal private int state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link IsMemberReadable#isReadable}
             *   Parameter: {@link ValueProfile} classProfile</pre>
             */
            @CompilationFinal private ValueProfile classProfile;
            @UnsafeAccessedField @CompilationFinal private IsMemberReadableCacheIdentityData isMemberReadable_cacheIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private IsMemberReadableCacheEqualsData isMemberReadable_cacheEquals_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberReadIdentityData readMember_readIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberReadEqualsData readMember_readEquals_cache;

            protected Cached(Object receiver) {
                super(receiver);
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link IsMemberReadable#cacheIdentity}
             *     Activation probability: 0.24167
             *     With/without class size: 10/9 bytes
             *   Specialization {@link IsMemberReadable#cacheEquals}
             *     Activation probability: 0.16667
             *     With/without class size: 8/9 bytes
             *   Specialization {@link IsMemberReadable#isReadable}
             *     Activation probability: 0.09167
             *     With/without class size: 5/0 bytes
             * </pre>
             */
            @ExplodeLoop
            @Override
            public boolean isMemberReadable(Object arg0Value_, String arg1Value) {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                AbstractConstantKeysObject arg0Value = ((AbstractConstantKeysObject) arg0Value_);
                int state_0 = this.state_0_;
                if ((state_0 & 0b111) != 0 /* is SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheIdentity(AbstractConstantKeysObject, String, String, Class<>, boolean)] || SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheEquals(AbstractConstantKeysObject, String, String, Class<>, boolean)] || SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.isReadable(AbstractConstantKeysObject, String, ValueProfile)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheIdentity(AbstractConstantKeysObject, String, String, Class<>, boolean)] */) {
                        IsMemberReadableCacheIdentityData s0_ = this.isMemberReadable_cacheIdentity_cache;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_) && (CompilerDirectives.isExact(arg0Value, s0_.cachedClass_))) {
                                assert DSLSupport.assertIdempotence((s0_.result_));
                                return IsMemberReadable.cacheIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.cachedClass_, s0_.result_);
                            }
                            s0_ = s0_.next_;
                        }
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheEquals(AbstractConstantKeysObject, String, String, Class<>, boolean)] */) {
                        IsMemberReadableCacheEqualsData s1_ = this.isMemberReadable_cacheEquals_cache;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_)) && (CompilerDirectives.isExact(arg0Value, s1_.cachedClass_))) {
                                assert DSLSupport.assertIdempotence((s1_.result_));
                                return IsMemberReadable.cacheEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.cachedClass_, s1_.result_);
                            }
                            s1_ = s1_.next_;
                        }
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.isReadable(AbstractConstantKeysObject, String, ValueProfile)] */) {
                        {
                            ValueProfile classProfile_ = this.classProfile;
                            if (classProfile_ != null) {
                                return IsMemberReadable.isReadable(arg0Value, arg1Value, classProfile_);
                            }
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return isMemberReadableAndSpecialize(arg0Value, arg1Value);
            }

            private boolean isMemberReadableAndSpecialize(AbstractConstantKeysObject arg0Value, String arg1Value) {
                int state_0 = this.state_0_;
                if (((state_0 & 0b110)) == 0 /* is-not SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheEquals(AbstractConstantKeysObject, String, String, Class<>, boolean)] && SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.isReadable(AbstractConstantKeysObject, String, ValueProfile)] */) {
                    while (true) {
                        int count0_ = 0;
                        IsMemberReadableCacheIdentityData s0_ = IS_MEMBER_READABLE_CACHE_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        IsMemberReadableCacheIdentityData s0_original = s0_;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_) && (CompilerDirectives.isExact(arg0Value, s0_.cachedClass_))) {
                                assert DSLSupport.assertIdempotence((s0_.result_));
                                break;
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            {
                                Class<?> cachedClass__ = (arg0Value.getClass());
                                // assert (arg1Value == s0_.cachedSymbol_);
                                if ((CompilerDirectives.isExact(arg0Value, cachedClass__))) {
                                    String cachedSymbol__ = (arg1Value);
                                    boolean result__ = (arg0Value.isMemberReadableImpl(cachedSymbol__));
                                    if ((result__) && count0_ < (8)) {
                                        s0_ = new IsMemberReadableCacheIdentityData(s0_original);
                                        s0_.cachedSymbol_ = cachedSymbol__;
                                        s0_.cachedClass_ = cachedClass__;
                                        s0_.result_ = result__;
                                        if (!IS_MEMBER_READABLE_CACHE_IDENTITY_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                            continue;
                                        }
                                        state_0 = state_0 | 0b1 /* add SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheIdentity(AbstractConstantKeysObject, String, String, Class<>, boolean)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                        }
                        if (s0_ != null) {
                            return IsMemberReadable.cacheIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.cachedClass_, s0_.result_);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100)) == 0 /* is-not SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.isReadable(AbstractConstantKeysObject, String, ValueProfile)] */) {
                    while (true) {
                        int count1_ = 0;
                        IsMemberReadableCacheEqualsData s1_ = IS_MEMBER_READABLE_CACHE_EQUALS_CACHE_UPDATER.getVolatile(this);
                        IsMemberReadableCacheEqualsData s1_original = s1_;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_)) && (CompilerDirectives.isExact(arg0Value, s1_.cachedClass_))) {
                                assert DSLSupport.assertIdempotence((s1_.result_));
                                break;
                            }
                            count1_++;
                            s1_ = s1_.next_;
                        }
                        if (s1_ == null) {
                            {
                                Class<?> cachedClass__1 = (arg0Value.getClass());
                                // assert (arg1Value.equals(s1_.cachedSymbol_));
                                if ((CompilerDirectives.isExact(arg0Value, cachedClass__1))) {
                                    String cachedSymbol__1 = (arg1Value);
                                    boolean result__1 = (arg0Value.isMemberReadableImpl(cachedSymbol__1));
                                    if ((result__1) && count1_ < (8)) {
                                        s1_ = new IsMemberReadableCacheEqualsData(s1_original);
                                        s1_.cachedSymbol_ = cachedSymbol__1;
                                        s1_.cachedClass_ = cachedClass__1;
                                        s1_.result_ = result__1;
                                        if (!IS_MEMBER_READABLE_CACHE_EQUALS_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                            continue;
                                        }
                                        this.isMemberReadable_cacheIdentity_cache = null;
                                        state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheIdentity(AbstractConstantKeysObject, String, String, Class<>, boolean)] */;
                                        state_0 = state_0 | 0b10 /* add SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheEquals(AbstractConstantKeysObject, String, String, Class<>, boolean)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                        }
                        if (s1_ != null) {
                            return IsMemberReadable.cacheEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.cachedClass_, s1_.result_);
                        }
                        break;
                    }
                }
                ValueProfile classProfile_;
                ValueProfile classProfile__shared = this.classProfile;
                if (classProfile__shared != null) {
                    classProfile_ = classProfile__shared;
                } else {
                    classProfile_ = (ValueProfile.createClassProfile());
                    if (classProfile_ == null) {
                        throw new IllegalStateException("Specialization 'isReadable(AbstractConstantKeysObject, String, ValueProfile)' contains a shared cache with name 'classProfile' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                    }
                }
                if (this.classProfile == null) {
                    VarHandle.storeStoreFence();
                    this.classProfile = classProfile_;
                }
                this.isMemberReadable_cacheIdentity_cache = null;
                this.isMemberReadable_cacheEquals_cache = null;
                state_0 = state_0 & 0xfffffffc /* remove SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheIdentity(AbstractConstantKeysObject, String, String, Class<>, boolean)], SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.cacheEquals(AbstractConstantKeysObject, String, String, Class<>, boolean)] */;
                state_0 = state_0 | 0b100 /* add SpecializationActive[AbstractConstantKeysObject.IsMemberReadable.isReadable(AbstractConstantKeysObject, String, ValueProfile)] */;
                this.state_0_ = state_0;
                return IsMemberReadable.isReadable(arg0Value, arg1Value, classProfile_);
            }

            @Override
            public NodeCost getCost() {
                int state_0 = this.state_0_;
                if ((state_0 & 0b111) == 0) {
                    return NodeCost.UNINITIALIZED;
                } else {
                    if (((state_0 & 0b111) & ((state_0 & 0b111) - 1)) == 0 /* is-single  */) {
                        IsMemberReadableCacheIdentityData s0_ = this.isMemberReadable_cacheIdentity_cache;
                        IsMemberReadableCacheEqualsData s1_ = this.isMemberReadable_cacheEquals_cache;
                        if ((s0_ == null || s0_.next_ == null) && (s1_ == null || s1_.next_ == null)) {
                            return NodeCost.MONOMORPHIC;
                        }
                    }
                }
                return NodeCost.POLYMORPHIC;
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link ReadMember#readIdentity}
             *     Activation probability: 0.24167
             *     With/without class size: 9/8 bytes
             *   Specialization {@link ReadMember#readEquals}
             *     Activation probability: 0.16667
             *     With/without class size: 8/8 bytes
             *   Specialization {@link ReadMember#read}
             *     Activation probability: 0.09167
             *     With/without class size: 5/0 bytes
             * </pre>
             */
            @ExplodeLoop
            @Override
            public Object readMember(Object arg0Value_, String arg1Value) throws UnsupportedMessageException, UnknownIdentifierException {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                AbstractConstantKeysObject arg0Value = ((AbstractConstantKeysObject) arg0Value_);
                int state_0 = this.state_0_;
                if ((state_0 & 0b111000) != 0 /* is SpecializationActive[AbstractConstantKeysObject.ReadMember.readIdentity(AbstractConstantKeysObject, String, String, ValueProfile)] || SpecializationActive[AbstractConstantKeysObject.ReadMember.readEquals(AbstractConstantKeysObject, String, String, ValueProfile)] || SpecializationActive[AbstractConstantKeysObject.ReadMember.read(AbstractConstantKeysObject, String, ValueProfile)] */) {
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[AbstractConstantKeysObject.ReadMember.readIdentity(AbstractConstantKeysObject, String, String, ValueProfile)] */) {
                        ReadMemberReadIdentityData s0_ = this.readMember_readIdentity_cache;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                return ReadMember.readIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.classProfile_);
                            }
                            s0_ = s0_.next_;
                        }
                    }
                    if ((state_0 & 0b10000) != 0 /* is SpecializationActive[AbstractConstantKeysObject.ReadMember.readEquals(AbstractConstantKeysObject, String, String, ValueProfile)] */) {
                        ReadMemberReadEqualsData s1_ = this.readMember_readEquals_cache;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                return ReadMember.readEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.classProfile_);
                            }
                            s1_ = s1_.next_;
                        }
                    }
                    if ((state_0 & 0b100000) != 0 /* is SpecializationActive[AbstractConstantKeysObject.ReadMember.read(AbstractConstantKeysObject, String, ValueProfile)] */) {
                        {
                            ValueProfile classProfile_ = this.classProfile;
                            if (classProfile_ != null) {
                                return ReadMember.read(arg0Value, arg1Value, classProfile_);
                            }
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return readMemberAndSpecialize(arg0Value, arg1Value);
            }

            private Object readMemberAndSpecialize(AbstractConstantKeysObject arg0Value, String arg1Value) throws UnknownIdentifierException {
                int state_0 = this.state_0_;
                if (((state_0 & 0b110000)) == 0 /* is-not SpecializationActive[AbstractConstantKeysObject.ReadMember.readEquals(AbstractConstantKeysObject, String, String, ValueProfile)] && SpecializationActive[AbstractConstantKeysObject.ReadMember.read(AbstractConstantKeysObject, String, ValueProfile)] */) {
                    while (true) {
                        int count0_ = 0;
                        ReadMemberReadIdentityData s0_ = READ_MEMBER_READ_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        ReadMemberReadIdentityData s0_original = s0_;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                break;
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            // assert (arg1Value == s0_.cachedSymbol_);
                            if (count0_ < (8)) {
                                s0_ = new ReadMemberReadIdentityData(s0_original);
                                s0_.cachedSymbol_ = (arg1Value);
                                ValueProfile classProfile__ = (ValueProfile.createClassProfile());
                                Objects.requireNonNull(classProfile__, "Specialization 'readIdentity(AbstractConstantKeysObject, String, String, ValueProfile)' cache 'classProfile' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                                s0_.classProfile_ = classProfile__;
                                if (!READ_MEMBER_READ_IDENTITY_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                    continue;
                                }
                                state_0 = state_0 | 0b1000 /* add SpecializationActive[AbstractConstantKeysObject.ReadMember.readIdentity(AbstractConstantKeysObject, String, String, ValueProfile)] */;
                                this.state_0_ = state_0;
                            }
                        }
                        if (s0_ != null) {
                            return ReadMember.readIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.classProfile_);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100000)) == 0 /* is-not SpecializationActive[AbstractConstantKeysObject.ReadMember.read(AbstractConstantKeysObject, String, ValueProfile)] */) {
                    while (true) {
                        int count1_ = 0;
                        ReadMemberReadEqualsData s1_ = READ_MEMBER_READ_EQUALS_CACHE_UPDATER.getVolatile(this);
                        ReadMemberReadEqualsData s1_original = s1_;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                break;
                            }
                            count1_++;
                            s1_ = s1_.next_;
                        }
                        if (s1_ == null) {
                            // assert (arg1Value.equals(s1_.cachedSymbol_));
                            if (count1_ < (8)) {
                                s1_ = new ReadMemberReadEqualsData(s1_original);
                                s1_.cachedSymbol_ = (arg1Value);
                                ValueProfile classProfile__1 = (ValueProfile.createClassProfile());
                                Objects.requireNonNull(classProfile__1, "Specialization 'readEquals(AbstractConstantKeysObject, String, String, ValueProfile)' cache 'classProfile' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                                s1_.classProfile_ = classProfile__1;
                                if (!READ_MEMBER_READ_EQUALS_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                    continue;
                                }
                                this.readMember_readIdentity_cache = null;
                                state_0 = state_0 & 0xfffffff7 /* remove SpecializationActive[AbstractConstantKeysObject.ReadMember.readIdentity(AbstractConstantKeysObject, String, String, ValueProfile)] */;
                                state_0 = state_0 | 0b10000 /* add SpecializationActive[AbstractConstantKeysObject.ReadMember.readEquals(AbstractConstantKeysObject, String, String, ValueProfile)] */;
                                this.state_0_ = state_0;
                            }
                        }
                        if (s1_ != null) {
                            return ReadMember.readEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.classProfile_);
                        }
                        break;
                    }
                }
                ValueProfile classProfile_;
                ValueProfile classProfile__shared = this.classProfile;
                if (classProfile__shared != null) {
                    classProfile_ = classProfile__shared;
                } else {
                    classProfile_ = (ValueProfile.createClassProfile());
                    if (classProfile_ == null) {
                        throw new IllegalStateException("Specialization 'read(AbstractConstantKeysObject, String, ValueProfile)' contains a shared cache with name 'classProfile' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                    }
                }
                if (this.classProfile == null) {
                    VarHandle.storeStoreFence();
                    this.classProfile = classProfile_;
                }
                this.readMember_readIdentity_cache = null;
                this.readMember_readEquals_cache = null;
                state_0 = state_0 & 0xffffffe7 /* remove SpecializationActive[AbstractConstantKeysObject.ReadMember.readIdentity(AbstractConstantKeysObject, String, String, ValueProfile)], SpecializationActive[AbstractConstantKeysObject.ReadMember.readEquals(AbstractConstantKeysObject, String, String, ValueProfile)] */;
                state_0 = state_0 | 0b100000 /* add SpecializationActive[AbstractConstantKeysObject.ReadMember.read(AbstractConstantKeysObject, String, ValueProfile)] */;
                this.state_0_ = state_0;
                return ReadMember.read(arg0Value, arg1Value, classProfile_);
            }

            @Override
            public boolean hasMembers(Object receiver) {
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                return (((AbstractConstantKeysObject) receiver)).hasMembers();
            }

            @Override
            public Object getMembers(Object receiver, boolean includeInternal) throws UnsupportedMessageException {
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                return (((AbstractConstantKeysObject) receiver)).getMembers(includeInternal);
            }

            @GeneratedBy(AbstractConstantKeysObject.class)
            @DenyReplace
            private static final class IsMemberReadableCacheIdentityData implements SpecializationDataNode {

                @CompilationFinal final IsMemberReadableCacheIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheIdentity}
                 *   Parameter: {@link Class} cachedClass</pre>
                 */
                @CompilationFinal Class<?> cachedClass_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheIdentity}
                 *   Parameter: boolean result</pre>
                 */
                @CompilationFinal boolean result_;

                IsMemberReadableCacheIdentityData(IsMemberReadableCacheIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(AbstractConstantKeysObject.class)
            @DenyReplace
            private static final class IsMemberReadableCacheEqualsData implements SpecializationDataNode {

                @CompilationFinal final IsMemberReadableCacheEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheEquals}
                 *   Parameter: {@link Class} cachedClass</pre>
                 */
                @CompilationFinal Class<?> cachedClass_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheEquals}
                 *   Parameter: boolean result</pre>
                 */
                @CompilationFinal boolean result_;

                IsMemberReadableCacheEqualsData(IsMemberReadableCacheEqualsData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(AbstractConstantKeysObject.class)
            @DenyReplace
            private static final class ReadMemberReadIdentityData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberReadIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#readIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#readIdentity}
                 *   Parameter: {@link ValueProfile} classProfile</pre>
                 */
                @CompilationFinal ValueProfile classProfile_;

                ReadMemberReadIdentityData(ReadMemberReadIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(AbstractConstantKeysObject.class)
            @DenyReplace
            private static final class ReadMemberReadEqualsData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberReadEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#readEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#readEquals}
                 *   Parameter: {@link ValueProfile} classProfile</pre>
                 */
                @CompilationFinal ValueProfile classProfile_;

                ReadMemberReadEqualsData(ReadMemberReadEqualsData next_) {
                    this.next_ = next_;
                }

            }
        }
        @GeneratedBy(AbstractConstantKeysObject.class)
        public static class Uncached extends AbstractRegexObjectGen.InteropLibraryExports.Uncached {

            protected Uncached(Object receiver) {
                super(receiver);
            }

            @Override
            @TruffleBoundary
            public boolean accepts(Object receiver) {
                return super.accepts(receiver);
            }

            @TruffleBoundary
            @Override
            public boolean isMemberReadable(Object arg0Value_, String arg1Value) {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                AbstractConstantKeysObject arg0Value = ((AbstractConstantKeysObject) arg0Value_);
                return IsMemberReadable.isReadable(arg0Value, arg1Value, (ValueProfile.getUncached()));
            }

            @TruffleBoundary
            @Override
            public Object readMember(Object arg0Value_, String arg1Value) throws UnknownIdentifierException, UnsupportedMessageException {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                AbstractConstantKeysObject arg0Value = ((AbstractConstantKeysObject) arg0Value_);
                return ReadMember.read(arg0Value, arg1Value, (ValueProfile.getUncached()));
            }

            @TruffleBoundary
            @Override
            public boolean hasMembers(Object receiver) {
                // declared: true
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                return ((AbstractConstantKeysObject) receiver) .hasMembers();
            }

            @TruffleBoundary
            @Override
            public Object getMembers(Object receiver, boolean includeInternal) throws UnsupportedMessageException {
                // declared: true
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                return ((AbstractConstantKeysObject) receiver) .getMembers(includeInternal);
            }

        }
    }
}
