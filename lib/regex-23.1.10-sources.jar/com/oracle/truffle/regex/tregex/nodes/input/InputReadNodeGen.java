// CheckStyle: start generated
package com.oracle.truffle.regex.tregex.nodes.input;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.RequiredField;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.strings.TruffleString;
import com.oracle.truffle.api.strings.TruffleString.CodePointAtIndexNode;
import com.oracle.truffle.api.strings.TruffleString.ReadByteNode;
import com.oracle.truffle.api.strings.TruffleString.ReadCharUTF16Node;
import com.oracle.truffle.regex.tregex.string.Encodings;
import com.oracle.truffle.regex.tregex.string.Encodings.Encoding;
import java.lang.invoke.VarHandle;
import java.util.Objects;

/**
 * Debug Info: <pre>
 *   Specialization {@link InputReadNode#doTStringUTF8}
 *     Activation probability: 0.48333
 *     With/without class size: 13/4 bytes
 *   Specialization {@link InputReadNode#doTStringUTF16}
 *     Activation probability: 0.33333
 *     With/without class size: 10/4 bytes
 *   Specialization {@link InputReadNode#doTStringUTF32}
 *     Activation probability: 0.18333
 *     With/without class size: 7/4 bytes
 * </pre>
 */
@GeneratedBy(InputReadNode.class)
@SuppressWarnings("javadoc")
public final class InputReadNodeGen extends InputReadNode {

    private static final Uncached UNCACHED = new Uncached();

    /**
     * State Info: <pre>
     *   0: SpecializationActive {@link InputReadNode#doTStringUTF8}
     *   1: SpecializationActive {@link InputReadNode#doTStringUTF16}
     *   2: SpecializationActive {@link InputReadNode#doTStringUTF32}
     * </pre>
     */
    @CompilationFinal private int state_0_;
    /**
     * Source Info: <pre>
     *   Specialization: {@link InputReadNode#doTStringUTF8}
     *   Parameter: {@link ReadByteNode} readRawNode</pre>
     */
    @Child private ReadByteNode tStringUTF8_readRawNode_;
    /**
     * Source Info: <pre>
     *   Specialization: {@link InputReadNode#doTStringUTF16}
     *   Parameter: {@link ReadCharUTF16Node} readRawNode</pre>
     */
    @Child private ReadCharUTF16Node tStringUTF16_readRawNode_;
    /**
     * Source Info: <pre>
     *   Specialization: {@link InputReadNode#doTStringUTF32}
     *   Parameter: {@link CodePointAtIndexNode} readRawNode</pre>
     */
    @Child private CodePointAtIndexNode tStringUTF32_readRawNode_;

    private InputReadNodeGen() {
    }

    @Override
    public int execute(Node arg0Value, TruffleString arg1Value, int arg2Value, Encoding arg3Value) {
        int state_0 = this.state_0_;
        if (state_0 != 0 /* is SpecializationActive[InputReadNode.doTStringUTF8(TruffleString, int, Encoding, ReadByteNode)] || SpecializationActive[InputReadNode.doTStringUTF16(TruffleString, int, Encoding, ReadCharUTF16Node)] || SpecializationActive[InputReadNode.doTStringUTF32(TruffleString, int, Encoding, CodePointAtIndexNode)] */) {
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[InputReadNode.doTStringUTF8(TruffleString, int, Encoding, ReadByteNode)] */) {
                {
                    ReadByteNode readRawNode__ = this.tStringUTF8_readRawNode_;
                    if (readRawNode__ != null) {
                        if ((arg3Value != Encodings.UTF_16) && (arg3Value != Encodings.UTF_32) && (arg3Value != Encodings.UTF_16_RAW)) {
                            return InputReadNode.doTStringUTF8(arg1Value, arg2Value, arg3Value, readRawNode__);
                        }
                    }
                }
            }
            if ((state_0 & 0b10) != 0 /* is SpecializationActive[InputReadNode.doTStringUTF16(TruffleString, int, Encoding, ReadCharUTF16Node)] */) {
                {
                    ReadCharUTF16Node readRawNode__1 = this.tStringUTF16_readRawNode_;
                    if (readRawNode__1 != null) {
                        if ((arg3Value == Encodings.UTF_16 || arg3Value == Encodings.UTF_16_RAW)) {
                            return InputReadNode.doTStringUTF16(arg1Value, arg2Value, arg3Value, readRawNode__1);
                        }
                    }
                }
            }
            if ((state_0 & 0b100) != 0 /* is SpecializationActive[InputReadNode.doTStringUTF32(TruffleString, int, Encoding, CodePointAtIndexNode)] */) {
                {
                    CodePointAtIndexNode readRawNode__2 = this.tStringUTF32_readRawNode_;
                    if (readRawNode__2 != null) {
                        if ((arg3Value == Encodings.UTF_32)) {
                            return InputReadNode.doTStringUTF32(arg1Value, arg2Value, arg3Value, readRawNode__2);
                        }
                    }
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
    }

    private int executeAndSpecialize(Node arg0Value, TruffleString arg1Value, int arg2Value, Encoding arg3Value) {
        int state_0 = this.state_0_;
        if ((arg3Value != Encodings.UTF_16) && (arg3Value != Encodings.UTF_32) && (arg3Value != Encodings.UTF_16_RAW)) {
            ReadByteNode readRawNode__ = this.insert((ReadByteNode.create()));
            Objects.requireNonNull(readRawNode__, "Specialization 'doTStringUTF8(TruffleString, int, Encoding, ReadByteNode)' cache 'readRawNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.tStringUTF8_readRawNode_ = readRawNode__;
            state_0 = state_0 | 0b1 /* add SpecializationActive[InputReadNode.doTStringUTF8(TruffleString, int, Encoding, ReadByteNode)] */;
            this.state_0_ = state_0;
            return InputReadNode.doTStringUTF8(arg1Value, arg2Value, arg3Value, readRawNode__);
        }
        if ((arg3Value == Encodings.UTF_16 || arg3Value == Encodings.UTF_16_RAW)) {
            ReadCharUTF16Node readRawNode__1 = this.insert((ReadCharUTF16Node.create()));
            Objects.requireNonNull(readRawNode__1, "Specialization 'doTStringUTF16(TruffleString, int, Encoding, ReadCharUTF16Node)' cache 'readRawNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.tStringUTF16_readRawNode_ = readRawNode__1;
            state_0 = state_0 | 0b10 /* add SpecializationActive[InputReadNode.doTStringUTF16(TruffleString, int, Encoding, ReadCharUTF16Node)] */;
            this.state_0_ = state_0;
            return InputReadNode.doTStringUTF16(arg1Value, arg2Value, arg3Value, readRawNode__1);
        }
        if ((arg3Value == Encodings.UTF_32)) {
            CodePointAtIndexNode readRawNode__2 = this.insert((CodePointAtIndexNode.create()));
            Objects.requireNonNull(readRawNode__2, "Specialization 'doTStringUTF32(TruffleString, int, Encoding, CodePointAtIndexNode)' cache 'readRawNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.tStringUTF32_readRawNode_ = readRawNode__2;
            state_0 = state_0 | 0b100 /* add SpecializationActive[InputReadNode.doTStringUTF32(TruffleString, int, Encoding, CodePointAtIndexNode)] */;
            this.state_0_ = state_0;
            return InputReadNode.doTStringUTF32(arg1Value, arg2Value, arg3Value, readRawNode__2);
        }
        throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
    }

    @Override
    public NodeCost getCost() {
        int state_0 = this.state_0_;
        if (state_0 == 0) {
            return NodeCost.UNINITIALIZED;
        } else {
            if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                return NodeCost.MONOMORPHIC;
            }
        }
        return NodeCost.POLYMORPHIC;
    }

    @NeverDefault
    public static InputReadNode create() {
        return new InputReadNodeGen();
    }

    @NeverDefault
    public static InputReadNode getUncached() {
        return InputReadNodeGen.UNCACHED;
    }

    /**
     * Required Fields: <ul>
     * <li>{@link Inlined#state_0_}
     * <li>{@link Inlined#tStringUTF8_readRawNode_}
     * <li>{@link Inlined#tStringUTF16_readRawNode_}
     * <li>{@link Inlined#tStringUTF32_readRawNode_}
     * </ul>
     */
    @NeverDefault
    public static InputReadNode inline(@RequiredField(bits = 3, value = StateField.class)@RequiredField(type = Node.class, value = ReferenceField.class)@RequiredField(type = Node.class, value = ReferenceField.class)@RequiredField(type = Node.class, value = ReferenceField.class) InlineTarget target) {
        return new InputReadNodeGen.Inlined(target);
    }

    @GeneratedBy(InputReadNode.class)
    @DenyReplace
    private static final class Inlined extends InputReadNode {

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link InputReadNode#doTStringUTF8}
         *   1: SpecializationActive {@link InputReadNode#doTStringUTF16}
         *   2: SpecializationActive {@link InputReadNode#doTStringUTF32}
         * </pre>
         */
        private final StateField state_0_;
        private final ReferenceField<ReadByteNode> tStringUTF8_readRawNode_;
        private final ReferenceField<ReadCharUTF16Node> tStringUTF16_readRawNode_;
        private final ReferenceField<CodePointAtIndexNode> tStringUTF32_readRawNode_;

        @SuppressWarnings("unchecked")
        private Inlined(InlineTarget target) {
            assert target.getTargetClass().isAssignableFrom(InputReadNode.class);
            this.state_0_ = target.getState(0, 3);
            this.tStringUTF8_readRawNode_ = target.getReference(1, ReadByteNode.class);
            this.tStringUTF16_readRawNode_ = target.getReference(2, ReadCharUTF16Node.class);
            this.tStringUTF32_readRawNode_ = target.getReference(3, CodePointAtIndexNode.class);
        }

        @Override
        public int execute(Node arg0Value, TruffleString arg1Value, int arg2Value, Encoding arg3Value) {
            int state_0 = this.state_0_.get(arg0Value);
            if (state_0 != 0 /* is SpecializationActive[InputReadNode.doTStringUTF8(TruffleString, int, Encoding, ReadByteNode)] || SpecializationActive[InputReadNode.doTStringUTF16(TruffleString, int, Encoding, ReadCharUTF16Node)] || SpecializationActive[InputReadNode.doTStringUTF32(TruffleString, int, Encoding, CodePointAtIndexNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[InputReadNode.doTStringUTF8(TruffleString, int, Encoding, ReadByteNode)] */) {
                    {
                        ReadByteNode readRawNode__ = this.tStringUTF8_readRawNode_.get(arg0Value);
                        if (readRawNode__ != null) {
                            if ((arg3Value != Encodings.UTF_16) && (arg3Value != Encodings.UTF_32) && (arg3Value != Encodings.UTF_16_RAW)) {
                                return InputReadNode.doTStringUTF8(arg1Value, arg2Value, arg3Value, readRawNode__);
                            }
                        }
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[InputReadNode.doTStringUTF16(TruffleString, int, Encoding, ReadCharUTF16Node)] */) {
                    {
                        ReadCharUTF16Node readRawNode__1 = this.tStringUTF16_readRawNode_.get(arg0Value);
                        if (readRawNode__1 != null) {
                            if ((arg3Value == Encodings.UTF_16 || arg3Value == Encodings.UTF_16_RAW)) {
                                return InputReadNode.doTStringUTF16(arg1Value, arg2Value, arg3Value, readRawNode__1);
                            }
                        }
                    }
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[InputReadNode.doTStringUTF32(TruffleString, int, Encoding, CodePointAtIndexNode)] */) {
                    {
                        CodePointAtIndexNode readRawNode__2 = this.tStringUTF32_readRawNode_.get(arg0Value);
                        if (readRawNode__2 != null) {
                            if ((arg3Value == Encodings.UTF_32)) {
                                return InputReadNode.doTStringUTF32(arg1Value, arg2Value, arg3Value, readRawNode__2);
                            }
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
        }

        private int executeAndSpecialize(Node arg0Value, TruffleString arg1Value, int arg2Value, Encoding arg3Value) {
            int state_0 = this.state_0_.get(arg0Value);
            if ((arg3Value != Encodings.UTF_16) && (arg3Value != Encodings.UTF_32) && (arg3Value != Encodings.UTF_16_RAW)) {
                ReadByteNode readRawNode__ = arg0Value.insert((ReadByteNode.create()));
                Objects.requireNonNull(readRawNode__, "Specialization 'doTStringUTF8(TruffleString, int, Encoding, ReadByteNode)' cache 'readRawNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.tStringUTF8_readRawNode_.set(arg0Value, readRawNode__);
                state_0 = state_0 | 0b1 /* add SpecializationActive[InputReadNode.doTStringUTF8(TruffleString, int, Encoding, ReadByteNode)] */;
                this.state_0_.set(arg0Value, state_0);
                return InputReadNode.doTStringUTF8(arg1Value, arg2Value, arg3Value, readRawNode__);
            }
            if ((arg3Value == Encodings.UTF_16 || arg3Value == Encodings.UTF_16_RAW)) {
                ReadCharUTF16Node readRawNode__1 = arg0Value.insert((ReadCharUTF16Node.create()));
                Objects.requireNonNull(readRawNode__1, "Specialization 'doTStringUTF16(TruffleString, int, Encoding, ReadCharUTF16Node)' cache 'readRawNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.tStringUTF16_readRawNode_.set(arg0Value, readRawNode__1);
                state_0 = state_0 | 0b10 /* add SpecializationActive[InputReadNode.doTStringUTF16(TruffleString, int, Encoding, ReadCharUTF16Node)] */;
                this.state_0_.set(arg0Value, state_0);
                return InputReadNode.doTStringUTF16(arg1Value, arg2Value, arg3Value, readRawNode__1);
            }
            if ((arg3Value == Encodings.UTF_32)) {
                CodePointAtIndexNode readRawNode__2 = arg0Value.insert((CodePointAtIndexNode.create()));
                Objects.requireNonNull(readRawNode__2, "Specialization 'doTStringUTF32(TruffleString, int, Encoding, CodePointAtIndexNode)' cache 'readRawNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.tStringUTF32_readRawNode_.set(arg0Value, readRawNode__2);
                state_0 = state_0 | 0b100 /* add SpecializationActive[InputReadNode.doTStringUTF32(TruffleString, int, Encoding, CodePointAtIndexNode)] */;
                this.state_0_.set(arg0Value, state_0);
                return InputReadNode.doTStringUTF32(arg1Value, arg2Value, arg3Value, readRawNode__2);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
        }

        @Override
        public boolean isAdoptable() {
            return false;
        }

    }
    @GeneratedBy(InputReadNode.class)
    @DenyReplace
    private static final class Uncached extends InputReadNode {

        @TruffleBoundary
        @Override
        public int execute(Node arg0Value, TruffleString arg1Value, int arg2Value, Encoding arg3Value) {
            if ((arg3Value != Encodings.UTF_16) && (arg3Value != Encodings.UTF_32) && (arg3Value != Encodings.UTF_16_RAW)) {
                return InputReadNode.doTStringUTF8(arg1Value, arg2Value, arg3Value, (ReadByteNode.getUncached()));
            }
            if ((arg3Value == Encodings.UTF_16 || arg3Value == Encodings.UTF_16_RAW)) {
                return InputReadNode.doTStringUTF16(arg1Value, arg2Value, arg3Value, (ReadCharUTF16Node.getUncached()));
            }
            if ((arg3Value == Encodings.UTF_32)) {
                return InputReadNode.doTStringUTF32(arg1Value, arg2Value, arg3Value, (CodePointAtIndexNode.getUncached()));
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MEGAMORPHIC;
        }

        @Override
        public boolean isAdoptable() {
            return false;
        }

    }
}
