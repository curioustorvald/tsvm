// CheckStyle: start generated
package com.oracle.truffle.regex.tregex.nodes;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.DSLSupport;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.DirectCallNode;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.InlinedConditionProfile;
import com.oracle.truffle.api.strings.TruffleString;
import com.oracle.truffle.api.strings.TruffleString.CodeRange;
import com.oracle.truffle.api.strings.TruffleString.GetCodeRangeImpreciseNode;
import com.oracle.truffle.api.strings.TruffleString.GetCodeRangeNode;
import com.oracle.truffle.api.strings.TruffleString.MaterializeNode;
import com.oracle.truffle.regex.RegexLanguage;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.Objects;

/**
 * Debug Info: <pre>
 *   Specialization {@link TRegexExecutorEntryNode#doTString}
 *     Activation probability: 1.00000
 *     With/without class size: 36/13 bytes
 * </pre>
 */
@GeneratedBy(TRegexExecutorEntryNode.class)
@SuppressWarnings("javadoc")
public final class TRegexExecutorEntryNodeGen extends TRegexExecutorEntryNode {

    private static final StateField STATE_0_TRegexExecutorEntryNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
    /**
     * Source Info: <pre>
     *   Specialization: {@link TRegexExecutorEntryNode#doTString}
     *   Parameter: {@link InlinedConditionProfile} isLatin1Profile
     *   Inline method: {@link InlinedConditionProfile#inline}</pre>
     */
    private static final InlinedConditionProfile INLINED_IS_LATIN1_PROFILE_ = InlinedConditionProfile.inline(InlineTarget.create(InlinedConditionProfile.class, STATE_0_TRegexExecutorEntryNode_UPDATER.subUpdater(1, 2)));
    @CompilationFinal(dimensions = 1) private static final CodeRange[] CODE_RANGE_VALUES = DSLSupport.lookupEnumConstants(CodeRange.class);

    /**
     * State Info: <pre>
     *   0: SpecializationActive {@link TRegexExecutorEntryNode#doTString}
     *   1-2: InlinedCache
     *        Specialization: {@link TRegexExecutorEntryNode#doTString}
     *        Parameter: {@link InlinedConditionProfile} isLatin1Profile
     *        Inline method: {@link InlinedConditionProfile#inline}
     * </pre>
     */
    @CompilationFinal @UnsafeAccessedField private int state_0_;
    /**
     * Source Info: <pre>
     *   Specialization: {@link TRegexExecutorEntryNode#doTString}
     *   Parameter: {@link MaterializeNode} materializeNode</pre>
     */
    @Child private MaterializeNode materializeNode_;
    /**
     * Source Info: <pre>
     *   Specialization: {@link TRegexExecutorEntryNode#doTString}
     *   Parameter: {@link GetCodeRangeImpreciseNode} codeRangeImpreciseNode</pre>
     */
    @Child private GetCodeRangeImpreciseNode codeRangeImpreciseNode_;
    /**
     * Source Info: <pre>
     *   Specialization: {@link TRegexExecutorEntryNode#doTString}
     *   Parameter: {@link GetCodeRangeNode} codeRangePreciseNode</pre>
     */
    @Child private GetCodeRangeNode codeRangePreciseNode_;

    private TRegexExecutorEntryNodeGen(RegexLanguage language, TRegexExecutorBaseNode executor) {
        super(language, executor);
    }

    @Override
    public Object execute(VirtualFrame frameValue, TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value) {
        int state_0 = this.state_0_;
        if ((state_0 & 0b1) != 0 /* is SpecializationActive[TRegexExecutorEntryNode.doTString(VirtualFrame, TruffleString, int, int, int, int, int, MaterializeNode, GetCodeRangeImpreciseNode, GetCodeRangeNode, InlinedConditionProfile)] */) {
            {
                MaterializeNode materializeNode__ = this.materializeNode_;
                if (materializeNode__ != null) {
                    GetCodeRangeImpreciseNode codeRangeImpreciseNode__ = this.codeRangeImpreciseNode_;
                    if (codeRangeImpreciseNode__ != null) {
                        GetCodeRangeNode codeRangePreciseNode__ = this.codeRangePreciseNode_;
                        if (codeRangePreciseNode__ != null) {
                            return doTString(frameValue, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, materializeNode__, codeRangeImpreciseNode__, codeRangePreciseNode__, INLINED_IS_LATIN1_PROFILE_);
                        }
                    }
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(frameValue, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
    }

    private Object executeAndSpecialize(VirtualFrame frameValue, TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value) {
        int state_0 = this.state_0_;
        MaterializeNode materializeNode__ = this.insert((MaterializeNode.create()));
        Objects.requireNonNull(materializeNode__, "Specialization 'doTString(VirtualFrame, TruffleString, int, int, int, int, int, MaterializeNode, GetCodeRangeImpreciseNode, GetCodeRangeNode, InlinedConditionProfile)' cache 'materializeNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
        VarHandle.storeStoreFence();
        this.materializeNode_ = materializeNode__;
        GetCodeRangeImpreciseNode codeRangeImpreciseNode__ = this.insert((GetCodeRangeImpreciseNode.create()));
        Objects.requireNonNull(codeRangeImpreciseNode__, "Specialization 'doTString(VirtualFrame, TruffleString, int, int, int, int, int, MaterializeNode, GetCodeRangeImpreciseNode, GetCodeRangeNode, InlinedConditionProfile)' cache 'codeRangeImpreciseNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
        VarHandle.storeStoreFence();
        this.codeRangeImpreciseNode_ = codeRangeImpreciseNode__;
        GetCodeRangeNode codeRangePreciseNode__ = this.insert((GetCodeRangeNode.create()));
        Objects.requireNonNull(codeRangePreciseNode__, "Specialization 'doTString(VirtualFrame, TruffleString, int, int, int, int, int, MaterializeNode, GetCodeRangeImpreciseNode, GetCodeRangeNode, InlinedConditionProfile)' cache 'codeRangePreciseNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
        VarHandle.storeStoreFence();
        this.codeRangePreciseNode_ = codeRangePreciseNode__;
        state_0 = state_0 | 0b1 /* add SpecializationActive[TRegexExecutorEntryNode.doTString(VirtualFrame, TruffleString, int, int, int, int, int, MaterializeNode, GetCodeRangeImpreciseNode, GetCodeRangeNode, InlinedConditionProfile)] */;
        this.state_0_ = state_0;
        return doTString(frameValue, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, materializeNode__, codeRangeImpreciseNode__, codeRangePreciseNode__, INLINED_IS_LATIN1_PROFILE_);
    }

    @Override
    public NodeCost getCost() {
        int state_0 = this.state_0_;
        if ((state_0 & 0b1) == 0) {
            return NodeCost.UNINITIALIZED;
        } else {
            return NodeCost.MONOMORPHIC;
        }
    }

    @NeverDefault
    public static TRegexExecutorEntryNode create(RegexLanguage language, TRegexExecutorBaseNode executor) {
        return new TRegexExecutorEntryNodeGen(language, executor);
    }

    private static CodeRange decodeCodeRange(int state) {
        if (state >= 0) {
            return CODE_RANGE_VALUES[state];
        } else {
            return null;
        }
    }

    private static int encodeCodeRange(CodeRange e) {
        if (e != null) {
            return e.ordinal();
        } else {
            return -1;
        }
    }

    /**
     * Debug Info: <pre>
     *   Specialization {@link TRegexExecutorEntryInnerNode#doTString}
     *     Activation probability: 1.00000
     *     With/without class size: 32/8 bytes
     * </pre>
     */
    @GeneratedBy(TRegexExecutorEntryInnerNode.class)
    @SuppressWarnings("javadoc")
    public static final class TRegexExecutorEntryInnerNodeGen extends TRegexExecutorEntryInnerNode {

        static final ReferenceField<TStringData> T_STRING_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "tString_cache", TStringData.class);

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link TRegexExecutorEntryInnerNode#doTString}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        @UnsafeAccessedField @Child private TStringData tString_cache;

        private TRegexExecutorEntryInnerNodeGen(RegexLanguage language, TRegexExecutorBaseNode executor) {
            super(language, executor);
        }

        @ExplodeLoop
        @Override
        public Object execute(VirtualFrame frameValue, TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, CodeRange arg6Value) {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(VirtualFrame, TruffleString, int, int, int, int, int, CodeRange, CodeRange, DirectCallNode)] */) {
                TStringData s0_ = this.tString_cache;
                while (s0_ != null) {
                    if ((arg6Value == decodeCodeRange((s0_.tString_state_0_ >>> 0 /* get-int EncodedEnum[cache=TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(..., CodeRange cachedCodeRange, ...)] */) - 2))) {
                        return doTString(frameValue, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, decodeCodeRange((s0_.tString_state_0_ >>> 0 /* get-int EncodedEnum[cache=TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(..., CodeRange cachedCodeRange, ...)] */) - 2), s0_.callNode_);
                    }
                    s0_ = s0_.next_;
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(frameValue, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value);
        }

        private Object executeAndSpecialize(VirtualFrame frameValue, TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, int arg5Value, CodeRange arg6Value) {
            int state_0 = this.state_0_;
            while (true) {
                int count0_ = 0;
                TStringData s0_ = T_STRING_CACHE_UPDATER.getVolatile(this);
                TStringData s0_original = s0_;
                while (s0_ != null) {
                    if ((arg6Value == decodeCodeRange((s0_.tString_state_0_ >>> 0 /* get-int EncodedEnum[cache=TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(..., CodeRange cachedCodeRange, ...)] */) - 2))) {
                        break;
                    }
                    count0_++;
                    s0_ = s0_.next_;
                }
                if (s0_ == null) {
                    // assert (arg6Value == decodeCodeRange((s0_.tString_state_0_ >>> 0 /* get-int EncodedEnum[cache=TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(..., CodeRange cachedCodeRange, ...)] */) - 2));
                    if (count0_ < (5)) {
                        s0_ = this.insert(new TStringData(s0_original));
                        s0_.tString_state_0_ = (s0_.tString_state_0_ | ((encodeCodeRange((arg6Value)) + 2) << 0) /* set-int EncodedEnum[cache=TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(..., CodeRange cachedCodeRange, ...)] */);
                        s0_.callNode_ = s0_.insert((createCallTarget(decodeCodeRange((s0_.tString_state_0_ >>> 0 /* get-int EncodedEnum[cache=TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(..., CodeRange cachedCodeRange, ...)] */) - 2))));
                        if (!T_STRING_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                            continue;
                        }
                        state_0 = state_0 | 0b1 /* add SpecializationActive[TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(VirtualFrame, TruffleString, int, int, int, int, int, CodeRange, CodeRange, DirectCallNode)] */;
                        this.state_0_ = state_0;
                    }
                }
                if (s0_ != null) {
                    return doTString(frameValue, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value, decodeCodeRange((s0_.tString_state_0_ >>> 0 /* get-int EncodedEnum[cache=TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(..., CodeRange cachedCodeRange, ...)] */) - 2), s0_.callNode_);
                }
                break;
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, arg6Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                    TStringData s0_ = this.tString_cache;
                    if ((s0_ == null || s0_.next_ == null)) {
                        return NodeCost.MONOMORPHIC;
                    }
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static TRegexExecutorEntryInnerNode create(RegexLanguage language, TRegexExecutorBaseNode executor) {
            return new TRegexExecutorEntryInnerNodeGen(language, executor);
        }

        @GeneratedBy(TRegexExecutorEntryInnerNode.class)
        @DenyReplace
        private static final class TStringData extends Node implements SpecializationDataNode {

            @Child TStringData next_;
            /**
             * State Info: <pre>
             *   0-2: EncodedEnum[cache=TRegexExecutorEntryNode.TRegexExecutorEntryInnerNode.doTString(..., CodeRange cachedCodeRange, ...)]
             * </pre>
             */
            @CompilationFinal private int tString_state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link TRegexExecutorEntryInnerNode#doTString}
             *   Parameter: {@link DirectCallNode} callNode</pre>
             */
            @Child DirectCallNode callNode_;

            TStringData(TStringData next_) {
                this.next_ = next_;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

        }
    }
}
