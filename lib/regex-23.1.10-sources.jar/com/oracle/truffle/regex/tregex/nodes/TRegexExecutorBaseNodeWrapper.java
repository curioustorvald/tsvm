// CheckStyle: start generated
package com.oracle.truffle.regex.tregex.nodes;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.instrumentation.ProbeNode;
import com.oracle.truffle.api.instrumentation.InstrumentableNode.WrapperNode;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.strings.TruffleString;
import com.oracle.truffle.api.strings.TruffleString.CodeRange;
import com.oracle.truffle.regex.RegexSource;

@GeneratedBy(TRegexExecutorBaseNode.class)
final class TRegexExecutorBaseNodeWrapper extends TRegexExecutorBaseNode implements WrapperNode {

    @Child private TRegexExecutorBaseNode delegateNode;
    @Child private ProbeNode probeNode;

    TRegexExecutorBaseNodeWrapper(TRegexExecutorBaseNode delegateNode, ProbeNode probeNode) {
        this.delegateNode = delegateNode;
        this.probeNode = probeNode;
    }

    @Override
    public TRegexExecutorBaseNode getDelegateNode() {
        return delegateNode;
    }

    @Override
    public ProbeNode getProbeNode() {
        return probeNode;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.NONE;
    }

    @Override
    public Object execute(VirtualFrame frame, TRegexExecutorLocals locals, CodeRange codeRange) {
        Object returnValue;
        for (;;) {
            boolean wasOnReturnExecuted = false;
            try {
                probeNode.onEnter(frame);
                returnValue = delegateNode.execute(frame, locals, codeRange);
                wasOnReturnExecuted = true;
                probeNode.onReturnValue(frame, returnValue);
                break;
            } catch (Throwable t) {
                Object result = probeNode.onReturnExceptionalOrUnwind(frame, t, wasOnReturnExecuted);
                if (result == ProbeNode.UNWIND_ACTION_REENTER) {
                    continue;
                } else if (result != null) {
                    returnValue = result;
                    break;
                }
                throw t;
            }
        }
        return returnValue;
    }

    @Override
    public TRegexExecutorNode shallowCopy() {
        return this.delegateNode.shallowCopy();
    }

    @Override
    public RegexSource getSource() {
        return this.delegateNode.getSource();
    }

    @Override
    public int getNumberOfStates() {
        return this.delegateNode.getNumberOfStates();
    }

    @Override
    public int getNumberOfTransitions() {
        return this.delegateNode.getNumberOfTransitions();
    }

    @Override
    public String getName() {
        return this.delegateNode.getName();
    }

    @Override
    public boolean isForward() {
        return this.delegateNode.isForward();
    }

    @Override
    public boolean isSimpleCG() {
        return this.delegateNode.isSimpleCG();
    }

    @Override
    public boolean writesCaptureGroups() {
        return this.delegateNode.writesCaptureGroups();
    }

    @Override
    public TRegexExecutorLocals createLocals(TruffleString input, int fromIndex, int maxIndex, int regionFrom, int regionTo, int index) {
        return this.delegateNode.createLocals(input, fromIndex, maxIndex, regionFrom, regionTo, index);
    }

}
