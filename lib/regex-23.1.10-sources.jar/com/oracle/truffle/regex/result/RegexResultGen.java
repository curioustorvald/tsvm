// CheckStyle: start generated
package com.oracle.truffle.regex.result;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.DSLSupport;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.interop.ArityException;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.interop.UnknownIdentifierException;
import com.oracle.truffle.api.interop.UnsupportedMessageException;
import com.oracle.truffle.api.interop.UnsupportedTypeException;
import com.oracle.truffle.api.library.LibraryExport;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.regex.AbstractConstantKeysObjectGen;
import com.oracle.truffle.regex.result.RegexResult.InvokeCacheNode;
import com.oracle.truffle.regex.result.RegexResult.IsMemberInvocable;
import com.oracle.truffle.regex.result.RegexResult.IsMemberReadable;
import com.oracle.truffle.regex.result.RegexResult.ReadMember;
import com.oracle.truffle.regex.result.RegexResult.RegexResultGetLastGroupNode;
import com.oracle.truffle.regex.result.RegexResultFactory.InvokeCacheNodeGen;
import com.oracle.truffle.regex.result.RegexResultFactory.RegexResultGetLastGroupNodeGen;
import com.oracle.truffle.regex.runtime.nodes.ToIntNode;
import com.oracle.truffle.regex.runtime.nodes.ToIntNodeGen;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.Objects;

@GeneratedBy(RegexResult.class)
@SuppressWarnings("javadoc")
final class RegexResultGen {

    static  {
        LibraryExport.register(RegexResult.class, new InteropLibraryExports());
    }

    private RegexResultGen() {
    }

    @GeneratedBy(RegexResult.class)
    private static final class InteropLibraryExports extends LibraryExport<InteropLibrary> {

        private InteropLibraryExports() {
            super(InteropLibrary.class, RegexResult.class, false, false, 0);
        }

        @Override
        protected InteropLibrary createUncached(Object receiver) {
            assert receiver instanceof RegexResult;
            InteropLibrary uncached = new Uncached(receiver);
            return uncached;
        }

        @Override
        protected InteropLibrary createCached(Object receiver) {
            assert receiver instanceof RegexResult;
            return new Cached(receiver);
        }

        @GeneratedBy(RegexResult.class)
        private static final class Cached extends AbstractConstantKeysObjectGen.InteropLibraryExports.Cached {

            static final ReferenceField<IsMemberReadableCacheIdentityData> IS_MEMBER_READABLE_CACHE_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "isMemberReadable_cacheIdentity_cache", IsMemberReadableCacheIdentityData.class);
            static final ReferenceField<IsMemberReadableCacheEqualsData> IS_MEMBER_READABLE_CACHE_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "isMemberReadable_cacheEquals_cache", IsMemberReadableCacheEqualsData.class);
            static final ReferenceField<ReadMemberIsMatchIdentityData> READ_MEMBER_IS_MATCH_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_isMatchIdentity_cache", ReadMemberIsMatchIdentityData.class);
            static final ReferenceField<ReadMemberIsMatchEqualsData> READ_MEMBER_IS_MATCH_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_isMatchEquals_cache", ReadMemberIsMatchEqualsData.class);
            static final ReferenceField<ReadMemberGetStartIdentityData> READ_MEMBER_GET_START_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_getStartIdentity_cache", ReadMemberGetStartIdentityData.class);
            static final ReferenceField<ReadMemberGetStartEqualsData> READ_MEMBER_GET_START_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_getStartEquals_cache", ReadMemberGetStartEqualsData.class);
            static final ReferenceField<ReadMemberGetEndIdentityData> READ_MEMBER_GET_END_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_getEndIdentity_cache", ReadMemberGetEndIdentityData.class);
            static final ReferenceField<ReadMemberGetEndEqualsData> READ_MEMBER_GET_END_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_getEndEquals_cache", ReadMemberGetEndEqualsData.class);
            static final ReferenceField<ReadMemberLastGroupIdentityData> READ_MEMBER_LAST_GROUP_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_lastGroupIdentity_cache", ReadMemberLastGroupIdentityData.class);
            static final ReferenceField<ReadMemberLastGroupEqualsData> READ_MEMBER_LAST_GROUP_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "readMember_lastGroupEquals_cache", ReadMemberLastGroupEqualsData.class);
            static final ReferenceField<IsMemberInvocableCacheIdentityData> IS_MEMBER_INVOCABLE_CACHE_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "isMemberInvocable_cacheIdentity_cache", IsMemberInvocableCacheIdentityData.class);
            static final ReferenceField<IsMemberInvocableCacheEqualsData> IS_MEMBER_INVOCABLE_CACHE_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "isMemberInvocable_cacheEquals_cache", IsMemberInvocableCacheEqualsData.class);

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link IsMemberReadable#cacheIdentity}
             *   1: SpecializationActive {@link IsMemberReadable#cacheEquals}
             *   2: SpecializationActive {@link IsMemberReadable#isReadable}
             *   3: SpecializationActive {@link ReadMember#isMatchIdentity}
             *   4: SpecializationActive {@link ReadMember#isMatchEquals}
             *   5: SpecializationActive {@link ReadMember#readGeneric}
             *   6: SpecializationActive {@link ReadMember#getStartIdentity}
             *   7: SpecializationActive {@link ReadMember#getStartEquals}
             *   8: SpecializationActive {@link ReadMember#getEndIdentity}
             *   9: SpecializationActive {@link ReadMember#getEndEquals}
             *   10: SpecializationActive {@link ReadMember#lastGroupIdentity}
             *   11: SpecializationActive {@link ReadMember#lastGroupEquals}
             *   12: SpecializationActive {@link IsMemberInvocable#cacheIdentity}
             *   13: SpecializationActive {@link IsMemberInvocable#cacheEquals}
             *   14: SpecializationActive {@link IsMemberInvocable#isInvocable}
             *   15: SpecializationActive {@link RegexResult#invokeMember(RegexResult, String, Object[], ToIntNode, InvokeCacheNode)}
             * </pre>
             */
            @CompilationFinal private int state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ReadMember#lastGroupIdentity}
             *   Parameter: {@link RegexResultGetLastGroupNode} getLastGroupNode</pre>
             */
            @Child private RegexResultGetLastGroupNode getLastGroupNode;
            @UnsafeAccessedField @CompilationFinal private IsMemberReadableCacheIdentityData isMemberReadable_cacheIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private IsMemberReadableCacheEqualsData isMemberReadable_cacheEquals_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberIsMatchIdentityData readMember_isMatchIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberIsMatchEqualsData readMember_isMatchEquals_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberGetStartIdentityData readMember_getStartIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberGetStartEqualsData readMember_getStartEquals_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberGetEndIdentityData readMember_getEndIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberGetEndEqualsData readMember_getEndEquals_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberLastGroupIdentityData readMember_lastGroupIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private ReadMemberLastGroupEqualsData readMember_lastGroupEquals_cache;
            @UnsafeAccessedField @CompilationFinal private IsMemberInvocableCacheIdentityData isMemberInvocable_cacheIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private IsMemberInvocableCacheEqualsData isMemberInvocable_cacheEquals_cache;
            /**
             * Source Info: <pre>
             *   Specialization: {@link RegexResult#invokeMember(RegexResult, String, Object[], ToIntNode, InvokeCacheNode)}
             *   Parameter: {@link ToIntNode} toIntNode</pre>
             */
            @Child private ToIntNode invokeMemberNode__invokeMember_toIntNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link RegexResult#invokeMember(RegexResult, String, Object[], ToIntNode, InvokeCacheNode)}
             *   Parameter: {@link InvokeCacheNode} invokeCache</pre>
             */
            @Child private InvokeCacheNode invokeMemberNode__invokeMember_invokeCache_;

            protected Cached(Object receiver) {
                super(receiver);
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link IsMemberReadable#cacheIdentity}
             *     Activation probability: 0.12083
             *     With/without class size: 6/5 bytes
             *   Specialization {@link IsMemberReadable#cacheEquals}
             *     Activation probability: 0.08333
             *     With/without class size: 5/5 bytes
             *   Specialization {@link IsMemberReadable#isReadable}
             *     Activation probability: 0.04583
             *     With/without class size: 4/0 bytes
             * </pre>
             */
            @ExplodeLoop
            @Override
            public boolean isMemberReadable(Object arg0Value_, String arg1Value) {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexResult arg0Value = ((RegexResult) arg0Value_);
                int state_0 = this.state_0_;
                if ((state_0 & 0b111) != 0 /* is SpecializationActive[RegexResult.IsMemberReadable.cacheIdentity(RegexResult, String, String, boolean)] || SpecializationActive[RegexResult.IsMemberReadable.cacheEquals(RegexResult, String, String, boolean)] || SpecializationActive[RegexResult.IsMemberReadable.isReadable(RegexResult, String)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexResult.IsMemberReadable.cacheIdentity(RegexResult, String, String, boolean)] */) {
                        IsMemberReadableCacheIdentityData s0_ = this.isMemberReadable_cacheIdentity_cache;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s0_.result_));
                                return IsMemberReadable.cacheIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.result_);
                            }
                            s0_ = s0_.next_;
                        }
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[RegexResult.IsMemberReadable.cacheEquals(RegexResult, String, String, boolean)] */) {
                        IsMemberReadableCacheEqualsData s1_ = this.isMemberReadable_cacheEquals_cache;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s1_.result_));
                                return IsMemberReadable.cacheEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.result_);
                            }
                            s1_ = s1_.next_;
                        }
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[RegexResult.IsMemberReadable.isReadable(RegexResult, String)] */) {
                        return IsMemberReadable.isReadable(arg0Value, arg1Value);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return isMemberReadableAndSpecialize(arg0Value, arg1Value);
            }

            private boolean isMemberReadableAndSpecialize(RegexResult arg0Value, String arg1Value) {
                int state_0 = this.state_0_;
                if (((state_0 & 0b110)) == 0 /* is-not SpecializationActive[RegexResult.IsMemberReadable.cacheEquals(RegexResult, String, String, boolean)] && SpecializationActive[RegexResult.IsMemberReadable.isReadable(RegexResult, String)] */) {
                    while (true) {
                        int count0_ = 0;
                        IsMemberReadableCacheIdentityData s0_ = IS_MEMBER_READABLE_CACHE_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        IsMemberReadableCacheIdentityData s0_original = s0_;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s0_.result_));
                                break;
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            {
                                String cachedSymbol__ = (arg1Value);
                                boolean result__ = (IsMemberReadable.isReadable(arg0Value, cachedSymbol__));
                                // assert (arg1Value == s0_.cachedSymbol_);
                                if ((result__) && count0_ < (4)) {
                                    s0_ = new IsMemberReadableCacheIdentityData(s0_original);
                                    s0_.cachedSymbol_ = cachedSymbol__;
                                    s0_.result_ = result__;
                                    if (!IS_MEMBER_READABLE_CACHE_IDENTITY_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                        continue;
                                    }
                                    state_0 = state_0 | 0b1 /* add SpecializationActive[RegexResult.IsMemberReadable.cacheIdentity(RegexResult, String, String, boolean)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s0_ != null) {
                            return IsMemberReadable.cacheIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.result_);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100)) == 0 /* is-not SpecializationActive[RegexResult.IsMemberReadable.isReadable(RegexResult, String)] */) {
                    while (true) {
                        int count1_ = 0;
                        IsMemberReadableCacheEqualsData s1_ = IS_MEMBER_READABLE_CACHE_EQUALS_CACHE_UPDATER.getVolatile(this);
                        IsMemberReadableCacheEqualsData s1_original = s1_;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s1_.result_));
                                break;
                            }
                            count1_++;
                            s1_ = s1_.next_;
                        }
                        if (s1_ == null) {
                            {
                                String cachedSymbol__1 = (arg1Value);
                                boolean result__1 = (IsMemberReadable.isReadable(arg0Value, cachedSymbol__1));
                                // assert (arg1Value.equals(s1_.cachedSymbol_));
                                if ((result__1) && count1_ < (4)) {
                                    s1_ = new IsMemberReadableCacheEqualsData(s1_original);
                                    s1_.cachedSymbol_ = cachedSymbol__1;
                                    s1_.result_ = result__1;
                                    if (!IS_MEMBER_READABLE_CACHE_EQUALS_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                        continue;
                                    }
                                    this.isMemberReadable_cacheIdentity_cache = null;
                                    state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[RegexResult.IsMemberReadable.cacheIdentity(RegexResult, String, String, boolean)] */;
                                    state_0 = state_0 | 0b10 /* add SpecializationActive[RegexResult.IsMemberReadable.cacheEquals(RegexResult, String, String, boolean)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s1_ != null) {
                            return IsMemberReadable.cacheEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.result_);
                        }
                        break;
                    }
                }
                this.isMemberReadable_cacheIdentity_cache = null;
                this.isMemberReadable_cacheEquals_cache = null;
                state_0 = state_0 & 0xfffffffc /* remove SpecializationActive[RegexResult.IsMemberReadable.cacheIdentity(RegexResult, String, String, boolean)], SpecializationActive[RegexResult.IsMemberReadable.cacheEquals(RegexResult, String, String, boolean)] */;
                state_0 = state_0 | 0b100 /* add SpecializationActive[RegexResult.IsMemberReadable.isReadable(RegexResult, String)] */;
                this.state_0_ = state_0;
                return IsMemberReadable.isReadable(arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                int state_0 = this.state_0_;
                if ((state_0 & 0b111) == 0) {
                    return NodeCost.UNINITIALIZED;
                } else {
                    if (((state_0 & 0b111) & ((state_0 & 0b111) - 1)) == 0 /* is-single  */) {
                        IsMemberReadableCacheIdentityData s0_ = this.isMemberReadable_cacheIdentity_cache;
                        IsMemberReadableCacheEqualsData s1_ = this.isMemberReadable_cacheEquals_cache;
                        if ((s0_ == null || s0_.next_ == null) && (s1_ == null || s1_.next_ == null)) {
                            return NodeCost.MONOMORPHIC;
                        }
                    }
                }
                return NodeCost.POLYMORPHIC;
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link ReadMember#isMatchIdentity}
             *     Activation probability: 0.04778
             *     With/without class size: 4/4 bytes
             *   Specialization {@link ReadMember#isMatchEquals}
             *     Activation probability: 0.04278
             *     With/without class size: 4/4 bytes
             *   Specialization {@link ReadMember#getStartIdentity}
             *     Activation probability: 0.03778
             *     With/without class size: 4/4 bytes
             *   Specialization {@link ReadMember#getStartEquals}
             *     Activation probability: 0.03278
             *     With/without class size: 4/4 bytes
             *   Specialization {@link ReadMember#getEndIdentity}
             *     Activation probability: 0.02778
             *     With/without class size: 4/4 bytes
             *   Specialization {@link ReadMember#getEndEquals}
             *     Activation probability: 0.02278
             *     With/without class size: 4/4 bytes
             *   Specialization {@link ReadMember#lastGroupIdentity}
             *     Activation probability: 0.01778
             *     With/without class size: 4/4 bytes
             *   Specialization {@link ReadMember#lastGroupEquals}
             *     Activation probability: 0.01278
             *     With/without class size: 4/4 bytes
             *   Specialization {@link ReadMember#readGeneric}
             *     Activation probability: 0.00778
             *     With/without class size: 4/0 bytes
             * </pre>
             */
            @ExplodeLoop
            @Override
            public Object readMember(Object arg0Value_, String arg1Value) throws UnsupportedMessageException, UnknownIdentifierException {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexResult arg0Value = ((RegexResult) arg0Value_);
                int state_0 = this.state_0_;
                if ((state_0 & 0b111111111000) != 0 /* is SpecializationActive[RegexResult.ReadMember.isMatchIdentity(RegexResult, String, String)] || SpecializationActive[RegexResult.ReadMember.isMatchEquals(RegexResult, String, String)] || SpecializationActive[RegexResult.ReadMember.getStartIdentity(RegexResult, String, String)] || SpecializationActive[RegexResult.ReadMember.getStartEquals(RegexResult, String, String)] || SpecializationActive[RegexResult.ReadMember.getEndIdentity(RegexResult, String, String)] || SpecializationActive[RegexResult.ReadMember.getEndEquals(RegexResult, String, String)] || SpecializationActive[RegexResult.ReadMember.lastGroupIdentity(RegexResult, String, String, RegexResultGetLastGroupNode)] || SpecializationActive[RegexResult.ReadMember.lastGroupEquals(RegexResult, String, String, RegexResultGetLastGroupNode)] || SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */) {
                    if ((state_0 & 0b1000) != 0 /* is SpecializationActive[RegexResult.ReadMember.isMatchIdentity(RegexResult, String, String)] */) {
                        ReadMemberIsMatchIdentityData s0_ = this.readMember_isMatchIdentity_cache;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s0_.cachedSymbol_.equals(RegexResult.PROP_IS_MATCH)));
                                return ReadMember.isMatchIdentity(arg0Value, arg1Value, s0_.cachedSymbol_);
                            }
                            s0_ = s0_.next_;
                        }
                    }
                    if ((state_0 & 0b10000) != 0 /* is SpecializationActive[RegexResult.ReadMember.isMatchEquals(RegexResult, String, String)] */) {
                        ReadMemberIsMatchEqualsData s1_ = this.readMember_isMatchEquals_cache;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s1_.cachedSymbol_.equals(RegexResult.PROP_IS_MATCH)));
                                return ReadMember.isMatchEquals(arg0Value, arg1Value, s1_.cachedSymbol_);
                            }
                            s1_ = s1_.next_;
                        }
                    }
                    if ((state_0 & 0b1000000) != 0 /* is SpecializationActive[RegexResult.ReadMember.getStartIdentity(RegexResult, String, String)] */) {
                        ReadMemberGetStartIdentityData s2_ = this.readMember_getStartIdentity_cache;
                        while (s2_ != null) {
                            if ((arg1Value == s2_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s2_.cachedSymbol_.equals(RegexResult.PROP_GET_START)));
                                return ReadMember.getStartIdentity(arg0Value, arg1Value, s2_.cachedSymbol_);
                            }
                            s2_ = s2_.next_;
                        }
                    }
                    if ((state_0 & 0b10000000) != 0 /* is SpecializationActive[RegexResult.ReadMember.getStartEquals(RegexResult, String, String)] */) {
                        ReadMemberGetStartEqualsData s3_ = this.readMember_getStartEquals_cache;
                        while (s3_ != null) {
                            if ((arg1Value.equals(s3_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s3_.cachedSymbol_.equals(RegexResult.PROP_GET_START)));
                                return ReadMember.getStartEquals(arg0Value, arg1Value, s3_.cachedSymbol_);
                            }
                            s3_ = s3_.next_;
                        }
                    }
                    if ((state_0 & 0b100000000) != 0 /* is SpecializationActive[RegexResult.ReadMember.getEndIdentity(RegexResult, String, String)] */) {
                        ReadMemberGetEndIdentityData s4_ = this.readMember_getEndIdentity_cache;
                        while (s4_ != null) {
                            if ((arg1Value == s4_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s4_.cachedSymbol_.equals(RegexResult.PROP_GET_END)));
                                return ReadMember.getEndIdentity(arg0Value, arg1Value, s4_.cachedSymbol_);
                            }
                            s4_ = s4_.next_;
                        }
                    }
                    if ((state_0 & 0b1000000000) != 0 /* is SpecializationActive[RegexResult.ReadMember.getEndEquals(RegexResult, String, String)] */) {
                        ReadMemberGetEndEqualsData s5_ = this.readMember_getEndEquals_cache;
                        while (s5_ != null) {
                            if ((arg1Value.equals(s5_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s5_.cachedSymbol_.equals(RegexResult.PROP_GET_END)));
                                return ReadMember.getEndEquals(arg0Value, arg1Value, s5_.cachedSymbol_);
                            }
                            s5_ = s5_.next_;
                        }
                    }
                    if ((state_0 & 0b10000000000) != 0 /* is SpecializationActive[RegexResult.ReadMember.lastGroupIdentity(RegexResult, String, String, RegexResultGetLastGroupNode)] */) {
                        ReadMemberLastGroupIdentityData s6_ = this.readMember_lastGroupIdentity_cache;
                        while (s6_ != null) {
                            {
                                RegexResultGetLastGroupNode getLastGroupNode_ = this.getLastGroupNode;
                                if (getLastGroupNode_ != null) {
                                    if ((arg1Value == s6_.cachedSymbol_)) {
                                        assert DSLSupport.assertIdempotence((s6_.cachedSymbol_.equals(RegexResult.PROP_LAST_GROUP)));
                                        return ReadMember.lastGroupIdentity(arg0Value, arg1Value, s6_.cachedSymbol_, getLastGroupNode_);
                                    }
                                }
                            }
                            s6_ = s6_.next_;
                        }
                    }
                    if ((state_0 & 0b100000000000) != 0 /* is SpecializationActive[RegexResult.ReadMember.lastGroupEquals(RegexResult, String, String, RegexResultGetLastGroupNode)] */) {
                        ReadMemberLastGroupEqualsData s7_ = this.readMember_lastGroupEquals_cache;
                        while (s7_ != null) {
                            {
                                RegexResultGetLastGroupNode getLastGroupNode_1 = this.getLastGroupNode;
                                if (getLastGroupNode_1 != null) {
                                    if ((arg1Value.equals(s7_.cachedSymbol_))) {
                                        assert DSLSupport.assertIdempotence((s7_.cachedSymbol_.equals(RegexResult.PROP_LAST_GROUP)));
                                        return ReadMember.lastGroupEquals(arg0Value, arg1Value, s7_.cachedSymbol_, getLastGroupNode_1);
                                    }
                                }
                            }
                            s7_ = s7_.next_;
                        }
                    }
                    if ((state_0 & 0b100000) != 0 /* is SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */) {
                        {
                            RegexResultGetLastGroupNode getLastGroupNode_2 = this.getLastGroupNode;
                            if (getLastGroupNode_2 != null) {
                                return ReadMember.readGeneric(arg0Value, arg1Value, getLastGroupNode_2);
                            }
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return readMemberAndSpecialize(arg0Value, arg1Value);
            }

            private Object readMemberAndSpecialize(RegexResult arg0Value, String arg1Value) throws UnknownIdentifierException {
                int state_0 = this.state_0_;
                int oldState_0 = (state_0 & 0b111111111000);
                try {
                    if (((state_0 & 0b110000)) == 0 /* is-not SpecializationActive[RegexResult.ReadMember.isMatchEquals(RegexResult, String, String)] && SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */) {
                        while (true) {
                            int count0_ = 0;
                            ReadMemberIsMatchIdentityData s0_ = READ_MEMBER_IS_MATCH_IDENTITY_CACHE_UPDATER.getVolatile(this);
                            ReadMemberIsMatchIdentityData s0_original = s0_;
                            while (s0_ != null) {
                                if ((arg1Value == s0_.cachedSymbol_)) {
                                    assert DSLSupport.assertIdempotence((s0_.cachedSymbol_.equals(RegexResult.PROP_IS_MATCH)));
                                    break;
                                }
                                count0_++;
                                s0_ = s0_.next_;
                            }
                            if (s0_ == null) {
                                {
                                    String cachedSymbol__ = (arg1Value);
                                    // assert (arg1Value == s0_.cachedSymbol_);
                                    if ((cachedSymbol__.equals(RegexResult.PROP_IS_MATCH)) && count0_ < (2)) {
                                        s0_ = new ReadMemberIsMatchIdentityData(s0_original);
                                        s0_.cachedSymbol_ = cachedSymbol__;
                                        if (!READ_MEMBER_IS_MATCH_IDENTITY_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                            continue;
                                        }
                                        state_0 = state_0 | 0b1000 /* add SpecializationActive[RegexResult.ReadMember.isMatchIdentity(RegexResult, String, String)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                            if (s0_ != null) {
                                return ReadMember.isMatchIdentity(arg0Value, arg1Value, s0_.cachedSymbol_);
                            }
                            break;
                        }
                    }
                    if (((state_0 & 0b100000)) == 0 /* is-not SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */) {
                        while (true) {
                            int count1_ = 0;
                            ReadMemberIsMatchEqualsData s1_ = READ_MEMBER_IS_MATCH_EQUALS_CACHE_UPDATER.getVolatile(this);
                            ReadMemberIsMatchEqualsData s1_original = s1_;
                            while (s1_ != null) {
                                if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                    assert DSLSupport.assertIdempotence((s1_.cachedSymbol_.equals(RegexResult.PROP_IS_MATCH)));
                                    break;
                                }
                                count1_++;
                                s1_ = s1_.next_;
                            }
                            if (s1_ == null) {
                                {
                                    String cachedSymbol__1 = (arg1Value);
                                    // assert (arg1Value.equals(s1_.cachedSymbol_));
                                    if ((cachedSymbol__1.equals(RegexResult.PROP_IS_MATCH)) && count1_ < (2)) {
                                        s1_ = new ReadMemberIsMatchEqualsData(s1_original);
                                        s1_.cachedSymbol_ = cachedSymbol__1;
                                        if (!READ_MEMBER_IS_MATCH_EQUALS_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                            continue;
                                        }
                                        this.readMember_isMatchIdentity_cache = null;
                                        state_0 = state_0 & 0xfffffff7 /* remove SpecializationActive[RegexResult.ReadMember.isMatchIdentity(RegexResult, String, String)] */;
                                        state_0 = state_0 | 0b10000 /* add SpecializationActive[RegexResult.ReadMember.isMatchEquals(RegexResult, String, String)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                            if (s1_ != null) {
                                return ReadMember.isMatchEquals(arg0Value, arg1Value, s1_.cachedSymbol_);
                            }
                            break;
                        }
                    }
                    if (((state_0 & 0b10100000)) == 0 /* is-not SpecializationActive[RegexResult.ReadMember.getStartEquals(RegexResult, String, String)] && SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */) {
                        while (true) {
                            int count2_ = 0;
                            ReadMemberGetStartIdentityData s2_ = READ_MEMBER_GET_START_IDENTITY_CACHE_UPDATER.getVolatile(this);
                            ReadMemberGetStartIdentityData s2_original = s2_;
                            while (s2_ != null) {
                                if ((arg1Value == s2_.cachedSymbol_)) {
                                    assert DSLSupport.assertIdempotence((s2_.cachedSymbol_.equals(RegexResult.PROP_GET_START)));
                                    break;
                                }
                                count2_++;
                                s2_ = s2_.next_;
                            }
                            if (s2_ == null) {
                                {
                                    String cachedSymbol__2 = (arg1Value);
                                    // assert (arg1Value == s2_.cachedSymbol_);
                                    if ((cachedSymbol__2.equals(RegexResult.PROP_GET_START)) && count2_ < (2)) {
                                        s2_ = new ReadMemberGetStartIdentityData(s2_original);
                                        s2_.cachedSymbol_ = cachedSymbol__2;
                                        if (!READ_MEMBER_GET_START_IDENTITY_CACHE_UPDATER.compareAndSet(this, s2_original, s2_)) {
                                            continue;
                                        }
                                        state_0 = state_0 | 0b1000000 /* add SpecializationActive[RegexResult.ReadMember.getStartIdentity(RegexResult, String, String)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                            if (s2_ != null) {
                                return ReadMember.getStartIdentity(arg0Value, arg1Value, s2_.cachedSymbol_);
                            }
                            break;
                        }
                    }
                    if (((state_0 & 0b100000)) == 0 /* is-not SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */) {
                        while (true) {
                            int count3_ = 0;
                            ReadMemberGetStartEqualsData s3_ = READ_MEMBER_GET_START_EQUALS_CACHE_UPDATER.getVolatile(this);
                            ReadMemberGetStartEqualsData s3_original = s3_;
                            while (s3_ != null) {
                                if ((arg1Value.equals(s3_.cachedSymbol_))) {
                                    assert DSLSupport.assertIdempotence((s3_.cachedSymbol_.equals(RegexResult.PROP_GET_START)));
                                    break;
                                }
                                count3_++;
                                s3_ = s3_.next_;
                            }
                            if (s3_ == null) {
                                {
                                    String cachedSymbol__3 = (arg1Value);
                                    // assert (arg1Value.equals(s3_.cachedSymbol_));
                                    if ((cachedSymbol__3.equals(RegexResult.PROP_GET_START)) && count3_ < (2)) {
                                        s3_ = new ReadMemberGetStartEqualsData(s3_original);
                                        s3_.cachedSymbol_ = cachedSymbol__3;
                                        if (!READ_MEMBER_GET_START_EQUALS_CACHE_UPDATER.compareAndSet(this, s3_original, s3_)) {
                                            continue;
                                        }
                                        this.readMember_getStartIdentity_cache = null;
                                        state_0 = state_0 & 0xffffffbf /* remove SpecializationActive[RegexResult.ReadMember.getStartIdentity(RegexResult, String, String)] */;
                                        state_0 = state_0 | 0b10000000 /* add SpecializationActive[RegexResult.ReadMember.getStartEquals(RegexResult, String, String)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                            if (s3_ != null) {
                                return ReadMember.getStartEquals(arg0Value, arg1Value, s3_.cachedSymbol_);
                            }
                            break;
                        }
                    }
                    if (((state_0 & 0b1000100000)) == 0 /* is-not SpecializationActive[RegexResult.ReadMember.getEndEquals(RegexResult, String, String)] && SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */) {
                        while (true) {
                            int count4_ = 0;
                            ReadMemberGetEndIdentityData s4_ = READ_MEMBER_GET_END_IDENTITY_CACHE_UPDATER.getVolatile(this);
                            ReadMemberGetEndIdentityData s4_original = s4_;
                            while (s4_ != null) {
                                if ((arg1Value == s4_.cachedSymbol_)) {
                                    assert DSLSupport.assertIdempotence((s4_.cachedSymbol_.equals(RegexResult.PROP_GET_END)));
                                    break;
                                }
                                count4_++;
                                s4_ = s4_.next_;
                            }
                            if (s4_ == null) {
                                {
                                    String cachedSymbol__4 = (arg1Value);
                                    // assert (arg1Value == s4_.cachedSymbol_);
                                    if ((cachedSymbol__4.equals(RegexResult.PROP_GET_END)) && count4_ < (2)) {
                                        s4_ = new ReadMemberGetEndIdentityData(s4_original);
                                        s4_.cachedSymbol_ = cachedSymbol__4;
                                        if (!READ_MEMBER_GET_END_IDENTITY_CACHE_UPDATER.compareAndSet(this, s4_original, s4_)) {
                                            continue;
                                        }
                                        state_0 = state_0 | 0b100000000 /* add SpecializationActive[RegexResult.ReadMember.getEndIdentity(RegexResult, String, String)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                            if (s4_ != null) {
                                return ReadMember.getEndIdentity(arg0Value, arg1Value, s4_.cachedSymbol_);
                            }
                            break;
                        }
                    }
                    if (((state_0 & 0b100000)) == 0 /* is-not SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */) {
                        while (true) {
                            int count5_ = 0;
                            ReadMemberGetEndEqualsData s5_ = READ_MEMBER_GET_END_EQUALS_CACHE_UPDATER.getVolatile(this);
                            ReadMemberGetEndEqualsData s5_original = s5_;
                            while (s5_ != null) {
                                if ((arg1Value.equals(s5_.cachedSymbol_))) {
                                    assert DSLSupport.assertIdempotence((s5_.cachedSymbol_.equals(RegexResult.PROP_GET_END)));
                                    break;
                                }
                                count5_++;
                                s5_ = s5_.next_;
                            }
                            if (s5_ == null) {
                                {
                                    String cachedSymbol__5 = (arg1Value);
                                    // assert (arg1Value.equals(s5_.cachedSymbol_));
                                    if ((cachedSymbol__5.equals(RegexResult.PROP_GET_END)) && count5_ < (2)) {
                                        s5_ = new ReadMemberGetEndEqualsData(s5_original);
                                        s5_.cachedSymbol_ = cachedSymbol__5;
                                        if (!READ_MEMBER_GET_END_EQUALS_CACHE_UPDATER.compareAndSet(this, s5_original, s5_)) {
                                            continue;
                                        }
                                        this.readMember_getEndIdentity_cache = null;
                                        state_0 = state_0 & 0xfffffeff /* remove SpecializationActive[RegexResult.ReadMember.getEndIdentity(RegexResult, String, String)] */;
                                        state_0 = state_0 | 0b1000000000 /* add SpecializationActive[RegexResult.ReadMember.getEndEquals(RegexResult, String, String)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                            if (s5_ != null) {
                                return ReadMember.getEndEquals(arg0Value, arg1Value, s5_.cachedSymbol_);
                            }
                            break;
                        }
                    }
                    if (((state_0 & 0b100000000000)) == 0 /* is-not SpecializationActive[RegexResult.ReadMember.lastGroupEquals(RegexResult, String, String, RegexResultGetLastGroupNode)] */) {
                        while (true) {
                            int count6_ = 0;
                            ReadMemberLastGroupIdentityData s6_ = READ_MEMBER_LAST_GROUP_IDENTITY_CACHE_UPDATER.getVolatile(this);
                            ReadMemberLastGroupIdentityData s6_original = s6_;
                            while (s6_ != null) {
                                {
                                    RegexResultGetLastGroupNode getLastGroupNode_ = this.getLastGroupNode;
                                    if (getLastGroupNode_ != null) {
                                        if ((arg1Value == s6_.cachedSymbol_)) {
                                            assert DSLSupport.assertIdempotence((s6_.cachedSymbol_.equals(RegexResult.PROP_LAST_GROUP)));
                                            break;
                                        }
                                    }
                                }
                                count6_++;
                                s6_ = s6_.next_;
                            }
                            if (s6_ == null) {
                                {
                                    String cachedSymbol__6 = (arg1Value);
                                    // assert (arg1Value == s6_.cachedSymbol_);
                                    if ((cachedSymbol__6.equals(RegexResult.PROP_LAST_GROUP)) && count6_ < (2)) {
                                        s6_ = new ReadMemberLastGroupIdentityData(s6_original);
                                        s6_.cachedSymbol_ = cachedSymbol__6;
                                        RegexResultGetLastGroupNode getLastGroupNode_;
                                        RegexResultGetLastGroupNode getLastGroupNode__shared = this.getLastGroupNode;
                                        if (getLastGroupNode__shared != null) {
                                            getLastGroupNode_ = getLastGroupNode__shared;
                                        } else {
                                            getLastGroupNode_ = this.insert((RegexResultGetLastGroupNodeGen.create()));
                                            if (getLastGroupNode_ == null) {
                                                throw new IllegalStateException("Specialization 'lastGroupIdentity(RegexResult, String, String, RegexResultGetLastGroupNode)' contains a shared cache with name 'getLastGroupNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                            }
                                        }
                                        if (this.getLastGroupNode == null) {
                                            this.getLastGroupNode = getLastGroupNode_;
                                        }
                                        if (!READ_MEMBER_LAST_GROUP_IDENTITY_CACHE_UPDATER.compareAndSet(this, s6_original, s6_)) {
                                            continue;
                                        }
                                        state_0 = state_0 | 0b10000000000 /* add SpecializationActive[RegexResult.ReadMember.lastGroupIdentity(RegexResult, String, String, RegexResultGetLastGroupNode)] */;
                                        this.state_0_ = state_0;
                                    }
                                }
                            }
                            if (s6_ != null) {
                                return ReadMember.lastGroupIdentity(arg0Value, arg1Value, s6_.cachedSymbol_, this.getLastGroupNode);
                            }
                            break;
                        }
                    }
                    while (true) {
                        int count7_ = 0;
                        ReadMemberLastGroupEqualsData s7_ = READ_MEMBER_LAST_GROUP_EQUALS_CACHE_UPDATER.getVolatile(this);
                        ReadMemberLastGroupEqualsData s7_original = s7_;
                        while (s7_ != null) {
                            {
                                RegexResultGetLastGroupNode getLastGroupNode_1 = this.getLastGroupNode;
                                if (getLastGroupNode_1 != null) {
                                    if ((arg1Value.equals(s7_.cachedSymbol_))) {
                                        assert DSLSupport.assertIdempotence((s7_.cachedSymbol_.equals(RegexResult.PROP_LAST_GROUP)));
                                        break;
                                    }
                                }
                            }
                            count7_++;
                            s7_ = s7_.next_;
                        }
                        if (s7_ == null) {
                            {
                                String cachedSymbol__7 = (arg1Value);
                                // assert (arg1Value.equals(s7_.cachedSymbol_));
                                if ((cachedSymbol__7.equals(RegexResult.PROP_LAST_GROUP)) && count7_ < (2)) {
                                    s7_ = new ReadMemberLastGroupEqualsData(s7_original);
                                    s7_.cachedSymbol_ = cachedSymbol__7;
                                    RegexResultGetLastGroupNode getLastGroupNode_1;
                                    RegexResultGetLastGroupNode getLastGroupNode_1_shared = this.getLastGroupNode;
                                    if (getLastGroupNode_1_shared != null) {
                                        getLastGroupNode_1 = getLastGroupNode_1_shared;
                                    } else {
                                        getLastGroupNode_1 = this.insert((RegexResultGetLastGroupNodeGen.create()));
                                        if (getLastGroupNode_1 == null) {
                                            throw new IllegalStateException("Specialization 'lastGroupEquals(RegexResult, String, String, RegexResultGetLastGroupNode)' contains a shared cache with name 'getLastGroupNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.getLastGroupNode == null) {
                                        this.getLastGroupNode = getLastGroupNode_1;
                                    }
                                    if (!READ_MEMBER_LAST_GROUP_EQUALS_CACHE_UPDATER.compareAndSet(this, s7_original, s7_)) {
                                        continue;
                                    }
                                    this.readMember_lastGroupIdentity_cache = null;
                                    state_0 = state_0 & 0xfffffbff /* remove SpecializationActive[RegexResult.ReadMember.lastGroupIdentity(RegexResult, String, String, RegexResultGetLastGroupNode)] */;
                                    state_0 = state_0 | 0b100000000000 /* add SpecializationActive[RegexResult.ReadMember.lastGroupEquals(RegexResult, String, String, RegexResultGetLastGroupNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s7_ != null) {
                            return ReadMember.lastGroupEquals(arg0Value, arg1Value, s7_.cachedSymbol_, this.getLastGroupNode);
                        }
                        break;
                    }
                    RegexResultGetLastGroupNode getLastGroupNode_2;
                    RegexResultGetLastGroupNode getLastGroupNode_2_shared = this.getLastGroupNode;
                    if (getLastGroupNode_2_shared != null) {
                        getLastGroupNode_2 = getLastGroupNode_2_shared;
                    } else {
                        getLastGroupNode_2 = this.insert((RegexResultGetLastGroupNodeGen.create()));
                        if (getLastGroupNode_2 == null) {
                            throw new IllegalStateException("Specialization 'readGeneric(RegexResult, String, RegexResultGetLastGroupNode)' contains a shared cache with name 'getLastGroupNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                        }
                    }
                    if (this.getLastGroupNode == null) {
                        VarHandle.storeStoreFence();
                        this.getLastGroupNode = getLastGroupNode_2;
                    }
                    this.readMember_isMatchIdentity_cache = null;
                    this.readMember_isMatchEquals_cache = null;
                    this.readMember_getStartIdentity_cache = null;
                    this.readMember_getStartEquals_cache = null;
                    this.readMember_getEndIdentity_cache = null;
                    this.readMember_getEndEquals_cache = null;
                    state_0 = state_0 & 0xfffffc27 /* remove SpecializationActive[RegexResult.ReadMember.isMatchIdentity(RegexResult, String, String)], SpecializationActive[RegexResult.ReadMember.isMatchEquals(RegexResult, String, String)], SpecializationActive[RegexResult.ReadMember.getStartIdentity(RegexResult, String, String)], SpecializationActive[RegexResult.ReadMember.getStartEquals(RegexResult, String, String)], SpecializationActive[RegexResult.ReadMember.getEndIdentity(RegexResult, String, String)], SpecializationActive[RegexResult.ReadMember.getEndEquals(RegexResult, String, String)] */;
                    state_0 = state_0 | 0b100000 /* add SpecializationActive[RegexResult.ReadMember.readGeneric(RegexResult, String, RegexResultGetLastGroupNode)] */;
                    this.state_0_ = state_0;
                    return ReadMember.readGeneric(arg0Value, arg1Value, getLastGroupNode_2);
                } finally {
                    if (oldState_0 != 0) {
                        readMember_checkForPolymorphicSpecialize(oldState_0);
                    }
                }
            }

            private void readMember_checkForPolymorphicSpecialize(int oldState_0) {
                if (((oldState_0 & 0b100000) == 0 && (state_0_ & 0b100000) != 0)) {
                    this.reportPolymorphicSpecialize();
                }
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link IsMemberInvocable#cacheIdentity}
             *     Activation probability: 0.12083
             *     With/without class size: 6/5 bytes
             *   Specialization {@link IsMemberInvocable#cacheEquals}
             *     Activation probability: 0.08333
             *     With/without class size: 5/5 bytes
             *   Specialization {@link IsMemberInvocable#isInvocable}
             *     Activation probability: 0.04583
             *     With/without class size: 4/0 bytes
             * </pre>
             */
            @ExplodeLoop
            @Override
            public boolean isMemberInvocable(Object arg0Value_, String arg1Value) {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexResult arg0Value = ((RegexResult) arg0Value_);
                int state_0 = this.state_0_;
                if ((state_0 & 0b111000000000000) != 0 /* is SpecializationActive[RegexResult.IsMemberInvocable.cacheIdentity(RegexResult, String, String, boolean)] || SpecializationActive[RegexResult.IsMemberInvocable.cacheEquals(RegexResult, String, String, boolean)] || SpecializationActive[RegexResult.IsMemberInvocable.isInvocable(RegexResult, String)] */) {
                    if ((state_0 & 0b1000000000000) != 0 /* is SpecializationActive[RegexResult.IsMemberInvocable.cacheIdentity(RegexResult, String, String, boolean)] */) {
                        IsMemberInvocableCacheIdentityData s0_ = this.isMemberInvocable_cacheIdentity_cache;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s0_.result_));
                                return IsMemberInvocable.cacheIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.result_);
                            }
                            s0_ = s0_.next_;
                        }
                    }
                    if ((state_0 & 0b10000000000000) != 0 /* is SpecializationActive[RegexResult.IsMemberInvocable.cacheEquals(RegexResult, String, String, boolean)] */) {
                        IsMemberInvocableCacheEqualsData s1_ = this.isMemberInvocable_cacheEquals_cache;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s1_.result_));
                                return IsMemberInvocable.cacheEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.result_);
                            }
                            s1_ = s1_.next_;
                        }
                    }
                    if ((state_0 & 0b100000000000000) != 0 /* is SpecializationActive[RegexResult.IsMemberInvocable.isInvocable(RegexResult, String)] */) {
                        return IsMemberInvocable.isInvocable(arg0Value, arg1Value);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return isMemberInvocableAndSpecialize(arg0Value, arg1Value);
            }

            private boolean isMemberInvocableAndSpecialize(RegexResult arg0Value, String arg1Value) {
                int state_0 = this.state_0_;
                if (((state_0 & 0b110000000000000)) == 0 /* is-not SpecializationActive[RegexResult.IsMemberInvocable.cacheEquals(RegexResult, String, String, boolean)] && SpecializationActive[RegexResult.IsMemberInvocable.isInvocable(RegexResult, String)] */) {
                    while (true) {
                        int count0_ = 0;
                        IsMemberInvocableCacheIdentityData s0_ = IS_MEMBER_INVOCABLE_CACHE_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        IsMemberInvocableCacheIdentityData s0_original = s0_;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s0_.result_));
                                break;
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            {
                                String cachedSymbol__ = (arg1Value);
                                boolean result__ = (IsMemberInvocable.isInvocable(arg0Value, cachedSymbol__));
                                // assert (arg1Value == s0_.cachedSymbol_);
                                if ((result__) && count0_ < (2)) {
                                    s0_ = new IsMemberInvocableCacheIdentityData(s0_original);
                                    s0_.cachedSymbol_ = cachedSymbol__;
                                    s0_.result_ = result__;
                                    if (!IS_MEMBER_INVOCABLE_CACHE_IDENTITY_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                        continue;
                                    }
                                    state_0 = state_0 | 0b1000000000000 /* add SpecializationActive[RegexResult.IsMemberInvocable.cacheIdentity(RegexResult, String, String, boolean)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s0_ != null) {
                            return IsMemberInvocable.cacheIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.result_);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100000000000000)) == 0 /* is-not SpecializationActive[RegexResult.IsMemberInvocable.isInvocable(RegexResult, String)] */) {
                    while (true) {
                        int count1_ = 0;
                        IsMemberInvocableCacheEqualsData s1_ = IS_MEMBER_INVOCABLE_CACHE_EQUALS_CACHE_UPDATER.getVolatile(this);
                        IsMemberInvocableCacheEqualsData s1_original = s1_;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s1_.result_));
                                break;
                            }
                            count1_++;
                            s1_ = s1_.next_;
                        }
                        if (s1_ == null) {
                            {
                                String cachedSymbol__1 = (arg1Value);
                                boolean result__1 = (IsMemberInvocable.isInvocable(arg0Value, cachedSymbol__1));
                                // assert (arg1Value.equals(s1_.cachedSymbol_));
                                if ((result__1) && count1_ < (2)) {
                                    s1_ = new IsMemberInvocableCacheEqualsData(s1_original);
                                    s1_.cachedSymbol_ = cachedSymbol__1;
                                    s1_.result_ = result__1;
                                    if (!IS_MEMBER_INVOCABLE_CACHE_EQUALS_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                        continue;
                                    }
                                    this.isMemberInvocable_cacheIdentity_cache = null;
                                    state_0 = state_0 & 0xffffefff /* remove SpecializationActive[RegexResult.IsMemberInvocable.cacheIdentity(RegexResult, String, String, boolean)] */;
                                    state_0 = state_0 | 0b10000000000000 /* add SpecializationActive[RegexResult.IsMemberInvocable.cacheEquals(RegexResult, String, String, boolean)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s1_ != null) {
                            return IsMemberInvocable.cacheEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.result_);
                        }
                        break;
                    }
                }
                this.isMemberInvocable_cacheIdentity_cache = null;
                this.isMemberInvocable_cacheEquals_cache = null;
                state_0 = state_0 & 0xffffcfff /* remove SpecializationActive[RegexResult.IsMemberInvocable.cacheIdentity(RegexResult, String, String, boolean)], SpecializationActive[RegexResult.IsMemberInvocable.cacheEquals(RegexResult, String, String, boolean)] */;
                state_0 = state_0 | 0b100000000000000 /* add SpecializationActive[RegexResult.IsMemberInvocable.isInvocable(RegexResult, String)] */;
                this.state_0_ = state_0;
                return IsMemberInvocable.isInvocable(arg0Value, arg1Value);
            }

            @Override
            public Object getMembers(Object receiver, boolean includeInternal) throws UnsupportedMessageException {
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                return (((RegexResult) receiver)).getMembers(includeInternal);
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link RegexResult#invokeMember(RegexResult, String, Object[], ToIntNode, InvokeCacheNode)}
             *     Activation probability: 0.25000
             *     With/without class size: 10/8 bytes
             * </pre>
             */
            @Override
            public Object invokeMember(Object arg0Value_, String arg1Value, Object... arg2Value) throws UnsupportedMessageException, ArityException, UnknownIdentifierException, UnsupportedTypeException {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexResult arg0Value = ((RegexResult) arg0Value_);
                int state_0 = this.state_0_;
                if ((state_0 & 0b1000000000000000) != 0 /* is SpecializationActive[RegexResult.invokeMember(RegexResult, String, Object[], ToIntNode, InvokeCacheNode)] */) {
                    {
                        ToIntNode toIntNode__ = this.invokeMemberNode__invokeMember_toIntNode_;
                        if (toIntNode__ != null) {
                            InvokeCacheNode invokeCache__ = this.invokeMemberNode__invokeMember_invokeCache_;
                            if (invokeCache__ != null) {
                                return arg0Value.invokeMember(arg1Value, arg2Value, toIntNode__, invokeCache__);
                            }
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return invokeMemberNode_AndSpecialize(arg0Value, arg1Value, arg2Value);
            }

            private Object invokeMemberNode_AndSpecialize(RegexResult arg0Value, String arg1Value, Object[] arg2Value) throws UnknownIdentifierException, ArityException, UnsupportedTypeException {
                int state_0 = this.state_0_;
                ToIntNode toIntNode__ = this.insert((ToIntNodeGen.create()));
                Objects.requireNonNull(toIntNode__, "Specialization 'invokeMember(RegexResult, String, Object[], ToIntNode, InvokeCacheNode)' cache 'toIntNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.invokeMemberNode__invokeMember_toIntNode_ = toIntNode__;
                InvokeCacheNode invokeCache__ = this.insert((InvokeCacheNodeGen.create()));
                Objects.requireNonNull(invokeCache__, "Specialization 'invokeMember(RegexResult, String, Object[], ToIntNode, InvokeCacheNode)' cache 'invokeCache' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.invokeMemberNode__invokeMember_invokeCache_ = invokeCache__;
                state_0 = state_0 | 0b1000000000000000 /* add SpecializationActive[RegexResult.invokeMember(RegexResult, String, Object[], ToIntNode, InvokeCacheNode)] */;
                this.state_0_ = state_0;
                return arg0Value.invokeMember(arg1Value, arg2Value, toIntNode__, invokeCache__);
            }

            @Override
            public Object toDisplayString(Object receiver, boolean allowSideEffects) {
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                return (((RegexResult) receiver)).toDisplayString(allowSideEffects);
            }

            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class IsMemberReadableCacheIdentityData implements SpecializationDataNode {

                @CompilationFinal final IsMemberReadableCacheIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheIdentity}
                 *   Parameter: boolean result</pre>
                 */
                @CompilationFinal boolean result_;

                IsMemberReadableCacheIdentityData(IsMemberReadableCacheIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class IsMemberReadableCacheEqualsData implements SpecializationDataNode {

                @CompilationFinal final IsMemberReadableCacheEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberReadable#cacheEquals}
                 *   Parameter: boolean result</pre>
                 */
                @CompilationFinal boolean result_;

                IsMemberReadableCacheEqualsData(IsMemberReadableCacheEqualsData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class ReadMemberIsMatchIdentityData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberIsMatchIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#isMatchIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;

                ReadMemberIsMatchIdentityData(ReadMemberIsMatchIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class ReadMemberIsMatchEqualsData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberIsMatchEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#isMatchEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;

                ReadMemberIsMatchEqualsData(ReadMemberIsMatchEqualsData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class ReadMemberGetStartIdentityData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberGetStartIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#getStartIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;

                ReadMemberGetStartIdentityData(ReadMemberGetStartIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class ReadMemberGetStartEqualsData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberGetStartEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#getStartEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;

                ReadMemberGetStartEqualsData(ReadMemberGetStartEqualsData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class ReadMemberGetEndIdentityData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberGetEndIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#getEndIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;

                ReadMemberGetEndIdentityData(ReadMemberGetEndIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class ReadMemberGetEndEqualsData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberGetEndEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#getEndEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;

                ReadMemberGetEndEqualsData(ReadMemberGetEndEqualsData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class ReadMemberLastGroupIdentityData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberLastGroupIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#lastGroupIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;

                ReadMemberLastGroupIdentityData(ReadMemberLastGroupIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class ReadMemberLastGroupEqualsData implements SpecializationDataNode {

                @CompilationFinal final ReadMemberLastGroupEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link ReadMember#lastGroupEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;

                ReadMemberLastGroupEqualsData(ReadMemberLastGroupEqualsData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class IsMemberInvocableCacheIdentityData implements SpecializationDataNode {

                @CompilationFinal final IsMemberInvocableCacheIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberInvocable#cacheIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberInvocable#cacheIdentity}
                 *   Parameter: boolean result</pre>
                 */
                @CompilationFinal boolean result_;

                IsMemberInvocableCacheIdentityData(IsMemberInvocableCacheIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexResult.class)
            @DenyReplace
            private static final class IsMemberInvocableCacheEqualsData implements SpecializationDataNode {

                @CompilationFinal final IsMemberInvocableCacheEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberInvocable#cacheEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberInvocable#cacheEquals}
                 *   Parameter: boolean result</pre>
                 */
                @CompilationFinal boolean result_;

                IsMemberInvocableCacheEqualsData(IsMemberInvocableCacheEqualsData next_) {
                    this.next_ = next_;
                }

            }
        }
        @GeneratedBy(RegexResult.class)
        @DenyReplace
        private static final class Uncached extends AbstractConstantKeysObjectGen.InteropLibraryExports.Uncached {

            protected Uncached(Object receiver) {
                super(receiver);
            }

            @Override
            @TruffleBoundary
            public boolean accepts(Object receiver) {
                return super.accepts(receiver);
            }

            @TruffleBoundary
            @Override
            public boolean isMemberReadable(Object arg0Value_, String arg1Value) {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexResult arg0Value = ((RegexResult) arg0Value_);
                return IsMemberReadable.isReadable(arg0Value, arg1Value);
            }

            @TruffleBoundary
            @Override
            public Object readMember(Object arg0Value_, String arg1Value) throws UnknownIdentifierException {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexResult arg0Value = ((RegexResult) arg0Value_);
                // assert (arg1Value.equals((arg1Value)));
                if (((arg1Value).equals(RegexResult.PROP_LAST_GROUP))) {
                    return ReadMember.lastGroupEquals(arg0Value, arg1Value, (arg1Value), (RegexResultGetLastGroupNodeGen.getUncached()));
                }
                return ReadMember.readGeneric(arg0Value, arg1Value, (RegexResultGetLastGroupNodeGen.getUncached()));
            }

            @TruffleBoundary
            @Override
            public boolean isMemberInvocable(Object arg0Value_, String arg1Value) {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexResult arg0Value = ((RegexResult) arg0Value_);
                return IsMemberInvocable.isInvocable(arg0Value, arg1Value);
            }

            @TruffleBoundary
            @Override
            public Object getMembers(Object receiver, boolean includeInternal) throws UnsupportedMessageException {
                // declared: true
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                return ((RegexResult) receiver) .getMembers(includeInternal);
            }

            @TruffleBoundary
            @Override
            public Object invokeMember(Object arg0Value_, String arg1Value, Object... arg2Value) throws UnknownIdentifierException, ArityException, UnsupportedTypeException {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexResult arg0Value = ((RegexResult) arg0Value_);
                return arg0Value.invokeMember(arg1Value, arg2Value, (ToIntNodeGen.getUncached()), (InvokeCacheNodeGen.getUncached()));
            }

            @TruffleBoundary
            @Override
            public Object toDisplayString(Object receiver, boolean allowSideEffects) {
                // declared: true
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                return ((RegexResult) receiver) .toDisplayString(allowSideEffects);
            }

        }
    }
}
