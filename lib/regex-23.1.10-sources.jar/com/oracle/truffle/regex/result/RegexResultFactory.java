// CheckStyle: start generated
package com.oracle.truffle.regex.result;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.DSLSupport;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.interop.UnknownIdentifierException;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.InlinedBranchProfile;
import com.oracle.truffle.regex.result.RegexResult.InvokeCacheNode;
import com.oracle.truffle.regex.result.RegexResult.RegexResultGetEndNode;
import com.oracle.truffle.regex.result.RegexResult.RegexResultGetLastGroupNode;
import com.oracle.truffle.regex.result.RegexResult.RegexResultGetStartNode;
import com.oracle.truffle.regex.runtime.nodes.DispatchNode;
import com.oracle.truffle.regex.runtime.nodes.DispatchNodeGen;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;

@GeneratedBy(RegexResult.class)
@SuppressWarnings("javadoc")
public final class RegexResultFactory {

    /**
     * Debug Info: <pre>
     *   Specialization {@link InvokeCacheNode#getStartIdentity}
     *     Activation probability: 0.32000
     *     With/without class size: 10/4 bytes
     *   Specialization {@link InvokeCacheNode#getStartEquals}
     *     Activation probability: 0.26000
     *     With/without class size: 9/4 bytes
     *   Specialization {@link InvokeCacheNode#getEndIdentity}
     *     Activation probability: 0.20000
     *     With/without class size: 8/4 bytes
     *   Specialization {@link InvokeCacheNode#getEndEquals}
     *     Activation probability: 0.14000
     *     With/without class size: 6/4 bytes
     *   Specialization {@link InvokeCacheNode#invokeGeneric}
     *     Activation probability: 0.08000
     *     With/without class size: 4/0 bytes
     * </pre>
     */
    @GeneratedBy(InvokeCacheNode.class)
    @SuppressWarnings("javadoc")
    static final class InvokeCacheNodeGen extends InvokeCacheNode {

        static final ReferenceField<GetStartIdentityData> GET_START_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "getStartIdentity_cache", GetStartIdentityData.class);
        static final ReferenceField<GetStartEqualsData> GET_START_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "getStartEquals_cache", GetStartEqualsData.class);
        static final ReferenceField<GetEndIdentityData> GET_END_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "getEndIdentity_cache", GetEndIdentityData.class);
        static final ReferenceField<GetEndEqualsData> GET_END_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "getEndEquals_cache", GetEndEqualsData.class);
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link InvokeCacheNode#getStartIdentity}
         *   1: SpecializationActive {@link InvokeCacheNode#getStartEquals}
         *   2: SpecializationActive {@link InvokeCacheNode#invokeGeneric}
         *   3: SpecializationActive {@link InvokeCacheNode#getEndIdentity}
         *   4: SpecializationActive {@link InvokeCacheNode#getEndEquals}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link InvokeCacheNode#getStartIdentity}
         *   Parameter: {@link RegexResultGetStartNode} getStartNode</pre>
         */
        @Child private RegexResultGetStartNode getStartNode;
        /**
         * Source Info: <pre>
         *   Specialization: {@link InvokeCacheNode#getEndIdentity}
         *   Parameter: {@link RegexResultGetEndNode} getEndNode</pre>
         */
        @Child private RegexResultGetEndNode getEndNode;
        @UnsafeAccessedField @CompilationFinal private GetStartIdentityData getStartIdentity_cache;
        @UnsafeAccessedField @CompilationFinal private GetStartEqualsData getStartEquals_cache;
        @UnsafeAccessedField @CompilationFinal private GetEndIdentityData getEndIdentity_cache;
        @UnsafeAccessedField @CompilationFinal private GetEndEqualsData getEndEquals_cache;

        private InvokeCacheNodeGen() {
        }

        @ExplodeLoop
        @Override
        Object execute(RegexResult arg0Value, String arg1Value, int arg2Value) throws UnknownIdentifierException {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[RegexResult.InvokeCacheNode.getStartIdentity(RegexResult, String, int, String, RegexResultGetStartNode)] || SpecializationActive[RegexResult.InvokeCacheNode.getStartEquals(RegexResult, String, int, String, RegexResultGetStartNode)] || SpecializationActive[RegexResult.InvokeCacheNode.getEndIdentity(RegexResult, String, int, String, RegexResultGetEndNode)] || SpecializationActive[RegexResult.InvokeCacheNode.getEndEquals(RegexResult, String, int, String, RegexResultGetEndNode)] || SpecializationActive[RegexResult.InvokeCacheNode.invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexResult.InvokeCacheNode.getStartIdentity(RegexResult, String, int, String, RegexResultGetStartNode)] */) {
                    GetStartIdentityData s0_ = this.getStartIdentity_cache;
                    while (s0_ != null) {
                        {
                            RegexResultGetStartNode getStartNode_ = this.getStartNode;
                            if (getStartNode_ != null) {
                                if ((arg1Value == s0_.cachedSymbol_)) {
                                    assert DSLSupport.assertIdempotence((s0_.cachedSymbol_.equals(RegexResult.PROP_GET_START)));
                                    return InvokeCacheNode.getStartIdentity(arg0Value, arg1Value, arg2Value, s0_.cachedSymbol_, getStartNode_);
                                }
                            }
                        }
                        s0_ = s0_.next_;
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[RegexResult.InvokeCacheNode.getStartEquals(RegexResult, String, int, String, RegexResultGetStartNode)] */) {
                    GetStartEqualsData s1_ = this.getStartEquals_cache;
                    while (s1_ != null) {
                        {
                            RegexResultGetStartNode getStartNode_1 = this.getStartNode;
                            if (getStartNode_1 != null) {
                                if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                    assert DSLSupport.assertIdempotence((s1_.cachedSymbol_.equals(RegexResult.PROP_GET_START)));
                                    return InvokeCacheNode.getStartEquals(arg0Value, arg1Value, arg2Value, s1_.cachedSymbol_, getStartNode_1);
                                }
                            }
                        }
                        s1_ = s1_.next_;
                    }
                }
                if ((state_0 & 0b1000) != 0 /* is SpecializationActive[RegexResult.InvokeCacheNode.getEndIdentity(RegexResult, String, int, String, RegexResultGetEndNode)] */) {
                    GetEndIdentityData s2_ = this.getEndIdentity_cache;
                    while (s2_ != null) {
                        {
                            RegexResultGetEndNode getEndNode_ = this.getEndNode;
                            if (getEndNode_ != null) {
                                if ((arg1Value == s2_.cachedSymbol_)) {
                                    assert DSLSupport.assertIdempotence((s2_.cachedSymbol_.equals(RegexResult.PROP_GET_END)));
                                    return InvokeCacheNode.getEndIdentity(arg0Value, arg1Value, arg2Value, s2_.cachedSymbol_, getEndNode_);
                                }
                            }
                        }
                        s2_ = s2_.next_;
                    }
                }
                if ((state_0 & 0b10000) != 0 /* is SpecializationActive[RegexResult.InvokeCacheNode.getEndEquals(RegexResult, String, int, String, RegexResultGetEndNode)] */) {
                    GetEndEqualsData s3_ = this.getEndEquals_cache;
                    while (s3_ != null) {
                        {
                            RegexResultGetEndNode getEndNode_1 = this.getEndNode;
                            if (getEndNode_1 != null) {
                                if ((arg1Value.equals(s3_.cachedSymbol_))) {
                                    assert DSLSupport.assertIdempotence((s3_.cachedSymbol_.equals(RegexResult.PROP_GET_END)));
                                    return InvokeCacheNode.getEndEquals(arg0Value, arg1Value, arg2Value, s3_.cachedSymbol_, getEndNode_1);
                                }
                            }
                        }
                        s3_ = s3_.next_;
                    }
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[RegexResult.InvokeCacheNode.invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)] */) {
                    {
                        RegexResultGetStartNode getStartNode_2 = this.getStartNode;
                        if (getStartNode_2 != null) {
                            RegexResultGetEndNode getEndNode_2 = this.getEndNode;
                            if (getEndNode_2 != null) {
                                return InvokeCacheNode.invokeGeneric(arg0Value, arg1Value, arg2Value, getStartNode_2, getEndNode_2);
                            }
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(RegexResult arg0Value, String arg1Value, int arg2Value) throws UnknownIdentifierException {
            int state_0 = this.state_0_;
            int oldState_0 = state_0;
            try {
                if (((state_0 & 0b110)) == 0 /* is-not SpecializationActive[RegexResult.InvokeCacheNode.getStartEquals(RegexResult, String, int, String, RegexResultGetStartNode)] && SpecializationActive[RegexResult.InvokeCacheNode.invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)] */) {
                    while (true) {
                        int count0_ = 0;
                        GetStartIdentityData s0_ = GET_START_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        GetStartIdentityData s0_original = s0_;
                        while (s0_ != null) {
                            {
                                RegexResultGetStartNode getStartNode_ = this.getStartNode;
                                if (getStartNode_ != null) {
                                    if ((arg1Value == s0_.cachedSymbol_)) {
                                        assert DSLSupport.assertIdempotence((s0_.cachedSymbol_.equals(RegexResult.PROP_GET_START)));
                                        break;
                                    }
                                }
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            {
                                String cachedSymbol__ = (arg1Value);
                                // assert (arg1Value == s0_.cachedSymbol_);
                                if ((cachedSymbol__.equals(RegexResult.PROP_GET_START)) && count0_ < (2)) {
                                    s0_ = new GetStartIdentityData(s0_original);
                                    s0_.cachedSymbol_ = cachedSymbol__;
                                    RegexResultGetStartNode getStartNode_;
                                    RegexResultGetStartNode getStartNode__shared = this.getStartNode;
                                    if (getStartNode__shared != null) {
                                        getStartNode_ = getStartNode__shared;
                                    } else {
                                        getStartNode_ = this.insert((RegexResultGetStartNodeGen.create()));
                                        if (getStartNode_ == null) {
                                            throw new IllegalStateException("Specialization 'getStartIdentity(RegexResult, String, int, String, RegexResultGetStartNode)' contains a shared cache with name 'getStartNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.getStartNode == null) {
                                        this.getStartNode = getStartNode_;
                                    }
                                    if (!GET_START_IDENTITY_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                        continue;
                                    }
                                    state_0 = state_0 | 0b1 /* add SpecializationActive[RegexResult.InvokeCacheNode.getStartIdentity(RegexResult, String, int, String, RegexResultGetStartNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s0_ != null) {
                            return InvokeCacheNode.getStartIdentity(arg0Value, arg1Value, arg2Value, s0_.cachedSymbol_, this.getStartNode);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100)) == 0 /* is-not SpecializationActive[RegexResult.InvokeCacheNode.invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)] */) {
                    while (true) {
                        int count1_ = 0;
                        GetStartEqualsData s1_ = GET_START_EQUALS_CACHE_UPDATER.getVolatile(this);
                        GetStartEqualsData s1_original = s1_;
                        while (s1_ != null) {
                            {
                                RegexResultGetStartNode getStartNode_1 = this.getStartNode;
                                if (getStartNode_1 != null) {
                                    if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                        assert DSLSupport.assertIdempotence((s1_.cachedSymbol_.equals(RegexResult.PROP_GET_START)));
                                        break;
                                    }
                                }
                            }
                            count1_++;
                            s1_ = s1_.next_;
                        }
                        if (s1_ == null) {
                            {
                                String cachedSymbol__1 = (arg1Value);
                                // assert (arg1Value.equals(s1_.cachedSymbol_));
                                if ((cachedSymbol__1.equals(RegexResult.PROP_GET_START)) && count1_ < (2)) {
                                    s1_ = new GetStartEqualsData(s1_original);
                                    s1_.cachedSymbol_ = cachedSymbol__1;
                                    RegexResultGetStartNode getStartNode_1;
                                    RegexResultGetStartNode getStartNode_1_shared = this.getStartNode;
                                    if (getStartNode_1_shared != null) {
                                        getStartNode_1 = getStartNode_1_shared;
                                    } else {
                                        getStartNode_1 = this.insert((RegexResultGetStartNodeGen.create()));
                                        if (getStartNode_1 == null) {
                                            throw new IllegalStateException("Specialization 'getStartEquals(RegexResult, String, int, String, RegexResultGetStartNode)' contains a shared cache with name 'getStartNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.getStartNode == null) {
                                        this.getStartNode = getStartNode_1;
                                    }
                                    if (!GET_START_EQUALS_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                        continue;
                                    }
                                    this.getStartIdentity_cache = null;
                                    state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[RegexResult.InvokeCacheNode.getStartIdentity(RegexResult, String, int, String, RegexResultGetStartNode)] */;
                                    state_0 = state_0 | 0b10 /* add SpecializationActive[RegexResult.InvokeCacheNode.getStartEquals(RegexResult, String, int, String, RegexResultGetStartNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s1_ != null) {
                            return InvokeCacheNode.getStartEquals(arg0Value, arg1Value, arg2Value, s1_.cachedSymbol_, this.getStartNode);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b10100)) == 0 /* is-not SpecializationActive[RegexResult.InvokeCacheNode.getEndEquals(RegexResult, String, int, String, RegexResultGetEndNode)] && SpecializationActive[RegexResult.InvokeCacheNode.invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)] */) {
                    while (true) {
                        int count2_ = 0;
                        GetEndIdentityData s2_ = GET_END_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        GetEndIdentityData s2_original = s2_;
                        while (s2_ != null) {
                            {
                                RegexResultGetEndNode getEndNode_ = this.getEndNode;
                                if (getEndNode_ != null) {
                                    if ((arg1Value == s2_.cachedSymbol_)) {
                                        assert DSLSupport.assertIdempotence((s2_.cachedSymbol_.equals(RegexResult.PROP_GET_END)));
                                        break;
                                    }
                                }
                            }
                            count2_++;
                            s2_ = s2_.next_;
                        }
                        if (s2_ == null) {
                            {
                                String cachedSymbol__2 = (arg1Value);
                                // assert (arg1Value == s2_.cachedSymbol_);
                                if ((cachedSymbol__2.equals(RegexResult.PROP_GET_END)) && count2_ < (2)) {
                                    s2_ = new GetEndIdentityData(s2_original);
                                    s2_.cachedSymbol_ = cachedSymbol__2;
                                    RegexResultGetEndNode getEndNode_;
                                    RegexResultGetEndNode getEndNode__shared = this.getEndNode;
                                    if (getEndNode__shared != null) {
                                        getEndNode_ = getEndNode__shared;
                                    } else {
                                        getEndNode_ = this.insert((RegexResultGetEndNodeGen.create()));
                                        if (getEndNode_ == null) {
                                            throw new IllegalStateException("Specialization 'getEndIdentity(RegexResult, String, int, String, RegexResultGetEndNode)' contains a shared cache with name 'getEndNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.getEndNode == null) {
                                        this.getEndNode = getEndNode_;
                                    }
                                    if (!GET_END_IDENTITY_CACHE_UPDATER.compareAndSet(this, s2_original, s2_)) {
                                        continue;
                                    }
                                    state_0 = state_0 | 0b1000 /* add SpecializationActive[RegexResult.InvokeCacheNode.getEndIdentity(RegexResult, String, int, String, RegexResultGetEndNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s2_ != null) {
                            return InvokeCacheNode.getEndIdentity(arg0Value, arg1Value, arg2Value, s2_.cachedSymbol_, this.getEndNode);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100)) == 0 /* is-not SpecializationActive[RegexResult.InvokeCacheNode.invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)] */) {
                    while (true) {
                        int count3_ = 0;
                        GetEndEqualsData s3_ = GET_END_EQUALS_CACHE_UPDATER.getVolatile(this);
                        GetEndEqualsData s3_original = s3_;
                        while (s3_ != null) {
                            {
                                RegexResultGetEndNode getEndNode_1 = this.getEndNode;
                                if (getEndNode_1 != null) {
                                    if ((arg1Value.equals(s3_.cachedSymbol_))) {
                                        assert DSLSupport.assertIdempotence((s3_.cachedSymbol_.equals(RegexResult.PROP_GET_END)));
                                        break;
                                    }
                                }
                            }
                            count3_++;
                            s3_ = s3_.next_;
                        }
                        if (s3_ == null) {
                            {
                                String cachedSymbol__3 = (arg1Value);
                                // assert (arg1Value.equals(s3_.cachedSymbol_));
                                if ((cachedSymbol__3.equals(RegexResult.PROP_GET_END)) && count3_ < (2)) {
                                    s3_ = new GetEndEqualsData(s3_original);
                                    s3_.cachedSymbol_ = cachedSymbol__3;
                                    RegexResultGetEndNode getEndNode_1;
                                    RegexResultGetEndNode getEndNode_1_shared = this.getEndNode;
                                    if (getEndNode_1_shared != null) {
                                        getEndNode_1 = getEndNode_1_shared;
                                    } else {
                                        getEndNode_1 = this.insert((RegexResultGetEndNodeGen.create()));
                                        if (getEndNode_1 == null) {
                                            throw new IllegalStateException("Specialization 'getEndEquals(RegexResult, String, int, String, RegexResultGetEndNode)' contains a shared cache with name 'getEndNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.getEndNode == null) {
                                        this.getEndNode = getEndNode_1;
                                    }
                                    if (!GET_END_EQUALS_CACHE_UPDATER.compareAndSet(this, s3_original, s3_)) {
                                        continue;
                                    }
                                    this.getEndIdentity_cache = null;
                                    state_0 = state_0 & 0xfffffff7 /* remove SpecializationActive[RegexResult.InvokeCacheNode.getEndIdentity(RegexResult, String, int, String, RegexResultGetEndNode)] */;
                                    state_0 = state_0 | 0b10000 /* add SpecializationActive[RegexResult.InvokeCacheNode.getEndEquals(RegexResult, String, int, String, RegexResultGetEndNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s3_ != null) {
                            return InvokeCacheNode.getEndEquals(arg0Value, arg1Value, arg2Value, s3_.cachedSymbol_, this.getEndNode);
                        }
                        break;
                    }
                }
                RegexResultGetStartNode getStartNode_2;
                RegexResultGetStartNode getStartNode_2_shared = this.getStartNode;
                if (getStartNode_2_shared != null) {
                    getStartNode_2 = getStartNode_2_shared;
                } else {
                    getStartNode_2 = this.insert((RegexResultGetStartNodeGen.create()));
                    if (getStartNode_2 == null) {
                        throw new IllegalStateException("Specialization 'invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)' contains a shared cache with name 'getStartNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                    }
                }
                if (this.getStartNode == null) {
                    VarHandle.storeStoreFence();
                    this.getStartNode = getStartNode_2;
                }
                RegexResultGetEndNode getEndNode_2;
                RegexResultGetEndNode getEndNode_2_shared = this.getEndNode;
                if (getEndNode_2_shared != null) {
                    getEndNode_2 = getEndNode_2_shared;
                } else {
                    getEndNode_2 = this.insert((RegexResultGetEndNodeGen.create()));
                    if (getEndNode_2 == null) {
                        throw new IllegalStateException("Specialization 'invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)' contains a shared cache with name 'getEndNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                    }
                }
                if (this.getEndNode == null) {
                    VarHandle.storeStoreFence();
                    this.getEndNode = getEndNode_2;
                }
                this.getStartIdentity_cache = null;
                this.getStartEquals_cache = null;
                this.getEndIdentity_cache = null;
                this.getEndEquals_cache = null;
                state_0 = state_0 & 0xffffffe4 /* remove SpecializationActive[RegexResult.InvokeCacheNode.getStartIdentity(RegexResult, String, int, String, RegexResultGetStartNode)], SpecializationActive[RegexResult.InvokeCacheNode.getStartEquals(RegexResult, String, int, String, RegexResultGetStartNode)], SpecializationActive[RegexResult.InvokeCacheNode.getEndIdentity(RegexResult, String, int, String, RegexResultGetEndNode)], SpecializationActive[RegexResult.InvokeCacheNode.getEndEquals(RegexResult, String, int, String, RegexResultGetEndNode)] */;
                state_0 = state_0 | 0b100 /* add SpecializationActive[RegexResult.InvokeCacheNode.invokeGeneric(RegexResult, String, int, RegexResultGetStartNode, RegexResultGetEndNode)] */;
                this.state_0_ = state_0;
                return InvokeCacheNode.invokeGeneric(arg0Value, arg1Value, arg2Value, getStartNode_2, getEndNode_2);
            } finally {
                if (oldState_0 != 0) {
                    checkForPolymorphicSpecialize(oldState_0);
                }
            }
        }

        private void checkForPolymorphicSpecialize(int oldState_0) {
            if (((oldState_0 & 0b100) == 0 && (state_0_ & 0b100) != 0)) {
                this.reportPolymorphicSpecialize();
            }
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                    GetStartIdentityData s0_ = this.getStartIdentity_cache;
                    GetStartEqualsData s1_ = this.getStartEquals_cache;
                    GetEndIdentityData s2_ = this.getEndIdentity_cache;
                    GetEndEqualsData s3_ = this.getEndEquals_cache;
                    if ((s0_ == null || s0_.next_ == null) && (s1_ == null || s1_.next_ == null) && (s2_ == null || s2_.next_ == null) && (s3_ == null || s3_.next_ == null)) {
                        return NodeCost.MONOMORPHIC;
                    }
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static InvokeCacheNode create() {
            return new InvokeCacheNodeGen();
        }

        @NeverDefault
        public static InvokeCacheNode getUncached() {
            return InvokeCacheNodeGen.UNCACHED;
        }

        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class GetStartIdentityData implements SpecializationDataNode {

            @CompilationFinal final GetStartIdentityData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InvokeCacheNode#getStartIdentity}
             *   Parameter: {@link String} cachedSymbol</pre>
             */
            @CompilationFinal String cachedSymbol_;

            GetStartIdentityData(GetStartIdentityData next_) {
                this.next_ = next_;
            }

        }
        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class GetStartEqualsData implements SpecializationDataNode {

            @CompilationFinal final GetStartEqualsData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InvokeCacheNode#getStartEquals}
             *   Parameter: {@link String} cachedSymbol</pre>
             */
            @CompilationFinal String cachedSymbol_;

            GetStartEqualsData(GetStartEqualsData next_) {
                this.next_ = next_;
            }

        }
        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class GetEndIdentityData implements SpecializationDataNode {

            @CompilationFinal final GetEndIdentityData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InvokeCacheNode#getEndIdentity}
             *   Parameter: {@link String} cachedSymbol</pre>
             */
            @CompilationFinal String cachedSymbol_;

            GetEndIdentityData(GetEndIdentityData next_) {
                this.next_ = next_;
            }

        }
        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class GetEndEqualsData implements SpecializationDataNode {

            @CompilationFinal final GetEndEqualsData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InvokeCacheNode#getEndEquals}
             *   Parameter: {@link String} cachedSymbol</pre>
             */
            @CompilationFinal String cachedSymbol_;

            GetEndEqualsData(GetEndEqualsData next_) {
                this.next_ = next_;
            }

        }
        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class Uncached extends InvokeCacheNode {

            @TruffleBoundary
            @Override
            Object execute(RegexResult arg0Value, String arg1Value, int arg2Value) throws UnknownIdentifierException {
                return InvokeCacheNode.invokeGeneric(arg0Value, arg1Value, arg2Value, (RegexResultGetStartNode.getUncached()), (RegexResultGetEndNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link RegexResultGetEndNode#doResult}
     *     Activation probability: 1.00000
     *     With/without class size: 32/9 bytes
     * </pre>
     */
    @GeneratedBy(RegexResultGetEndNode.class)
    @SuppressWarnings("javadoc")
    static final class RegexResultGetEndNodeGen extends RegexResultGetEndNode {

        private static final StateField STATE_0_RegexResultGetEndNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetEndNode#doResult}
         *   Parameter: {@link InlinedBranchProfile} lazyProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_LAZY_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_RegexResultGetEndNode_UPDATER.subUpdater(1, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetEndNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}</pre>
         */
        private static final DispatchNode INLINED_GET_INDICES_CALL_ = DispatchNodeGen.inline(InlineTarget.create(DispatchNode.class, STATE_0_RegexResultGetEndNode_UPDATER.subUpdater(2, 2), ReferenceField.create(MethodHandles.lookup(), "getIndicesCall__field1_", Node.class), ReferenceField.create(MethodHandles.lookup(), "getIndicesCall__field2_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link RegexResultGetEndNode#doResult}
         *   1: InlinedCache
         *        Specialization: {@link RegexResultGetEndNode#doResult}
         *        Parameter: {@link InlinedBranchProfile} lazyProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   2-3: InlinedCache
         *        Specialization: {@link RegexResultGetEndNode#doResult}
         *        Parameter: {@link DispatchNode} getIndicesCall
         *        Inline method: {@link DispatchNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetEndNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}
         *   Inline field: {@link Node} field1</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node getIndicesCall__field1_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetEndNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}
         *   Inline field: {@link Node} field2</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node getIndicesCall__field2_;

        private RegexResultGetEndNodeGen() {
        }

        @Override
        int execute(Object arg0Value, int arg1Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexResult.RegexResultGetEndNode.doResult(RegexResult, int, InlinedBranchProfile, DispatchNode)] */ && arg0Value instanceof RegexResult) {
                RegexResult arg0Value_ = (RegexResult) arg0Value;
                return doResult(arg0Value_, arg1Value, INLINED_LAZY_PROFILE_, INLINED_GET_INDICES_CALL_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private int executeAndSpecialize(Object arg0Value, int arg1Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof RegexResult) {
                RegexResult arg0Value_ = (RegexResult) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[RegexResult.RegexResultGetEndNode.doResult(RegexResult, int, InlinedBranchProfile, DispatchNode)] */;
                this.state_0_ = state_0;
                return doResult(arg0Value_, arg1Value, INLINED_LAZY_PROFILE_, INLINED_GET_INDICES_CALL_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static RegexResultGetEndNode create() {
            return new RegexResultGetEndNodeGen();
        }

        @NeverDefault
        public static RegexResultGetEndNode getUncached() {
            return RegexResultGetEndNodeGen.UNCACHED;
        }

        @GeneratedBy(RegexResultGetEndNode.class)
        @DenyReplace
        private static final class Uncached extends RegexResultGetEndNode {

            @TruffleBoundary
            @Override
            int execute(Object arg0Value, int arg1Value) {
                if (arg0Value instanceof RegexResult) {
                    RegexResult arg0Value_ = (RegexResult) arg0Value;
                    return doResult(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (DispatchNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link RegexResultGetStartNode#doResult}
     *     Activation probability: 1.00000
     *     With/without class size: 32/9 bytes
     * </pre>
     */
    @GeneratedBy(RegexResultGetStartNode.class)
    @SuppressWarnings("javadoc")
    public static final class RegexResultGetStartNodeGen extends RegexResultGetStartNode {

        private static final StateField STATE_0_RegexResultGetStartNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetStartNode#doResult}
         *   Parameter: {@link InlinedBranchProfile} lazyProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_LAZY_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_RegexResultGetStartNode_UPDATER.subUpdater(1, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetStartNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}</pre>
         */
        private static final DispatchNode INLINED_GET_INDICES_CALL_ = DispatchNodeGen.inline(InlineTarget.create(DispatchNode.class, STATE_0_RegexResultGetStartNode_UPDATER.subUpdater(2, 2), ReferenceField.create(MethodHandles.lookup(), "getIndicesCall__field1_", Node.class), ReferenceField.create(MethodHandles.lookup(), "getIndicesCall__field2_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link RegexResultGetStartNode#doResult}
         *   1: InlinedCache
         *        Specialization: {@link RegexResultGetStartNode#doResult}
         *        Parameter: {@link InlinedBranchProfile} lazyProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   2-3: InlinedCache
         *        Specialization: {@link RegexResultGetStartNode#doResult}
         *        Parameter: {@link DispatchNode} getIndicesCall
         *        Inline method: {@link DispatchNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetStartNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}
         *   Inline field: {@link Node} field1</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node getIndicesCall__field1_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetStartNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}
         *   Inline field: {@link Node} field2</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node getIndicesCall__field2_;

        private RegexResultGetStartNodeGen() {
        }

        @Override
        public int execute(Object arg0Value, int arg1Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexResult.RegexResultGetStartNode.doResult(RegexResult, int, InlinedBranchProfile, DispatchNode)] */ && arg0Value instanceof RegexResult) {
                RegexResult arg0Value_ = (RegexResult) arg0Value;
                return doResult(arg0Value_, arg1Value, INLINED_LAZY_PROFILE_, INLINED_GET_INDICES_CALL_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private int executeAndSpecialize(Object arg0Value, int arg1Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof RegexResult) {
                RegexResult arg0Value_ = (RegexResult) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[RegexResult.RegexResultGetStartNode.doResult(RegexResult, int, InlinedBranchProfile, DispatchNode)] */;
                this.state_0_ = state_0;
                return doResult(arg0Value_, arg1Value, INLINED_LAZY_PROFILE_, INLINED_GET_INDICES_CALL_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static RegexResultGetStartNode create() {
            return new RegexResultGetStartNodeGen();
        }

        @NeverDefault
        public static RegexResultGetStartNode getUncached() {
            return RegexResultGetStartNodeGen.UNCACHED;
        }

        @GeneratedBy(RegexResultGetStartNode.class)
        @DenyReplace
        private static final class Uncached extends RegexResultGetStartNode {

            @TruffleBoundary
            @Override
            public int execute(Object arg0Value, int arg1Value) {
                if (arg0Value instanceof RegexResult) {
                    RegexResult arg0Value_ = (RegexResult) arg0Value;
                    return doResult(arg0Value_, arg1Value, (InlinedBranchProfile.getUncached()), (DispatchNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link RegexResultGetLastGroupNode#doResult}
     *     Activation probability: 1.00000
     *     With/without class size: 32/9 bytes
     * </pre>
     */
    @GeneratedBy(RegexResultGetLastGroupNode.class)
    @SuppressWarnings("javadoc")
    public static final class RegexResultGetLastGroupNodeGen extends RegexResultGetLastGroupNode {

        private static final StateField STATE_0_RegexResultGetLastGroupNode_UPDATER = StateField.create(MethodHandles.lookup(), "state_0_");
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetLastGroupNode#doResult}
         *   Parameter: {@link InlinedBranchProfile} lazyProfile
         *   Inline method: {@link InlinedBranchProfile#inline}</pre>
         */
        private static final InlinedBranchProfile INLINED_LAZY_PROFILE_ = InlinedBranchProfile.inline(InlineTarget.create(InlinedBranchProfile.class, STATE_0_RegexResultGetLastGroupNode_UPDATER.subUpdater(1, 1)));
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetLastGroupNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}</pre>
         */
        private static final DispatchNode INLINED_GET_INDICES_CALL_ = DispatchNodeGen.inline(InlineTarget.create(DispatchNode.class, STATE_0_RegexResultGetLastGroupNode_UPDATER.subUpdater(2, 2), ReferenceField.create(MethodHandles.lookup(), "getIndicesCall__field1_", Node.class), ReferenceField.create(MethodHandles.lookup(), "getIndicesCall__field2_", Node.class)));
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link RegexResultGetLastGroupNode#doResult}
         *   1: InlinedCache
         *        Specialization: {@link RegexResultGetLastGroupNode#doResult}
         *        Parameter: {@link InlinedBranchProfile} lazyProfile
         *        Inline method: {@link InlinedBranchProfile#inline}
         *   2-3: InlinedCache
         *        Specialization: {@link RegexResultGetLastGroupNode#doResult}
         *        Parameter: {@link DispatchNode} getIndicesCall
         *        Inline method: {@link DispatchNodeGen#inline}
         * </pre>
         */
        @CompilationFinal @UnsafeAccessedField private int state_0_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetLastGroupNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}
         *   Inline field: {@link Node} field1</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node getIndicesCall__field1_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link RegexResultGetLastGroupNode#doResult}
         *   Parameter: {@link DispatchNode} getIndicesCall
         *   Inline method: {@link DispatchNodeGen#inline}
         *   Inline field: {@link Node} field2</pre>
         */
        @Child @UnsafeAccessedField @SuppressWarnings("unused") private Node getIndicesCall__field2_;

        private RegexResultGetLastGroupNodeGen() {
        }

        @Override
        public int execute(Object arg0Value) {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexResult.RegexResultGetLastGroupNode.doResult(RegexResult, InlinedBranchProfile, DispatchNode)] */ && arg0Value instanceof RegexResult) {
                RegexResult arg0Value_ = (RegexResult) arg0Value;
                return doResult(arg0Value_, INLINED_LAZY_PROFILE_, INLINED_GET_INDICES_CALL_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private int executeAndSpecialize(Object arg0Value) {
            int state_0 = this.state_0_;
            if (arg0Value instanceof RegexResult) {
                RegexResult arg0Value_ = (RegexResult) arg0Value;
                state_0 = state_0 | 0b1 /* add SpecializationActive[RegexResult.RegexResultGetLastGroupNode.doResult(RegexResult, InlinedBranchProfile, DispatchNode)] */;
                this.state_0_ = state_0;
                return doResult(arg0Value_, INLINED_LAZY_PROFILE_, INLINED_GET_INDICES_CALL_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if ((state_0 & 0b1) == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        @NeverDefault
        public static RegexResultGetLastGroupNode create() {
            return new RegexResultGetLastGroupNodeGen();
        }

        @NeverDefault
        public static RegexResultGetLastGroupNode getUncached() {
            return RegexResultGetLastGroupNodeGen.UNCACHED;
        }

        @GeneratedBy(RegexResultGetLastGroupNode.class)
        @DenyReplace
        private static final class Uncached extends RegexResultGetLastGroupNode {

            @TruffleBoundary
            @Override
            public int execute(Object arg0Value) {
                if (arg0Value instanceof RegexResult) {
                    RegexResult arg0Value_ = (RegexResult) arg0Value;
                    return doResult(arg0Value_, (InlinedBranchProfile.getUncached()), (DispatchNodeGen.getUncached()));
                }
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
}
