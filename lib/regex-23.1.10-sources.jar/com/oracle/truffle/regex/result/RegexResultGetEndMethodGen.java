// CheckStyle: start generated
package com.oracle.truffle.regex.result;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.interop.ArityException;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.interop.UnsupportedMessageException;
import com.oracle.truffle.api.interop.UnsupportedTypeException;
import com.oracle.truffle.api.library.LibraryExport;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.regex.AbstractRegexObjectGen;
import com.oracle.truffle.regex.result.RegexResult.RegexResultGetEndMethod;
import com.oracle.truffle.regex.result.RegexResult.RegexResultGetEndNode;
import com.oracle.truffle.regex.result.RegexResultFactory.RegexResultGetEndNodeGen;
import com.oracle.truffle.regex.runtime.nodes.ToIntNode;
import com.oracle.truffle.regex.runtime.nodes.ToIntNodeGen;
import java.lang.invoke.VarHandle;
import java.util.Objects;

@GeneratedBy(RegexResultGetEndMethod.class)
@SuppressWarnings("javadoc")
final class RegexResultGetEndMethodGen {

    static  {
        LibraryExport.register(RegexResultGetEndMethod.class, new InteropLibraryExports());
    }

    private RegexResultGetEndMethodGen() {
    }

    @GeneratedBy(RegexResultGetEndMethod.class)
    private static final class InteropLibraryExports extends LibraryExport<InteropLibrary> {

        private InteropLibraryExports() {
            super(InteropLibrary.class, RegexResultGetEndMethod.class, false, false, 0);
        }

        @Override
        protected InteropLibrary createUncached(Object receiver) {
            assert receiver instanceof RegexResultGetEndMethod;
            InteropLibrary uncached = new Uncached(receiver);
            return uncached;
        }

        @Override
        protected InteropLibrary createCached(Object receiver) {
            assert receiver instanceof RegexResultGetEndMethod;
            return new Cached(receiver);
        }

        @GeneratedBy(RegexResultGetEndMethod.class)
        private static final class Cached extends AbstractRegexObjectGen.InteropLibraryExports.Cached {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link RegexResultGetEndMethod#execute(RegexResultGetEndMethod, Object[], ToIntNode, RegexResultGetEndNode)}
             * </pre>
             */
            @CompilationFinal private int state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link RegexResultGetEndMethod#execute(RegexResultGetEndMethod, Object[], ToIntNode, RegexResultGetEndNode)}
             *   Parameter: {@link ToIntNode} toIntNode</pre>
             */
            @Child private ToIntNode toIntNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link RegexResultGetEndMethod#execute(RegexResultGetEndMethod, Object[], ToIntNode, RegexResultGetEndNode)}
             *   Parameter: {@link RegexResultGetEndNode} getEndNode</pre>
             */
            @Child private RegexResultGetEndNode getEndNode_;

            protected Cached(Object receiver) {
                super(receiver);
            }

            @Override
            public boolean isExecutable(Object receiver) {
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                return (((RegexResultGetEndMethod) receiver)).isExecutable();
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link RegexResultGetEndMethod#execute(RegexResultGetEndMethod, Object[], ToIntNode, RegexResultGetEndNode)}
             *     Activation probability: 1.00000
             *     With/without class size: 28/8 bytes
             * </pre>
             */
            @Override
            public Object execute(Object arg0Value_, Object... arg1Value) throws UnsupportedTypeException, ArityException, UnsupportedMessageException {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexResultGetEndMethod arg0Value = ((RegexResultGetEndMethod) arg0Value_);
                int state_0 = this.state_0_;
                if (state_0 != 0 /* is SpecializationActive[RegexResultGetEndMethod.execute(RegexResultGetEndMethod, Object[], ToIntNode, RegexResultGetEndNode)] */) {
                    {
                        ToIntNode toIntNode__ = this.toIntNode_;
                        if (toIntNode__ != null) {
                            RegexResultGetEndNode getEndNode__ = this.getEndNode_;
                            if (getEndNode__ != null) {
                                return arg0Value.execute(arg1Value, toIntNode__, getEndNode__);
                            }
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value);
            }

            private int executeAndSpecialize(RegexResultGetEndMethod arg0Value, Object[] arg1Value) throws ArityException, UnsupportedTypeException {
                int state_0 = this.state_0_;
                ToIntNode toIntNode__ = this.insert((ToIntNodeGen.create()));
                Objects.requireNonNull(toIntNode__, "Specialization 'execute(RegexResultGetEndMethod, Object[], ToIntNode, RegexResultGetEndNode)' cache 'toIntNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.toIntNode_ = toIntNode__;
                RegexResultGetEndNode getEndNode__ = this.insert((RegexResultGetEndNodeGen.create()));
                Objects.requireNonNull(getEndNode__, "Specialization 'execute(RegexResultGetEndMethod, Object[], ToIntNode, RegexResultGetEndNode)' cache 'getEndNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.getEndNode_ = getEndNode__;
                state_0 = state_0 | 0b1 /* add SpecializationActive[RegexResultGetEndMethod.execute(RegexResultGetEndMethod, Object[], ToIntNode, RegexResultGetEndNode)] */;
                this.state_0_ = state_0;
                return arg0Value.execute(arg1Value, toIntNode__, getEndNode__);
            }

            @Override
            public NodeCost getCost() {
                int state_0 = this.state_0_;
                if (state_0 == 0) {
                    return NodeCost.UNINITIALIZED;
                } else {
                    return NodeCost.MONOMORPHIC;
                }
            }

        }
        @GeneratedBy(RegexResultGetEndMethod.class)
        @DenyReplace
        private static final class Uncached extends AbstractRegexObjectGen.InteropLibraryExports.Uncached {

            protected Uncached(Object receiver) {
                super(receiver);
            }

            @Override
            @TruffleBoundary
            public boolean accepts(Object receiver) {
                return super.accepts(receiver);
            }

            @TruffleBoundary
            @Override
            public boolean isExecutable(Object receiver) {
                // declared: true
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                return ((RegexResultGetEndMethod) receiver) .isExecutable();
            }

            @TruffleBoundary
            @Override
            public Object execute(Object arg0Value_, Object... arg1Value) throws ArityException, UnsupportedTypeException {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexResultGetEndMethod arg0Value = ((RegexResultGetEndMethod) arg0Value_);
                return arg0Value.execute(arg1Value, (ToIntNodeGen.getUncached()), (RegexResultGetEndNodeGen.getUncached()));
            }

        }
    }
}
