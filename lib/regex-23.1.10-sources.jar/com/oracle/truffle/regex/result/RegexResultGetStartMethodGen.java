// CheckStyle: start generated
package com.oracle.truffle.regex.result;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.interop.ArityException;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.interop.UnsupportedMessageException;
import com.oracle.truffle.api.interop.UnsupportedTypeException;
import com.oracle.truffle.api.library.LibraryExport;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.regex.AbstractRegexObjectGen;
import com.oracle.truffle.regex.result.RegexResult.RegexResultGetStartMethod;
import com.oracle.truffle.regex.result.RegexResult.RegexResultGetStartNode;
import com.oracle.truffle.regex.result.RegexResultFactory.RegexResultGetStartNodeGen;
import com.oracle.truffle.regex.runtime.nodes.ToIntNode;
import com.oracle.truffle.regex.runtime.nodes.ToIntNodeGen;
import java.lang.invoke.VarHandle;
import java.util.Objects;

@GeneratedBy(RegexResultGetStartMethod.class)
@SuppressWarnings("javadoc")
final class RegexResultGetStartMethodGen {

    static  {
        LibraryExport.register(RegexResultGetStartMethod.class, new InteropLibraryExports());
    }

    private RegexResultGetStartMethodGen() {
    }

    @GeneratedBy(RegexResultGetStartMethod.class)
    private static final class InteropLibraryExports extends LibraryExport<InteropLibrary> {

        private InteropLibraryExports() {
            super(InteropLibrary.class, RegexResultGetStartMethod.class, false, false, 0);
        }

        @Override
        protected InteropLibrary createUncached(Object receiver) {
            assert receiver instanceof RegexResultGetStartMethod;
            InteropLibrary uncached = new Uncached(receiver);
            return uncached;
        }

        @Override
        protected InteropLibrary createCached(Object receiver) {
            assert receiver instanceof RegexResultGetStartMethod;
            return new Cached(receiver);
        }

        @GeneratedBy(RegexResultGetStartMethod.class)
        private static final class Cached extends AbstractRegexObjectGen.InteropLibraryExports.Cached {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link RegexResultGetStartMethod#execute(RegexResultGetStartMethod, Object[], ToIntNode, RegexResultGetStartNode)}
             * </pre>
             */
            @CompilationFinal private int state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link RegexResultGetStartMethod#execute(RegexResultGetStartMethod, Object[], ToIntNode, RegexResultGetStartNode)}
             *   Parameter: {@link ToIntNode} toIntNode</pre>
             */
            @Child private ToIntNode toIntNode_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link RegexResultGetStartMethod#execute(RegexResultGetStartMethod, Object[], ToIntNode, RegexResultGetStartNode)}
             *   Parameter: {@link RegexResultGetStartNode} getStartNode</pre>
             */
            @Child private RegexResultGetStartNode getStartNode_;

            protected Cached(Object receiver) {
                super(receiver);
            }

            @Override
            public boolean isExecutable(Object receiver) {
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                return (((RegexResultGetStartMethod) receiver)).isExecutable();
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link RegexResultGetStartMethod#execute(RegexResultGetStartMethod, Object[], ToIntNode, RegexResultGetStartNode)}
             *     Activation probability: 1.00000
             *     With/without class size: 28/8 bytes
             * </pre>
             */
            @Override
            public Object execute(Object arg0Value_, Object... arg1Value) throws UnsupportedTypeException, ArityException, UnsupportedMessageException {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexResultGetStartMethod arg0Value = ((RegexResultGetStartMethod) arg0Value_);
                int state_0 = this.state_0_;
                if (state_0 != 0 /* is SpecializationActive[RegexResultGetStartMethod.execute(RegexResultGetStartMethod, Object[], ToIntNode, RegexResultGetStartNode)] */) {
                    {
                        ToIntNode toIntNode__ = this.toIntNode_;
                        if (toIntNode__ != null) {
                            RegexResultGetStartNode getStartNode__ = this.getStartNode_;
                            if (getStartNode__ != null) {
                                return arg0Value.execute(arg1Value, toIntNode__, getStartNode__);
                            }
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value);
            }

            private int executeAndSpecialize(RegexResultGetStartMethod arg0Value, Object[] arg1Value) throws ArityException, UnsupportedTypeException {
                int state_0 = this.state_0_;
                ToIntNode toIntNode__ = this.insert((ToIntNodeGen.create()));
                Objects.requireNonNull(toIntNode__, "Specialization 'execute(RegexResultGetStartMethod, Object[], ToIntNode, RegexResultGetStartNode)' cache 'toIntNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.toIntNode_ = toIntNode__;
                RegexResultGetStartNode getStartNode__ = this.insert((RegexResultGetStartNodeGen.create()));
                Objects.requireNonNull(getStartNode__, "Specialization 'execute(RegexResultGetStartMethod, Object[], ToIntNode, RegexResultGetStartNode)' cache 'getStartNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.getStartNode_ = getStartNode__;
                state_0 = state_0 | 0b1 /* add SpecializationActive[RegexResultGetStartMethod.execute(RegexResultGetStartMethod, Object[], ToIntNode, RegexResultGetStartNode)] */;
                this.state_0_ = state_0;
                return arg0Value.execute(arg1Value, toIntNode__, getStartNode__);
            }

            @Override
            public NodeCost getCost() {
                int state_0 = this.state_0_;
                if (state_0 == 0) {
                    return NodeCost.UNINITIALIZED;
                } else {
                    return NodeCost.MONOMORPHIC;
                }
            }

        }
        @GeneratedBy(RegexResultGetStartMethod.class)
        @DenyReplace
        private static final class Uncached extends AbstractRegexObjectGen.InteropLibraryExports.Uncached {

            protected Uncached(Object receiver) {
                super(receiver);
            }

            @Override
            @TruffleBoundary
            public boolean accepts(Object receiver) {
                return super.accepts(receiver);
            }

            @TruffleBoundary
            @Override
            public boolean isExecutable(Object receiver) {
                // declared: true
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                return ((RegexResultGetStartMethod) receiver) .isExecutable();
            }

            @TruffleBoundary
            @Override
            public Object execute(Object arg0Value_, Object... arg1Value) throws ArityException, UnsupportedTypeException {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexResultGetStartMethod arg0Value = ((RegexResultGetStartMethod) arg0Value_);
                return arg0Value.execute(arg1Value, (ToIntNodeGen.getUncached()), (RegexResultGetStartNode.getUncached()));
            }

        }
    }
}
