// CheckStyle: start generated
package com.oracle.truffle.regex;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.DSLSupport;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.interop.ArityException;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.interop.UnknownIdentifierException;
import com.oracle.truffle.api.interop.UnsupportedMessageException;
import com.oracle.truffle.api.interop.UnsupportedTypeException;
import com.oracle.truffle.api.library.LibraryExport;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.profiles.ValueProfile;
import com.oracle.truffle.regex.AbstractConstantKeysObject.IsMemberReadable;
import com.oracle.truffle.regex.RegexObject.InvokeCacheNode;
import com.oracle.truffle.regex.RegexObject.IsMemberInvocable;
import com.oracle.truffle.regex.RegexObjectFactory.InvokeCacheNodeGen;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.Objects;

@GeneratedBy(RegexObject.class)
@SuppressWarnings("javadoc")
final class RegexObjectGen {

    static  {
        LibraryExport.register(RegexObject.class, new InteropLibraryExports());
    }

    private RegexObjectGen() {
    }

    @GeneratedBy(RegexObject.class)
    private static final class InteropLibraryExports extends LibraryExport<InteropLibrary> {

        private InteropLibraryExports() {
            super(InteropLibrary.class, RegexObject.class, false, false, 0);
        }

        @Override
        protected InteropLibrary createUncached(Object receiver) {
            assert receiver instanceof RegexObject;
            InteropLibrary uncached = new Uncached(receiver);
            return uncached;
        }

        @Override
        protected InteropLibrary createCached(Object receiver) {
            assert receiver instanceof RegexObject;
            return new Cached(receiver);
        }

        @GeneratedBy(RegexObject.class)
        private static final class Cached extends AbstractConstantKeysObjectGen.InteropLibraryExports.Cached {

            static final ReferenceField<IsMemberInvocableCacheIdentityData> IS_MEMBER_INVOCABLE_CACHE_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "isMemberInvocable_cacheIdentity_cache", IsMemberInvocableCacheIdentityData.class);
            static final ReferenceField<IsMemberInvocableCacheEqualsData> IS_MEMBER_INVOCABLE_CACHE_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "isMemberInvocable_cacheEquals_cache", IsMemberInvocableCacheEqualsData.class);

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link IsMemberInvocable#cacheIdentity}
             *   1: SpecializationActive {@link IsMemberInvocable#cacheEquals}
             *   2: SpecializationActive {@link IsMemberInvocable#isInvocable}
             *   3: SpecializationActive {@link RegexObject#invokeMember(RegexObject, String, Object[], InvokeCacheNode)}
             * </pre>
             */
            @CompilationFinal private int state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link IsMemberReadable#isReadable}
             *   Parameter: {@link ValueProfile} classProfile</pre>
             */
            @CompilationFinal private ValueProfile classProfile;
            @UnsafeAccessedField @CompilationFinal private IsMemberInvocableCacheIdentityData isMemberInvocable_cacheIdentity_cache;
            @UnsafeAccessedField @CompilationFinal private IsMemberInvocableCacheEqualsData isMemberInvocable_cacheEquals_cache;
            /**
             * Source Info: <pre>
             *   Specialization: {@link RegexObject#invokeMember(RegexObject, String, Object[], InvokeCacheNode)}
             *   Parameter: {@link InvokeCacheNode} invokeCache</pre>
             */
            @Child private InvokeCacheNode invokeMemberNode__invokeMember_invokeCache_;

            protected Cached(Object receiver) {
                super(receiver);
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link IsMemberInvocable#cacheIdentity}
             *     Activation probability: 0.12083
             *     With/without class size: 6/5 bytes
             *   Specialization {@link IsMemberInvocable#cacheEquals}
             *     Activation probability: 0.08333
             *     With/without class size: 5/5 bytes
             *   Specialization {@link IsMemberInvocable#isInvocable}
             *     Activation probability: 0.04583
             *     With/without class size: 4/0 bytes
             * </pre>
             */
            @ExplodeLoop
            @Override
            public boolean isMemberInvocable(Object arg0Value_, String arg1Value) {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexObject arg0Value = ((RegexObject) arg0Value_);
                int state_0 = this.state_0_;
                if ((state_0 & 0b111) != 0 /* is SpecializationActive[RegexObject.IsMemberInvocable.cacheIdentity(RegexObject, String, String, boolean)] || SpecializationActive[RegexObject.IsMemberInvocable.cacheEquals(RegexObject, String, String, boolean)] || SpecializationActive[RegexObject.IsMemberInvocable.isInvocable(RegexObject, String)] */) {
                    if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexObject.IsMemberInvocable.cacheIdentity(RegexObject, String, String, boolean)] */) {
                        IsMemberInvocableCacheIdentityData s0_ = this.isMemberInvocable_cacheIdentity_cache;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s0_.result_));
                                return IsMemberInvocable.cacheIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.result_);
                            }
                            s0_ = s0_.next_;
                        }
                    }
                    if ((state_0 & 0b10) != 0 /* is SpecializationActive[RegexObject.IsMemberInvocable.cacheEquals(RegexObject, String, String, boolean)] */) {
                        IsMemberInvocableCacheEqualsData s1_ = this.isMemberInvocable_cacheEquals_cache;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s1_.result_));
                                return IsMemberInvocable.cacheEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.result_);
                            }
                            s1_ = s1_.next_;
                        }
                    }
                    if ((state_0 & 0b100) != 0 /* is SpecializationActive[RegexObject.IsMemberInvocable.isInvocable(RegexObject, String)] */) {
                        return IsMemberInvocable.isInvocable(arg0Value, arg1Value);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return isMemberInvocableAndSpecialize(arg0Value, arg1Value);
            }

            private boolean isMemberInvocableAndSpecialize(RegexObject arg0Value, String arg1Value) {
                int state_0 = this.state_0_;
                if (((state_0 & 0b110)) == 0 /* is-not SpecializationActive[RegexObject.IsMemberInvocable.cacheEquals(RegexObject, String, String, boolean)] && SpecializationActive[RegexObject.IsMemberInvocable.isInvocable(RegexObject, String)] */) {
                    while (true) {
                        int count0_ = 0;
                        IsMemberInvocableCacheIdentityData s0_ = IS_MEMBER_INVOCABLE_CACHE_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        IsMemberInvocableCacheIdentityData s0_original = s0_;
                        while (s0_ != null) {
                            if ((arg1Value == s0_.cachedSymbol_)) {
                                assert DSLSupport.assertIdempotence((s0_.result_));
                                break;
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            {
                                String cachedSymbol__ = (arg1Value);
                                boolean result__ = (IsMemberInvocable.isInvocable(arg0Value, cachedSymbol__));
                                // assert (arg1Value == s0_.cachedSymbol_);
                                if ((result__) && count0_ < (2)) {
                                    s0_ = new IsMemberInvocableCacheIdentityData(s0_original);
                                    s0_.cachedSymbol_ = cachedSymbol__;
                                    s0_.result_ = result__;
                                    if (!IS_MEMBER_INVOCABLE_CACHE_IDENTITY_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                        continue;
                                    }
                                    state_0 = state_0 | 0b1 /* add SpecializationActive[RegexObject.IsMemberInvocable.cacheIdentity(RegexObject, String, String, boolean)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s0_ != null) {
                            return IsMemberInvocable.cacheIdentity(arg0Value, arg1Value, s0_.cachedSymbol_, s0_.result_);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100)) == 0 /* is-not SpecializationActive[RegexObject.IsMemberInvocable.isInvocable(RegexObject, String)] */) {
                    while (true) {
                        int count1_ = 0;
                        IsMemberInvocableCacheEqualsData s1_ = IS_MEMBER_INVOCABLE_CACHE_EQUALS_CACHE_UPDATER.getVolatile(this);
                        IsMemberInvocableCacheEqualsData s1_original = s1_;
                        while (s1_ != null) {
                            if ((arg1Value.equals(s1_.cachedSymbol_))) {
                                assert DSLSupport.assertIdempotence((s1_.result_));
                                break;
                            }
                            count1_++;
                            s1_ = s1_.next_;
                        }
                        if (s1_ == null) {
                            {
                                String cachedSymbol__1 = (arg1Value);
                                boolean result__1 = (IsMemberInvocable.isInvocable(arg0Value, cachedSymbol__1));
                                // assert (arg1Value.equals(s1_.cachedSymbol_));
                                if ((result__1) && count1_ < (2)) {
                                    s1_ = new IsMemberInvocableCacheEqualsData(s1_original);
                                    s1_.cachedSymbol_ = cachedSymbol__1;
                                    s1_.result_ = result__1;
                                    if (!IS_MEMBER_INVOCABLE_CACHE_EQUALS_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                        continue;
                                    }
                                    this.isMemberInvocable_cacheIdentity_cache = null;
                                    state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[RegexObject.IsMemberInvocable.cacheIdentity(RegexObject, String, String, boolean)] */;
                                    state_0 = state_0 | 0b10 /* add SpecializationActive[RegexObject.IsMemberInvocable.cacheEquals(RegexObject, String, String, boolean)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s1_ != null) {
                            return IsMemberInvocable.cacheEquals(arg0Value, arg1Value, s1_.cachedSymbol_, s1_.result_);
                        }
                        break;
                    }
                }
                this.isMemberInvocable_cacheIdentity_cache = null;
                this.isMemberInvocable_cacheEquals_cache = null;
                state_0 = state_0 & 0xfffffffc /* remove SpecializationActive[RegexObject.IsMemberInvocable.cacheIdentity(RegexObject, String, String, boolean)], SpecializationActive[RegexObject.IsMemberInvocable.cacheEquals(RegexObject, String, String, boolean)] */;
                state_0 = state_0 | 0b100 /* add SpecializationActive[RegexObject.IsMemberInvocable.isInvocable(RegexObject, String)] */;
                this.state_0_ = state_0;
                return IsMemberInvocable.isInvocable(arg0Value, arg1Value);
            }

            @Override
            public NodeCost getCost() {
                int state_0 = this.state_0_;
                if ((state_0 & 0b111) == 0) {
                    return NodeCost.UNINITIALIZED;
                } else {
                    if (((state_0 & 0b111) & ((state_0 & 0b111) - 1)) == 0 /* is-single  */) {
                        IsMemberInvocableCacheIdentityData s0_ = this.isMemberInvocable_cacheIdentity_cache;
                        IsMemberInvocableCacheEqualsData s1_ = this.isMemberInvocable_cacheEquals_cache;
                        if ((s0_ == null || s0_.next_ == null) && (s1_ == null || s1_.next_ == null)) {
                            return NodeCost.MONOMORPHIC;
                        }
                    }
                }
                return NodeCost.POLYMORPHIC;
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link RegexObject#invokeMember(RegexObject, String, Object[], InvokeCacheNode)}
             *     Activation probability: 0.25000
             *     With/without class size: 9/4 bytes
             * </pre>
             */
            @Override
            public Object invokeMember(Object arg0Value_, String arg1Value, Object... arg2Value) throws UnsupportedMessageException, ArityException, UnknownIdentifierException, UnsupportedTypeException {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexObject arg0Value = ((RegexObject) arg0Value_);
                int state_0 = this.state_0_;
                if ((state_0 & 0b1000) != 0 /* is SpecializationActive[RegexObject.invokeMember(RegexObject, String, Object[], InvokeCacheNode)] */) {
                    {
                        InvokeCacheNode invokeCache__ = this.invokeMemberNode__invokeMember_invokeCache_;
                        if (invokeCache__ != null) {
                            return arg0Value.invokeMember(arg1Value, arg2Value, invokeCache__);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return invokeMemberNode_AndSpecialize(arg0Value, arg1Value, arg2Value);
            }

            private Object invokeMemberNode_AndSpecialize(RegexObject arg0Value, String arg1Value, Object[] arg2Value) throws UnknownIdentifierException, ArityException, UnsupportedTypeException, UnsupportedMessageException {
                int state_0 = this.state_0_;
                InvokeCacheNode invokeCache__ = this.insert((InvokeCacheNodeGen.create()));
                Objects.requireNonNull(invokeCache__, "Specialization 'invokeMember(RegexObject, String, Object[], InvokeCacheNode)' cache 'invokeCache' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.invokeMemberNode__invokeMember_invokeCache_ = invokeCache__;
                state_0 = state_0 | 0b1000 /* add SpecializationActive[RegexObject.invokeMember(RegexObject, String, Object[], InvokeCacheNode)] */;
                this.state_0_ = state_0;
                return arg0Value.invokeMember(arg1Value, arg2Value, invokeCache__);
            }

            @GeneratedBy(RegexObject.class)
            @DenyReplace
            private static final class IsMemberInvocableCacheIdentityData implements SpecializationDataNode {

                @CompilationFinal final IsMemberInvocableCacheIdentityData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberInvocable#cacheIdentity}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberInvocable#cacheIdentity}
                 *   Parameter: boolean result</pre>
                 */
                @CompilationFinal boolean result_;

                IsMemberInvocableCacheIdentityData(IsMemberInvocableCacheIdentityData next_) {
                    this.next_ = next_;
                }

            }
            @GeneratedBy(RegexObject.class)
            @DenyReplace
            private static final class IsMemberInvocableCacheEqualsData implements SpecializationDataNode {

                @CompilationFinal final IsMemberInvocableCacheEqualsData next_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberInvocable#cacheEquals}
                 *   Parameter: {@link String} cachedSymbol</pre>
                 */
                @CompilationFinal String cachedSymbol_;
                /**
                 * Source Info: <pre>
                 *   Specialization: {@link IsMemberInvocable#cacheEquals}
                 *   Parameter: boolean result</pre>
                 */
                @CompilationFinal boolean result_;

                IsMemberInvocableCacheEqualsData(IsMemberInvocableCacheEqualsData next_) {
                    this.next_ = next_;
                }

            }
        }
        @GeneratedBy(RegexObject.class)
        @DenyReplace
        private static final class Uncached extends AbstractConstantKeysObjectGen.InteropLibraryExports.Uncached {

            protected Uncached(Object receiver) {
                super(receiver);
            }

            @Override
            @TruffleBoundary
            public boolean accepts(Object receiver) {
                return super.accepts(receiver);
            }

            @TruffleBoundary
            @Override
            public boolean isMemberInvocable(Object arg0Value_, String arg1Value) {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexObject arg0Value = ((RegexObject) arg0Value_);
                return IsMemberInvocable.isInvocable(arg0Value, arg1Value);
            }

            @TruffleBoundary
            @Override
            public Object invokeMember(Object arg0Value_, String arg1Value, Object... arg2Value) throws UnknownIdentifierException, ArityException, UnsupportedTypeException, UnsupportedMessageException {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexObject arg0Value = ((RegexObject) arg0Value_);
                return arg0Value.invokeMember(arg1Value, arg2Value, (InvokeCacheNodeGen.getUncached()));
            }

        }
    }
}
