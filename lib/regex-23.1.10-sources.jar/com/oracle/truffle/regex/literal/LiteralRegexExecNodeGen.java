// CheckStyle: start generated
package com.oracle.truffle.regex.literal;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.strings.TruffleString;
import com.oracle.truffle.regex.RegexLanguage;
import com.oracle.truffle.regex.result.RegexResult;
import com.oracle.truffle.regex.tregex.parser.ast.RegexAST;
import com.oracle.truffle.regex.tregex.parser.ast.visitors.PreCalcResultVisitor;
import com.oracle.truffle.regex.tregex.string.Encodings.Encoding;

/**
 * Debug Info: <pre>
 *   Specialization {@link LiteralRegexExecNode#doTString}
 *     Activation probability: 1.00000
 *     With/without class size: 16/0 bytes
 * </pre>
 */
@GeneratedBy(LiteralRegexExecNode.class)
@SuppressWarnings("javadoc")
public final class LiteralRegexExecNodeGen extends LiteralRegexExecNode {

    private LiteralRegexExecNodeGen(RegexLanguage language, RegexAST ast, LiteralRegexExecImplNode implNode) {
        super(language, ast, implNode);
    }

    @Override
    public RegexResult execute(VirtualFrame frameValue, TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value) {
        return doTString(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value);
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    @NeverDefault
    public static LiteralRegexExecNode create(RegexLanguage language, RegexAST ast, LiteralRegexExecImplNode implNode) {
        return new LiteralRegexExecNodeGen(language, ast, implNode);
    }

    /**
     * Debug Info: <pre>
     *   Specialization {@link IndexOfString#run}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(IndexOfString.class)
    @SuppressWarnings("javadoc")
    public static final class IndexOfStringNodeGen extends IndexOfString {

        private IndexOfStringNodeGen(PreCalcResultVisitor preCalcResultVisitor) {
            super(preCalcResultVisitor);
        }

        @Override
        RegexResult execute(TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            return run(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static IndexOfString create(PreCalcResultVisitor preCalcResultVisitor) {
            return new IndexOfStringNodeGen(preCalcResultVisitor);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link StartsWith#run}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(StartsWith.class)
    @SuppressWarnings("javadoc")
    public static final class StartsWithNodeGen extends StartsWith {

        private StartsWithNodeGen(PreCalcResultVisitor preCalcResultVisitor) {
            super(preCalcResultVisitor);
        }

        @Override
        RegexResult execute(TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            return run(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static StartsWith create(PreCalcResultVisitor preCalcResultVisitor) {
            return new StartsWithNodeGen(preCalcResultVisitor);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link EndsWith#run}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(EndsWith.class)
    @SuppressWarnings("javadoc")
    public static final class EndsWithNodeGen extends EndsWith {

        private EndsWithNodeGen(PreCalcResultVisitor preCalcResultVisitor, boolean sticky) {
            super(preCalcResultVisitor, sticky);
        }

        @Override
        RegexResult execute(TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            return run(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static EndsWith create(PreCalcResultVisitor preCalcResultVisitor, boolean sticky) {
            return new EndsWithNodeGen(preCalcResultVisitor, sticky);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link Equals#run}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(Equals.class)
    @SuppressWarnings("javadoc")
    public static final class EqualsNodeGen extends Equals {

        private EqualsNodeGen(PreCalcResultVisitor preCalcResultVisitor) {
            super(preCalcResultVisitor);
        }

        @Override
        RegexResult execute(TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            return run(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static Equals create(PreCalcResultVisitor preCalcResultVisitor) {
            return new EqualsNodeGen(preCalcResultVisitor);
        }

    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link RegionMatches#run}
     *     Activation probability: 1.00000
     *     With/without class size: 16/0 bytes
     * </pre>
     */
    @GeneratedBy(RegionMatches.class)
    @SuppressWarnings("javadoc")
    public static final class RegionMatchesNodeGen extends RegionMatches {

        private RegionMatchesNodeGen(PreCalcResultVisitor preCalcResultVisitor) {
            super(preCalcResultVisitor);
        }

        @Override
        RegexResult execute(TruffleString arg0Value, int arg1Value, int arg2Value, int arg3Value, int arg4Value, Encoding arg5Value) {
            return run(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MONOMORPHIC;
        }

        @NeverDefault
        public static RegionMatches create(PreCalcResultVisitor preCalcResultVisitor) {
            return new RegionMatchesNodeGen(preCalcResultVisitor);
        }

    }
}
