// CheckStyle: start generated
package com.oracle.truffle.regex.runtime.nodes;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.library.LibraryFactory;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.EncapsulatingNodeReference;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import java.lang.invoke.MethodHandles;
import java.util.Objects;

/**
 * Debug Info: <pre>
 *   Specialization {@link ToLongNode#doPrimitiveInt}
 *     Activation probability: 0.38500
 *     With/without class size: 8/0 bytes
 *   Specialization {@link ToLongNode#doPrimitiveLong}
 *     Activation probability: 0.29500
 *     With/without class size: 7/0 bytes
 *   Specialization {@link ToLongNode#doBoxed}
 *     Activation probability: 0.20500
 *     With/without class size: 8/4 bytes
 *   Specialization {@link ToLongNode#doBoxed}
 *     Activation probability: 0.11500
 *     With/without class size: 5/0 bytes
 * </pre>
 */
@GeneratedBy(ToLongNode.class)
@SuppressWarnings({"javadoc", "unused"})
public final class ToLongNodeGen extends ToLongNode {

    static final ReferenceField<Boxed0Data> BOXED0_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "boxed0_cache", Boxed0Data.class);
    private static final Uncached UNCACHED = new Uncached();
    private static final LibraryFactory<InteropLibrary> INTEROP_LIBRARY_ = LibraryFactory.resolve(InteropLibrary.class);

    /**
     * State Info: <pre>
     *   0: SpecializationActive {@link ToLongNode#doPrimitiveInt}
     *   1: SpecializationActive {@link ToLongNode#doPrimitiveLong}
     *   2: SpecializationActive {@link ToLongNode#doBoxed}
     *   3: SpecializationActive {@link ToLongNode#doBoxed}
     * </pre>
     */
    @CompilationFinal private int state_0_;
    @UnsafeAccessedField @Child private Boxed0Data boxed0_cache;

    private ToLongNodeGen() {
    }

    @ExplodeLoop
    @Override
    public long execute(Object arg0Value) {
        int state_0 = this.state_0_;
        if (state_0 != 0 /* is SpecializationActive[ToLongNode.doPrimitiveInt(int)] || SpecializationActive[ToLongNode.doPrimitiveLong(long)] || SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] || SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] */) {
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[ToLongNode.doPrimitiveInt(int)] */ && arg0Value instanceof Integer) {
                int arg0Value_ = (int) arg0Value;
                return ToLongNode.doPrimitiveInt(arg0Value_);
            }
            if ((state_0 & 0b10) != 0 /* is SpecializationActive[ToLongNode.doPrimitiveLong(long)] */ && arg0Value instanceof Long) {
                long arg0Value_ = (long) arg0Value;
                return ToLongNode.doPrimitiveLong(arg0Value_);
            }
            if ((state_0 & 0b1100) != 0 /* is SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] || SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] */) {
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] */) {
                    Boxed0Data s2_ = this.boxed0_cache;
                    while (s2_ != null) {
                        if ((s2_.args_.accepts(arg0Value)) && (s2_.args_.fitsInLong(arg0Value))) {
                            return ToLongNode.doBoxed(arg0Value, s2_.args_);
                        }
                        s2_ = s2_.next_;
                    }
                }
                if ((state_0 & 0b1000) != 0 /* is SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] */) {
                    EncapsulatingNodeReference encapsulating_ = EncapsulatingNodeReference.getCurrent();
                    Node prev_ = encapsulating_.set(this);
                    try {
                        {
                            InteropLibrary args__ = (INTEROP_LIBRARY_.getUncached());
                            if ((args__.fitsInLong(arg0Value))) {
                                return this.boxed1Boundary(state_0, arg0Value);
                            }
                        }
                    } finally {
                        encapsulating_.set(prev_);
                    }
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value);
    }

    @SuppressWarnings("static-method")
    @TruffleBoundary
    private long boxed1Boundary(int state_0, Object arg0Value) {
        {
            InteropLibrary args__ = (INTEROP_LIBRARY_.getUncached());
            return ToLongNode.doBoxed(arg0Value, args__);
        }
    }

    @SuppressWarnings("unused")
    private long executeAndSpecialize(Object arg0Value) {
        int state_0 = this.state_0_;
        if (arg0Value instanceof Integer) {
            int arg0Value_ = (int) arg0Value;
            state_0 = state_0 | 0b1 /* add SpecializationActive[ToLongNode.doPrimitiveInt(int)] */;
            this.state_0_ = state_0;
            return ToLongNode.doPrimitiveInt(arg0Value_);
        }
        if (arg0Value instanceof Long) {
            long arg0Value_ = (long) arg0Value;
            state_0 = state_0 | 0b10 /* add SpecializationActive[ToLongNode.doPrimitiveLong(long)] */;
            this.state_0_ = state_0;
            return ToLongNode.doPrimitiveLong(arg0Value_);
        }
        if (((state_0 & 0b1000)) == 0 /* is-not SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] */) {
            while (true) {
                int count2_ = 0;
                Boxed0Data s2_ = BOXED0_CACHE_UPDATER.getVolatile(this);
                Boxed0Data s2_original = s2_;
                while (s2_ != null) {
                    if ((s2_.args_.accepts(arg0Value)) && (s2_.args_.fitsInLong(arg0Value))) {
                        break;
                    }
                    count2_++;
                    s2_ = s2_.next_;
                }
                if (s2_ == null) {
                    {
                        InteropLibrary args__ = this.insert((INTEROP_LIBRARY_.create(arg0Value)));
                        // assert (s2_.args_.accepts(arg0Value));
                        if ((args__.fitsInLong(arg0Value)) && count2_ < (2)) {
                            s2_ = this.insert(new Boxed0Data(s2_original));
                            Objects.requireNonNull(s2_.insert(args__), "Specialization 'doBoxed(Object, InteropLibrary)' cache 'args' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                            s2_.args_ = args__;
                            if (!BOXED0_CACHE_UPDATER.compareAndSet(this, s2_original, s2_)) {
                                continue;
                            }
                            state_0 = state_0 | 0b100 /* add SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] */;
                            this.state_0_ = state_0;
                        }
                    }
                }
                if (s2_ != null) {
                    return ToLongNode.doBoxed(arg0Value, s2_.args_);
                }
                break;
            }
        }
        {
            InteropLibrary args__ = null;
            {
                EncapsulatingNodeReference encapsulating_ = EncapsulatingNodeReference.getCurrent();
                Node prev_ = encapsulating_.set(this);
                try {
                    {
                        args__ = (INTEROP_LIBRARY_.getUncached());
                        if ((args__.fitsInLong(arg0Value))) {
                            this.boxed0_cache = null;
                            state_0 = state_0 & 0xfffffffb /* remove SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] */;
                            state_0 = state_0 | 0b1000 /* add SpecializationActive[ToLongNode.doBoxed(Object, InteropLibrary)] */;
                            this.state_0_ = state_0;
                            return ToLongNode.doBoxed(arg0Value, args__);
                        }
                    }
                } finally {
                    encapsulating_.set(prev_);
                }
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
    }

    @Override
    public NodeCost getCost() {
        int state_0 = this.state_0_;
        if (state_0 == 0) {
            return NodeCost.UNINITIALIZED;
        } else {
            if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                Boxed0Data s2_ = this.boxed0_cache;
                if ((s2_ == null || s2_.next_ == null)) {
                    return NodeCost.MONOMORPHIC;
                }
            }
        }
        return NodeCost.POLYMORPHIC;
    }

    @NeverDefault
    public static ToLongNode create() {
        return new ToLongNodeGen();
    }

    @NeverDefault
    public static ToLongNode getUncached() {
        return ToLongNodeGen.UNCACHED;
    }

    @GeneratedBy(ToLongNode.class)
    @DenyReplace
    private static final class Boxed0Data extends Node implements SpecializationDataNode {

        @Child Boxed0Data next_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToLongNode#doBoxed}
         *   Parameter: {@link InteropLibrary} args</pre>
         */
        @Child InteropLibrary args_;

        Boxed0Data(Boxed0Data next_) {
            this.next_ = next_;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.NONE;
        }

    }
    @GeneratedBy(ToLongNode.class)
    @DenyReplace
    private static final class Uncached extends ToLongNode {

        @TruffleBoundary
        @Override
        public long execute(Object arg0Value) {
            if (arg0Value instanceof Integer) {
                int arg0Value_ = (int) arg0Value;
                return ToLongNode.doPrimitiveInt(arg0Value_);
            }
            if (arg0Value instanceof Long) {
                long arg0Value_ = (long) arg0Value;
                return ToLongNode.doPrimitiveLong(arg0Value_);
            }
            if (((INTEROP_LIBRARY_.getUncached(arg0Value)).fitsInLong(arg0Value))) {
                return ToLongNode.doBoxed(arg0Value, (INTEROP_LIBRARY_.getUncached(arg0Value)));
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MEGAMORPHIC;
        }

        @Override
        public boolean isAdoptable() {
            return false;
        }

    }
}
