// CheckStyle: start generated
package com.oracle.truffle.regex.runtime.nodes;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.interop.UnsupportedTypeException;
import com.oracle.truffle.api.library.LibraryFactory;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.EncapsulatingNodeReference;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import java.lang.invoke.MethodHandles;
import java.util.Objects;

/**
 * Debug Info: <pre>
 *   Specialization {@link ToIntNode#doPrimitiveInt}
 *     Activation probability: 0.48333
 *     With/without class size: 9/0 bytes
 *   Specialization {@link ToIntNode#doBoxed}
 *     Activation probability: 0.33333
 *     With/without class size: 12/4 bytes
 *   Specialization {@link ToIntNode#doBoxed}
 *     Activation probability: 0.18333
 *     With/without class size: 6/0 bytes
 * </pre>
 */
@GeneratedBy(ToIntNode.class)
@SuppressWarnings({"javadoc", "unused"})
public final class ToIntNodeGen extends ToIntNode {

    static final ReferenceField<Boxed0Data> BOXED0_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "boxed0_cache", Boxed0Data.class);
    private static final Uncached UNCACHED = new Uncached();
    private static final LibraryFactory<InteropLibrary> INTEROP_LIBRARY_ = LibraryFactory.resolve(InteropLibrary.class);

    /**
     * State Info: <pre>
     *   0: SpecializationActive {@link ToIntNode#doPrimitiveInt}
     *   1: SpecializationActive {@link ToIntNode#doBoxed}
     *   2: SpecializationActive {@link ToIntNode#doBoxed}
     * </pre>
     */
    @CompilationFinal private int state_0_;
    @UnsafeAccessedField @Child private Boxed0Data boxed0_cache;

    private ToIntNodeGen() {
    }

    @ExplodeLoop
    @Override
    public int execute(Object arg0Value) throws UnsupportedTypeException {
        int state_0 = this.state_0_;
        if (state_0 != 0 /* is SpecializationActive[ToIntNode.doPrimitiveInt(int)] || SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] || SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] */) {
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[ToIntNode.doPrimitiveInt(int)] */ && arg0Value instanceof Integer) {
                int arg0Value_ = (int) arg0Value;
                return ToIntNode.doPrimitiveInt(arg0Value_);
            }
            if ((state_0 & 0b110) != 0 /* is SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] || SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] */) {
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] */) {
                    Boxed0Data s1_ = this.boxed0_cache;
                    while (s1_ != null) {
                        if ((s1_.args_.accepts(arg0Value)) && (s1_.args_.fitsInInt(arg0Value))) {
                            return ToIntNode.doBoxed(arg0Value, s1_.args_);
                        }
                        s1_ = s1_.next_;
                    }
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] */) {
                    EncapsulatingNodeReference encapsulating_ = EncapsulatingNodeReference.getCurrent();
                    Node prev_ = encapsulating_.set(this);
                    try {
                        {
                            InteropLibrary args__ = (INTEROP_LIBRARY_.getUncached());
                            if ((args__.fitsInInt(arg0Value))) {
                                return this.boxed1Boundary(state_0, arg0Value);
                            }
                        }
                    } finally {
                        encapsulating_.set(prev_);
                    }
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value);
    }

    @SuppressWarnings("static-method")
    @TruffleBoundary
    private int boxed1Boundary(int state_0, Object arg0Value) throws UnsupportedTypeException {
        {
            InteropLibrary args__ = (INTEROP_LIBRARY_.getUncached());
            return ToIntNode.doBoxed(arg0Value, args__);
        }
    }

    @SuppressWarnings("unused")
    private int executeAndSpecialize(Object arg0Value) throws UnsupportedTypeException {
        int state_0 = this.state_0_;
        if (arg0Value instanceof Integer) {
            int arg0Value_ = (int) arg0Value;
            state_0 = state_0 | 0b1 /* add SpecializationActive[ToIntNode.doPrimitiveInt(int)] */;
            this.state_0_ = state_0;
            return ToIntNode.doPrimitiveInt(arg0Value_);
        }
        if (((state_0 & 0b100)) == 0 /* is-not SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] */) {
            while (true) {
                int count1_ = 0;
                Boxed0Data s1_ = BOXED0_CACHE_UPDATER.getVolatile(this);
                Boxed0Data s1_original = s1_;
                while (s1_ != null) {
                    if ((s1_.args_.accepts(arg0Value)) && (s1_.args_.fitsInInt(arg0Value))) {
                        break;
                    }
                    count1_++;
                    s1_ = s1_.next_;
                }
                if (s1_ == null) {
                    {
                        InteropLibrary args__ = this.insert((INTEROP_LIBRARY_.create(arg0Value)));
                        // assert (s1_.args_.accepts(arg0Value));
                        if ((args__.fitsInInt(arg0Value)) && count1_ < (2)) {
                            s1_ = this.insert(new Boxed0Data(s1_original));
                            Objects.requireNonNull(s1_.insert(args__), "Specialization 'doBoxed(Object, InteropLibrary)' cache 'args' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                            s1_.args_ = args__;
                            if (!BOXED0_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                continue;
                            }
                            state_0 = state_0 | 0b10 /* add SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] */;
                            this.state_0_ = state_0;
                        }
                    }
                }
                if (s1_ != null) {
                    return ToIntNode.doBoxed(arg0Value, s1_.args_);
                }
                break;
            }
        }
        {
            InteropLibrary args__ = null;
            {
                EncapsulatingNodeReference encapsulating_ = EncapsulatingNodeReference.getCurrent();
                Node prev_ = encapsulating_.set(this);
                try {
                    {
                        args__ = (INTEROP_LIBRARY_.getUncached());
                        if ((args__.fitsInInt(arg0Value))) {
                            this.boxed0_cache = null;
                            state_0 = state_0 & 0xfffffffd /* remove SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] */;
                            state_0 = state_0 | 0b100 /* add SpecializationActive[ToIntNode.doBoxed(Object, InteropLibrary)] */;
                            this.state_0_ = state_0;
                            return ToIntNode.doBoxed(arg0Value, args__);
                        }
                    }
                } finally {
                    encapsulating_.set(prev_);
                }
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
    }

    @Override
    public NodeCost getCost() {
        int state_0 = this.state_0_;
        if (state_0 == 0) {
            return NodeCost.UNINITIALIZED;
        } else {
            if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                Boxed0Data s1_ = this.boxed0_cache;
                if ((s1_ == null || s1_.next_ == null)) {
                    return NodeCost.MONOMORPHIC;
                }
            }
        }
        return NodeCost.POLYMORPHIC;
    }

    @NeverDefault
    public static ToIntNode create() {
        return new ToIntNodeGen();
    }

    @NeverDefault
    public static ToIntNode getUncached() {
        return ToIntNodeGen.UNCACHED;
    }

    @GeneratedBy(ToIntNode.class)
    @DenyReplace
    private static final class Boxed0Data extends Node implements SpecializationDataNode {

        @Child Boxed0Data next_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link ToIntNode#doBoxed}
         *   Parameter: {@link InteropLibrary} args</pre>
         */
        @Child InteropLibrary args_;

        Boxed0Data(Boxed0Data next_) {
            this.next_ = next_;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.NONE;
        }

    }
    @GeneratedBy(ToIntNode.class)
    @DenyReplace
    private static final class Uncached extends ToIntNode {

        @TruffleBoundary
        @Override
        public int execute(Object arg0Value) throws UnsupportedTypeException {
            if (arg0Value instanceof Integer) {
                int arg0Value_ = (int) arg0Value;
                return ToIntNode.doPrimitiveInt(arg0Value_);
            }
            if (((INTEROP_LIBRARY_.getUncached(arg0Value)).fitsInInt(arg0Value))) {
                return ToIntNode.doBoxed(arg0Value, (INTEROP_LIBRARY_.getUncached(arg0Value)));
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MEGAMORPHIC;
        }

        @Override
        public boolean isAdoptable() {
            return false;
        }

    }
}
