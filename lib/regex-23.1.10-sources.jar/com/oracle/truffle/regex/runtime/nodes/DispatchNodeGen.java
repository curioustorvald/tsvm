// CheckStyle: start generated
package com.oracle.truffle.regex.runtime.nodes;

import com.oracle.truffle.api.CallTarget;
import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.InlineTarget;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.RequiredField;
import com.oracle.truffle.api.dsl.InlineSupport.StateField;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.DirectCallNode;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.IndirectCallNode;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.regex.result.RegexResult;
import java.lang.invoke.VarHandle;

/**
 * Debug Info: <pre>
 *   Specialization {@link DispatchNode#doDirect}
 *     Activation probability: 0.65000
 *     With/without class size: 22/8 bytes
 *   Specialization {@link DispatchNode#doIndirect}
 *     Activation probability: 0.35000
 *     With/without class size: 11/4 bytes
 * </pre>
 */
@GeneratedBy(DispatchNode.class)
@SuppressWarnings("javadoc")
public final class DispatchNodeGen {

    private static final Uncached UNCACHED = new Uncached();

    @NeverDefault
    public static DispatchNode getUncached() {
        return DispatchNodeGen.UNCACHED;
    }

    /**
     * Required Fields: <ul>
     * <li>{@link Inlined#state_0_}
     * <li>{@link Inlined#direct_cache}
     * <li>{@link Inlined#indirect_callNode_}
     * </ul>
     */
    @NeverDefault
    public static DispatchNode inline(@RequiredField(bits = 2, value = StateField.class)@RequiredField(type = Node.class, value = ReferenceField.class)@RequiredField(type = Node.class, value = ReferenceField.class) InlineTarget target) {
        return new DispatchNodeGen.Inlined(target);
    }

    @GeneratedBy(DispatchNode.class)
    @DenyReplace
    private static final class Inlined extends DispatchNode {

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link DispatchNode#doDirect}
         *   1: SpecializationActive {@link DispatchNode#doIndirect}
         * </pre>
         */
        private final StateField state_0_;
        private final ReferenceField<DirectData> direct_cache;
        private final ReferenceField<IndirectCallNode> indirect_callNode_;

        @SuppressWarnings("unchecked")
        private Inlined(InlineTarget target) {
            assert target.getTargetClass().isAssignableFrom(DispatchNode.class);
            this.state_0_ = target.getState(0, 2);
            this.direct_cache = target.getReference(1, DirectData.class);
            this.indirect_callNode_ = target.getReference(2, IndirectCallNode.class);
        }

        @ExplodeLoop
        @Override
        public Object execute(Node arg0Value, CallTarget arg1Value, RegexResult arg2Value) {
            int state_0 = this.state_0_.get(arg0Value);
            if (state_0 != 0 /* is SpecializationActive[DispatchNode.doDirect(CallTarget, RegexResult, CallTarget, DirectCallNode)] || SpecializationActive[DispatchNode.doIndirect(CallTarget, RegexResult, IndirectCallNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[DispatchNode.doDirect(CallTarget, RegexResult, CallTarget, DirectCallNode)] */) {
                    DirectData s0_ = this.direct_cache.get(arg0Value);
                    while (s0_ != null) {
                        if ((arg1Value == s0_.cachedTarget_)) {
                            return DispatchNode.doDirect(arg1Value, arg2Value, s0_.cachedTarget_, s0_.callNode_);
                        }
                        s0_ = s0_.next_;
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[DispatchNode.doIndirect(CallTarget, RegexResult, IndirectCallNode)] */) {
                    {
                        IndirectCallNode callNode__ = this.indirect_callNode_.get(arg0Value);
                        if (callNode__ != null) {
                            return DispatchNode.doIndirect(arg1Value, arg2Value, callNode__);
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Node arg0Value, CallTarget arg1Value, RegexResult arg2Value) {
            int state_0 = this.state_0_.get(arg0Value);
            if (((state_0 & 0b10)) == 0 /* is-not SpecializationActive[DispatchNode.doIndirect(CallTarget, RegexResult, IndirectCallNode)] */) {
                while (true) {
                    int count0_ = 0;
                    DirectData s0_ = this.direct_cache.getVolatile(arg0Value);
                    DirectData s0_original = s0_;
                    while (s0_ != null) {
                        if ((arg1Value == s0_.cachedTarget_)) {
                            break;
                        }
                        count0_++;
                        s0_ = s0_.next_;
                    }
                    if (s0_ == null) {
                        // assert (arg1Value == s0_.cachedTarget_);
                        if (count0_ < (4)) {
                            s0_ = arg0Value.insert(new DirectData(s0_original));
                            s0_.cachedTarget_ = (arg1Value);
                            s0_.callNode_ = s0_.insert((DirectCallNode.create(s0_.cachedTarget_)));
                            if (!this.direct_cache.compareAndSet(arg0Value, s0_original, s0_)) {
                                continue;
                            }
                            state_0 = state_0 | 0b1 /* add SpecializationActive[DispatchNode.doDirect(CallTarget, RegexResult, CallTarget, DirectCallNode)] */;
                            this.state_0_.set(arg0Value, state_0);
                        }
                    }
                    if (s0_ != null) {
                        return DispatchNode.doDirect(arg1Value, arg2Value, s0_.cachedTarget_, s0_.callNode_);
                    }
                    break;
                }
            }
            VarHandle.storeStoreFence();
            this.indirect_callNode_.set(arg0Value, arg0Value.insert((IndirectCallNode.create())));
            this.direct_cache.set(arg0Value, null);
            state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[DispatchNode.doDirect(CallTarget, RegexResult, CallTarget, DirectCallNode)] */;
            state_0 = state_0 | 0b10 /* add SpecializationActive[DispatchNode.doIndirect(CallTarget, RegexResult, IndirectCallNode)] */;
            this.state_0_.set(arg0Value, state_0);
            return DispatchNode.doIndirect(arg1Value, arg2Value, this.indirect_callNode_.get(arg0Value));
        }

        @Override
        public boolean isAdoptable() {
            return false;
        }

    }
    @GeneratedBy(DispatchNode.class)
    @DenyReplace
    private static final class DirectData extends Node implements SpecializationDataNode {

        @Child DirectData next_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link DispatchNode#doDirect}
         *   Parameter: {@link CallTarget} cachedTarget</pre>
         */
        @CompilationFinal CallTarget cachedTarget_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link DispatchNode#doDirect}
         *   Parameter: {@link DirectCallNode} callNode</pre>
         */
        @Child DirectCallNode callNode_;

        DirectData(DirectData next_) {
            this.next_ = next_;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.NONE;
        }

    }
    @GeneratedBy(DispatchNode.class)
    @DenyReplace
    private static final class Uncached extends DispatchNode {

        @TruffleBoundary
        @Override
        public Object execute(Node arg0Value, CallTarget arg1Value, RegexResult arg2Value) {
            return DispatchNode.doIndirect(arg1Value, arg2Value, (IndirectCallNode.getUncached()));
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MEGAMORPHIC;
        }

        @Override
        public boolean isAdoptable() {
            return false;
        }

    }
}
