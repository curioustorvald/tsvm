// CheckStyle: start generated
package com.oracle.truffle.regex.runtime.nodes;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.library.LibraryFactory;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.EncapsulatingNodeReference;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.strings.TruffleString;
import com.oracle.truffle.api.strings.TruffleString.Encoding;
import com.oracle.truffle.api.strings.TruffleString.FromJavaStringNode;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.Objects;

/**
 * Debug Info: <pre>
 *   Specialization {@link ExpectStringNode#doString}
 *     Activation probability: 0.38500
 *     With/without class size: 11/4 bytes
 *   Specialization {@link ExpectStringNode#doTString}
 *     Activation probability: 0.29500
 *     With/without class size: 7/0 bytes
 *   Specialization {@link ExpectStringNode#doBoxedString}
 *     Activation probability: 0.20500
 *     With/without class size: 8/4 bytes
 *   Specialization {@link ExpectStringNode#doBoxedString}
 *     Activation probability: 0.11500
 *     With/without class size: 5/0 bytes
 * </pre>
 */
@GeneratedBy(ExpectStringNode.class)
@SuppressWarnings({"javadoc", "unused"})
public final class ExpectStringNodeGen extends ExpectStringNode {

    static final ReferenceField<BoxedString0Data> BOXED_STRING0_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "boxedString0_cache", BoxedString0Data.class);
    private static final Uncached UNCACHED = new Uncached();
    private static final LibraryFactory<InteropLibrary> INTEROP_LIBRARY_ = LibraryFactory.resolve(InteropLibrary.class);

    /**
     * State Info: <pre>
     *   0: SpecializationActive {@link ExpectStringNode#doString}
     *   1: SpecializationActive {@link ExpectStringNode#doTString}
     *   2: SpecializationActive {@link ExpectStringNode#doBoxedString}
     *   3: SpecializationActive {@link ExpectStringNode#doBoxedString}
     * </pre>
     */
    @CompilationFinal private int state_0_;
    /**
     * Source Info: <pre>
     *   Specialization: {@link ExpectStringNode#doString}
     *   Parameter: {@link FromJavaStringNode} fromJavaStringNode</pre>
     */
    @Child private FromJavaStringNode string_fromJavaStringNode_;
    @UnsafeAccessedField @Child private BoxedString0Data boxedString0_cache;

    private ExpectStringNodeGen() {
    }

    @ExplodeLoop
    @Override
    public TruffleString execute(Object arg0Value, Encoding arg1Value) {
        int state_0 = this.state_0_;
        if (state_0 != 0 /* is SpecializationActive[ExpectStringNode.doString(String, Encoding, FromJavaStringNode)] || SpecializationActive[ExpectStringNode.doTString(TruffleString, Encoding)] || SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] || SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] */) {
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[ExpectStringNode.doString(String, Encoding, FromJavaStringNode)] */ && arg0Value instanceof String) {
                String arg0Value_ = (String) arg0Value;
                {
                    FromJavaStringNode fromJavaStringNode__ = this.string_fromJavaStringNode_;
                    if (fromJavaStringNode__ != null) {
                        return ExpectStringNode.doString(arg0Value_, arg1Value, fromJavaStringNode__);
                    }
                }
            }
            if ((state_0 & 0b10) != 0 /* is SpecializationActive[ExpectStringNode.doTString(TruffleString, Encoding)] */ && arg0Value instanceof TruffleString) {
                TruffleString arg0Value_ = (TruffleString) arg0Value;
                return ExpectStringNode.doTString(arg0Value_, arg1Value);
            }
            if ((state_0 & 0b1100) != 0 /* is SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] || SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] */) {
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] */) {
                    BoxedString0Data s2_ = this.boxedString0_cache;
                    while (s2_ != null) {
                        if ((s2_.inputs_.accepts(arg0Value)) && (s2_.inputs_.isString(arg0Value))) {
                            return ExpectStringNode.doBoxedString(arg0Value, arg1Value, s2_.inputs_);
                        }
                        s2_ = s2_.next_;
                    }
                }
                if ((state_0 & 0b1000) != 0 /* is SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] */) {
                    EncapsulatingNodeReference encapsulating_ = EncapsulatingNodeReference.getCurrent();
                    Node prev_ = encapsulating_.set(this);
                    try {
                        {
                            InteropLibrary inputs__ = (INTEROP_LIBRARY_.getUncached());
                            if ((inputs__.isString(arg0Value))) {
                                return this.boxedString1Boundary(state_0, arg0Value, arg1Value);
                            }
                        }
                    } finally {
                        encapsulating_.set(prev_);
                    }
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value, arg1Value);
    }

    @SuppressWarnings("static-method")
    @TruffleBoundary
    private TruffleString boxedString1Boundary(int state_0, Object arg0Value, Encoding arg1Value) {
        {
            InteropLibrary inputs__ = (INTEROP_LIBRARY_.getUncached());
            return ExpectStringNode.doBoxedString(arg0Value, arg1Value, inputs__);
        }
    }

    @SuppressWarnings("unused")
    private TruffleString executeAndSpecialize(Object arg0Value, Encoding arg1Value) {
        int state_0 = this.state_0_;
        if (arg0Value instanceof String) {
            String arg0Value_ = (String) arg0Value;
            FromJavaStringNode fromJavaStringNode__ = this.insert((FromJavaStringNode.create()));
            Objects.requireNonNull(fromJavaStringNode__, "Specialization 'doString(String, Encoding, FromJavaStringNode)' cache 'fromJavaStringNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
            VarHandle.storeStoreFence();
            this.string_fromJavaStringNode_ = fromJavaStringNode__;
            state_0 = state_0 | 0b1 /* add SpecializationActive[ExpectStringNode.doString(String, Encoding, FromJavaStringNode)] */;
            this.state_0_ = state_0;
            return ExpectStringNode.doString(arg0Value_, arg1Value, fromJavaStringNode__);
        }
        if (arg0Value instanceof TruffleString) {
            TruffleString arg0Value_ = (TruffleString) arg0Value;
            state_0 = state_0 | 0b10 /* add SpecializationActive[ExpectStringNode.doTString(TruffleString, Encoding)] */;
            this.state_0_ = state_0;
            return ExpectStringNode.doTString(arg0Value_, arg1Value);
        }
        if (((state_0 & 0b1000)) == 0 /* is-not SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] */) {
            while (true) {
                int count2_ = 0;
                BoxedString0Data s2_ = BOXED_STRING0_CACHE_UPDATER.getVolatile(this);
                BoxedString0Data s2_original = s2_;
                while (s2_ != null) {
                    if ((s2_.inputs_.accepts(arg0Value)) && (s2_.inputs_.isString(arg0Value))) {
                        break;
                    }
                    count2_++;
                    s2_ = s2_.next_;
                }
                if (s2_ == null) {
                    {
                        InteropLibrary inputs__ = this.insert((INTEROP_LIBRARY_.create(arg0Value)));
                        // assert (s2_.inputs_.accepts(arg0Value));
                        if ((inputs__.isString(arg0Value)) && count2_ < (2)) {
                            s2_ = this.insert(new BoxedString0Data(s2_original));
                            Objects.requireNonNull(s2_.insert(inputs__), "Specialization 'doBoxedString(Object, Encoding, InteropLibrary)' cache 'inputs' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                            s2_.inputs_ = inputs__;
                            if (!BOXED_STRING0_CACHE_UPDATER.compareAndSet(this, s2_original, s2_)) {
                                continue;
                            }
                            state_0 = state_0 | 0b100 /* add SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] */;
                            this.state_0_ = state_0;
                        }
                    }
                }
                if (s2_ != null) {
                    return ExpectStringNode.doBoxedString(arg0Value, arg1Value, s2_.inputs_);
                }
                break;
            }
        }
        {
            InteropLibrary inputs__ = null;
            {
                EncapsulatingNodeReference encapsulating_ = EncapsulatingNodeReference.getCurrent();
                Node prev_ = encapsulating_.set(this);
                try {
                    {
                        inputs__ = (INTEROP_LIBRARY_.getUncached());
                        if ((inputs__.isString(arg0Value))) {
                            this.boxedString0_cache = null;
                            state_0 = state_0 & 0xfffffffb /* remove SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] */;
                            state_0 = state_0 | 0b1000 /* add SpecializationActive[ExpectStringNode.doBoxedString(Object, Encoding, InteropLibrary)] */;
                            this.state_0_ = state_0;
                            return ExpectStringNode.doBoxedString(arg0Value, arg1Value, inputs__);
                        }
                    }
                } finally {
                    encapsulating_.set(prev_);
                }
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
    }

    @Override
    public NodeCost getCost() {
        int state_0 = this.state_0_;
        if (state_0 == 0) {
            return NodeCost.UNINITIALIZED;
        } else {
            if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                BoxedString0Data s2_ = this.boxedString0_cache;
                if ((s2_ == null || s2_.next_ == null)) {
                    return NodeCost.MONOMORPHIC;
                }
            }
        }
        return NodeCost.POLYMORPHIC;
    }

    @NeverDefault
    public static ExpectStringNode create() {
        return new ExpectStringNodeGen();
    }

    @NeverDefault
    public static ExpectStringNode getUncached() {
        return ExpectStringNodeGen.UNCACHED;
    }

    @GeneratedBy(ExpectStringNode.class)
    @DenyReplace
    private static final class BoxedString0Data extends Node implements SpecializationDataNode {

        @Child BoxedString0Data next_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link ExpectStringNode#doBoxedString}
         *   Parameter: {@link InteropLibrary} inputs</pre>
         */
        @Child InteropLibrary inputs_;

        BoxedString0Data(BoxedString0Data next_) {
            this.next_ = next_;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.NONE;
        }

    }
    @GeneratedBy(ExpectStringNode.class)
    @DenyReplace
    private static final class Uncached extends ExpectStringNode {

        @TruffleBoundary
        @Override
        public TruffleString execute(Object arg0Value, Encoding arg1Value) {
            if (arg0Value instanceof String) {
                String arg0Value_ = (String) arg0Value;
                return ExpectStringNode.doString(arg0Value_, arg1Value, (FromJavaStringNode.getUncached()));
            }
            if (arg0Value instanceof TruffleString) {
                TruffleString arg0Value_ = (TruffleString) arg0Value;
                return ExpectStringNode.doTString(arg0Value_, arg1Value);
            }
            if (((INTEROP_LIBRARY_.getUncached(arg0Value)).isString(arg0Value))) {
                return ExpectStringNode.doBoxedString(arg0Value, arg1Value, (INTEROP_LIBRARY_.getUncached(arg0Value)));
            }
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.MEGAMORPHIC;
        }

        @Override
        public boolean isAdoptable() {
            return false;
        }

    }
}
