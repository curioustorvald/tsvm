// CheckStyle: start generated
package com.oracle.truffle.regex;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.interop.ArityException;
import com.oracle.truffle.api.interop.InteropLibrary;
import com.oracle.truffle.api.interop.UnsupportedMessageException;
import com.oracle.truffle.api.interop.UnsupportedTypeException;
import com.oracle.truffle.api.library.LibraryExport;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.regex.RegexObject.ExecCompiledRegexNode;
import com.oracle.truffle.regex.RegexObject.RegexObjectExecMethod;
import com.oracle.truffle.regex.RegexObjectFactory.ExecCompiledRegexNodeGen;
import java.lang.invoke.VarHandle;
import java.util.Objects;

@GeneratedBy(RegexObjectExecMethod.class)
@SuppressWarnings("javadoc")
final class RegexObjectExecMethodGen {

    static  {
        LibraryExport.register(RegexObjectExecMethod.class, new InteropLibraryExports());
    }

    private RegexObjectExecMethodGen() {
    }

    @GeneratedBy(RegexObjectExecMethod.class)
    private static final class InteropLibraryExports extends LibraryExport<InteropLibrary> {

        private InteropLibraryExports() {
            super(InteropLibrary.class, RegexObjectExecMethod.class, false, false, 0);
        }

        @Override
        protected InteropLibrary createUncached(Object receiver) {
            assert receiver instanceof RegexObjectExecMethod;
            InteropLibrary uncached = new Uncached(receiver);
            return uncached;
        }

        @Override
        protected InteropLibrary createCached(Object receiver) {
            assert receiver instanceof RegexObjectExecMethod;
            return new Cached(receiver);
        }

        @GeneratedBy(RegexObjectExecMethod.class)
        private static final class Cached extends AbstractRegexObjectGen.InteropLibraryExports.Cached {

            /**
             * State Info: <pre>
             *   0: SpecializationActive {@link RegexObjectExecMethod#execute(RegexObjectExecMethod, Object[], ExecCompiledRegexNode)}
             * </pre>
             */
            @CompilationFinal private int state_0_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link RegexObjectExecMethod#execute(RegexObjectExecMethod, Object[], ExecCompiledRegexNode)}
             *   Parameter: {@link ExecCompiledRegexNode} execNode</pre>
             */
            @Child private ExecCompiledRegexNode execNode_;

            protected Cached(Object receiver) {
                super(receiver);
            }

            @Override
            public boolean isExecutable(Object receiver) {
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                return (((RegexObjectExecMethod) receiver)).isExecutable();
            }

            /**
             * Debug Info: <pre>
             *   Specialization {@link RegexObjectExecMethod#execute(RegexObjectExecMethod, Object[], ExecCompiledRegexNode)}
             *     Activation probability: 1.00000
             *     With/without class size: 24/4 bytes
             * </pre>
             */
            @Override
            public Object execute(Object arg0Value_, Object... arg1Value) throws UnsupportedTypeException, ArityException, UnsupportedMessageException {
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                assert assertAdopted();
                RegexObjectExecMethod arg0Value = ((RegexObjectExecMethod) arg0Value_);
                int state_0 = this.state_0_;
                if (state_0 != 0 /* is SpecializationActive[RegexObjectExecMethod.execute(RegexObjectExecMethod, Object[], ExecCompiledRegexNode)] */) {
                    {
                        ExecCompiledRegexNode execNode__ = this.execNode_;
                        if (execNode__ != null) {
                            return arg0Value.execute(arg1Value, execNode__);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                return executeAndSpecialize(arg0Value, arg1Value);
            }

            private Object executeAndSpecialize(RegexObjectExecMethod arg0Value, Object[] arg1Value) throws ArityException, UnsupportedTypeException, UnsupportedMessageException {
                int state_0 = this.state_0_;
                ExecCompiledRegexNode execNode__ = this.insert((ExecCompiledRegexNodeGen.create()));
                Objects.requireNonNull(execNode__, "Specialization 'execute(RegexObjectExecMethod, Object[], ExecCompiledRegexNode)' cache 'execNode' returned a 'null' default value. The cache initializer must never return a default value for this cache. Use @Cached(neverDefault=false) to allow default values for this cached value or make sure the cache initializer never returns 'null'.");
                VarHandle.storeStoreFence();
                this.execNode_ = execNode__;
                state_0 = state_0 | 0b1 /* add SpecializationActive[RegexObjectExecMethod.execute(RegexObjectExecMethod, Object[], ExecCompiledRegexNode)] */;
                this.state_0_ = state_0;
                return arg0Value.execute(arg1Value, execNode__);
            }

            @Override
            public NodeCost getCost() {
                int state_0 = this.state_0_;
                if (state_0 == 0) {
                    return NodeCost.UNINITIALIZED;
                } else {
                    return NodeCost.MONOMORPHIC;
                }
            }

        }
        @GeneratedBy(RegexObjectExecMethod.class)
        @DenyReplace
        private static final class Uncached extends AbstractRegexObjectGen.InteropLibraryExports.Uncached {

            protected Uncached(Object receiver) {
                super(receiver);
            }

            @Override
            @TruffleBoundary
            public boolean accepts(Object receiver) {
                return super.accepts(receiver);
            }

            @TruffleBoundary
            @Override
            public boolean isExecutable(Object receiver) {
                // declared: true
                assert this.accepts(receiver) : "Invalid library usage. Library does not accept given receiver.";
                return ((RegexObjectExecMethod) receiver) .isExecutable();
            }

            @TruffleBoundary
            @Override
            public Object execute(Object arg0Value_, Object... arg1Value) throws ArityException, UnsupportedTypeException, UnsupportedMessageException {
                // declared: true
                assert this.accepts(arg0Value_) : "Invalid library usage. Library does not accept given receiver.";
                RegexObjectExecMethod arg0Value = ((RegexObjectExecMethod) arg0Value_);
                return arg0Value.execute(arg1Value, (ExecCompiledRegexNodeGen.getUncached()));
            }

        }
    }
}
