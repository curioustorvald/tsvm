// CheckStyle: start generated
package com.oracle.truffle.regex;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.CompilerDirectives.TruffleBoundary;
import com.oracle.truffle.api.dsl.DSLSupport;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.interop.ArityException;
import com.oracle.truffle.api.interop.UnknownIdentifierException;
import com.oracle.truffle.api.interop.UnsupportedMessageException;
import com.oracle.truffle.api.interop.UnsupportedTypeException;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.DirectCallNode;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.IndirectCallNode;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.regex.RegexObject.ExecBooleanCompiledRegexNode;
import com.oracle.truffle.regex.RegexObject.ExecCompiledRegexNode;
import com.oracle.truffle.regex.RegexObject.InvokeCacheNode;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;

@GeneratedBy(RegexObject.class)
@SuppressWarnings("javadoc")
public final class RegexObjectFactory {

    /**
     * Debug Info: <pre>
     *   Specialization {@link InvokeCacheNode#execIdentity}
     *     Activation probability: 0.32000
     *     With/without class size: 10/4 bytes
     *   Specialization {@link InvokeCacheNode#execEquals}
     *     Activation probability: 0.26000
     *     With/without class size: 9/4 bytes
     *   Specialization {@link InvokeCacheNode#execBooleanIdentity}
     *     Activation probability: 0.20000
     *     With/without class size: 8/4 bytes
     *   Specialization {@link InvokeCacheNode#execBooleanEquals}
     *     Activation probability: 0.14000
     *     With/without class size: 6/4 bytes
     *   Specialization {@link InvokeCacheNode#invokeGeneric}
     *     Activation probability: 0.08000
     *     With/without class size: 4/0 bytes
     * </pre>
     */
    @GeneratedBy(InvokeCacheNode.class)
    @SuppressWarnings("javadoc")
    static final class InvokeCacheNodeGen extends InvokeCacheNode {

        static final ReferenceField<ExecIdentityData> EXEC_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "execIdentity_cache", ExecIdentityData.class);
        static final ReferenceField<ExecEqualsData> EXEC_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "execEquals_cache", ExecEqualsData.class);
        static final ReferenceField<ExecBooleanIdentityData> EXEC_BOOLEAN_IDENTITY_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "execBooleanIdentity_cache", ExecBooleanIdentityData.class);
        static final ReferenceField<ExecBooleanEqualsData> EXEC_BOOLEAN_EQUALS_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "execBooleanEquals_cache", ExecBooleanEqualsData.class);
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link InvokeCacheNode#execIdentity}
         *   1: SpecializationActive {@link InvokeCacheNode#execEquals}
         *   2: SpecializationActive {@link InvokeCacheNode#invokeGeneric}
         *   3: SpecializationActive {@link InvokeCacheNode#execBooleanIdentity}
         *   4: SpecializationActive {@link InvokeCacheNode#execBooleanEquals}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link InvokeCacheNode#execIdentity}
         *   Parameter: {@link ExecCompiledRegexNode} execNode</pre>
         */
        @Child private ExecCompiledRegexNode execNode;
        /**
         * Source Info: <pre>
         *   Specialization: {@link InvokeCacheNode#execBooleanIdentity}
         *   Parameter: {@link ExecBooleanCompiledRegexNode} execBoolNode</pre>
         */
        @Child private ExecBooleanCompiledRegexNode execBoolNode;
        @UnsafeAccessedField @CompilationFinal private ExecIdentityData execIdentity_cache;
        @UnsafeAccessedField @CompilationFinal private ExecEqualsData execEquals_cache;
        @UnsafeAccessedField @CompilationFinal private ExecBooleanIdentityData execBooleanIdentity_cache;
        @UnsafeAccessedField @CompilationFinal private ExecBooleanEqualsData execBooleanEquals_cache;

        private InvokeCacheNodeGen() {
        }

        @ExplodeLoop
        @Override
        Object execute(String arg0Value, RegexObject arg1Value, Object[] arg2Value) throws UnsupportedMessageException, ArityException, UnsupportedTypeException, UnknownIdentifierException {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[RegexObject.InvokeCacheNode.execIdentity(String, RegexObject, Object[], String, ExecCompiledRegexNode)] || SpecializationActive[RegexObject.InvokeCacheNode.execEquals(String, RegexObject, Object[], String, ExecCompiledRegexNode)] || SpecializationActive[RegexObject.InvokeCacheNode.execBooleanIdentity(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] || SpecializationActive[RegexObject.InvokeCacheNode.execBooleanEquals(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] || SpecializationActive[RegexObject.InvokeCacheNode.invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexObject.InvokeCacheNode.execIdentity(String, RegexObject, Object[], String, ExecCompiledRegexNode)] */) {
                    ExecIdentityData s0_ = this.execIdentity_cache;
                    while (s0_ != null) {
                        {
                            ExecCompiledRegexNode execNode_ = this.execNode;
                            if (execNode_ != null) {
                                if ((arg0Value == s0_.cachedSymbol_)) {
                                    assert DSLSupport.assertIdempotence((s0_.cachedSymbol_.equals(RegexObject.PROP_EXEC)));
                                    return execIdentity(arg0Value, arg1Value, arg2Value, s0_.cachedSymbol_, execNode_);
                                }
                            }
                        }
                        s0_ = s0_.next_;
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[RegexObject.InvokeCacheNode.execEquals(String, RegexObject, Object[], String, ExecCompiledRegexNode)] */) {
                    ExecEqualsData s1_ = this.execEquals_cache;
                    while (s1_ != null) {
                        {
                            ExecCompiledRegexNode execNode_1 = this.execNode;
                            if (execNode_1 != null) {
                                if ((arg0Value.equals(s1_.cachedSymbol_))) {
                                    assert DSLSupport.assertIdempotence((s1_.cachedSymbol_.equals(RegexObject.PROP_EXEC)));
                                    return execEquals(arg0Value, arg1Value, arg2Value, s1_.cachedSymbol_, execNode_1);
                                }
                            }
                        }
                        s1_ = s1_.next_;
                    }
                }
                if ((state_0 & 0b1000) != 0 /* is SpecializationActive[RegexObject.InvokeCacheNode.execBooleanIdentity(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] */) {
                    ExecBooleanIdentityData s2_ = this.execBooleanIdentity_cache;
                    while (s2_ != null) {
                        {
                            ExecBooleanCompiledRegexNode execBoolNode_ = this.execBoolNode;
                            if (execBoolNode_ != null) {
                                if ((arg0Value == s2_.cachedSymbol_)) {
                                    assert DSLSupport.assertIdempotence((s2_.cachedSymbol_.equals(RegexObject.PROP_EXEC_BOOLEAN)));
                                    return execBooleanIdentity(arg0Value, arg1Value, arg2Value, s2_.cachedSymbol_, execBoolNode_);
                                }
                            }
                        }
                        s2_ = s2_.next_;
                    }
                }
                if ((state_0 & 0b10000) != 0 /* is SpecializationActive[RegexObject.InvokeCacheNode.execBooleanEquals(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] */) {
                    ExecBooleanEqualsData s3_ = this.execBooleanEquals_cache;
                    while (s3_ != null) {
                        {
                            ExecBooleanCompiledRegexNode execBoolNode_1 = this.execBoolNode;
                            if (execBoolNode_1 != null) {
                                if ((arg0Value.equals(s3_.cachedSymbol_))) {
                                    assert DSLSupport.assertIdempotence((s3_.cachedSymbol_.equals(RegexObject.PROP_EXEC_BOOLEAN)));
                                    return execBooleanEquals(arg0Value, arg1Value, arg2Value, s3_.cachedSymbol_, execBoolNode_1);
                                }
                            }
                        }
                        s3_ = s3_.next_;
                    }
                }
                if ((state_0 & 0b100) != 0 /* is SpecializationActive[RegexObject.InvokeCacheNode.invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)] */) {
                    {
                        ExecCompiledRegexNode execNode_2 = this.execNode;
                        if (execNode_2 != null) {
                            ExecBooleanCompiledRegexNode execBoolNode_2 = this.execBoolNode;
                            if (execBoolNode_2 != null) {
                                return InvokeCacheNode.invokeGeneric(arg0Value, arg1Value, arg2Value, execNode_2, execBoolNode_2);
                            }
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(String arg0Value, RegexObject arg1Value, Object[] arg2Value) throws UnsupportedMessageException, ArityException, UnsupportedTypeException, UnknownIdentifierException {
            int state_0 = this.state_0_;
            int oldState_0 = state_0;
            try {
                if (((state_0 & 0b110)) == 0 /* is-not SpecializationActive[RegexObject.InvokeCacheNode.execEquals(String, RegexObject, Object[], String, ExecCompiledRegexNode)] && SpecializationActive[RegexObject.InvokeCacheNode.invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)] */) {
                    while (true) {
                        int count0_ = 0;
                        ExecIdentityData s0_ = EXEC_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        ExecIdentityData s0_original = s0_;
                        while (s0_ != null) {
                            {
                                ExecCompiledRegexNode execNode_ = this.execNode;
                                if (execNode_ != null) {
                                    if ((arg0Value == s0_.cachedSymbol_)) {
                                        assert DSLSupport.assertIdempotence((s0_.cachedSymbol_.equals(RegexObject.PROP_EXEC)));
                                        break;
                                    }
                                }
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            {
                                String cachedSymbol__ = (arg0Value);
                                // assert (arg0Value == s0_.cachedSymbol_);
                                if ((cachedSymbol__.equals(RegexObject.PROP_EXEC)) && count0_ < (2)) {
                                    s0_ = new ExecIdentityData(s0_original);
                                    s0_.cachedSymbol_ = cachedSymbol__;
                                    ExecCompiledRegexNode execNode_;
                                    ExecCompiledRegexNode execNode__shared = this.execNode;
                                    if (execNode__shared != null) {
                                        execNode_ = execNode__shared;
                                    } else {
                                        execNode_ = this.insert((ExecCompiledRegexNodeGen.create()));
                                        if (execNode_ == null) {
                                            throw new IllegalStateException("Specialization 'execIdentity(String, RegexObject, Object[], String, ExecCompiledRegexNode)' contains a shared cache with name 'execNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.execNode == null) {
                                        this.execNode = execNode_;
                                    }
                                    if (!EXEC_IDENTITY_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                        continue;
                                    }
                                    state_0 = state_0 | 0b1 /* add SpecializationActive[RegexObject.InvokeCacheNode.execIdentity(String, RegexObject, Object[], String, ExecCompiledRegexNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s0_ != null) {
                            return execIdentity(arg0Value, arg1Value, arg2Value, s0_.cachedSymbol_, this.execNode);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100)) == 0 /* is-not SpecializationActive[RegexObject.InvokeCacheNode.invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)] */) {
                    while (true) {
                        int count1_ = 0;
                        ExecEqualsData s1_ = EXEC_EQUALS_CACHE_UPDATER.getVolatile(this);
                        ExecEqualsData s1_original = s1_;
                        while (s1_ != null) {
                            {
                                ExecCompiledRegexNode execNode_1 = this.execNode;
                                if (execNode_1 != null) {
                                    if ((arg0Value.equals(s1_.cachedSymbol_))) {
                                        assert DSLSupport.assertIdempotence((s1_.cachedSymbol_.equals(RegexObject.PROP_EXEC)));
                                        break;
                                    }
                                }
                            }
                            count1_++;
                            s1_ = s1_.next_;
                        }
                        if (s1_ == null) {
                            {
                                String cachedSymbol__1 = (arg0Value);
                                // assert (arg0Value.equals(s1_.cachedSymbol_));
                                if ((cachedSymbol__1.equals(RegexObject.PROP_EXEC)) && count1_ < (2)) {
                                    s1_ = new ExecEqualsData(s1_original);
                                    s1_.cachedSymbol_ = cachedSymbol__1;
                                    ExecCompiledRegexNode execNode_1;
                                    ExecCompiledRegexNode execNode_1_shared = this.execNode;
                                    if (execNode_1_shared != null) {
                                        execNode_1 = execNode_1_shared;
                                    } else {
                                        execNode_1 = this.insert((ExecCompiledRegexNodeGen.create()));
                                        if (execNode_1 == null) {
                                            throw new IllegalStateException("Specialization 'execEquals(String, RegexObject, Object[], String, ExecCompiledRegexNode)' contains a shared cache with name 'execNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.execNode == null) {
                                        this.execNode = execNode_1;
                                    }
                                    if (!EXEC_EQUALS_CACHE_UPDATER.compareAndSet(this, s1_original, s1_)) {
                                        continue;
                                    }
                                    this.execIdentity_cache = null;
                                    state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[RegexObject.InvokeCacheNode.execIdentity(String, RegexObject, Object[], String, ExecCompiledRegexNode)] */;
                                    state_0 = state_0 | 0b10 /* add SpecializationActive[RegexObject.InvokeCacheNode.execEquals(String, RegexObject, Object[], String, ExecCompiledRegexNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s1_ != null) {
                            return execEquals(arg0Value, arg1Value, arg2Value, s1_.cachedSymbol_, this.execNode);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b10100)) == 0 /* is-not SpecializationActive[RegexObject.InvokeCacheNode.execBooleanEquals(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] && SpecializationActive[RegexObject.InvokeCacheNode.invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)] */) {
                    while (true) {
                        int count2_ = 0;
                        ExecBooleanIdentityData s2_ = EXEC_BOOLEAN_IDENTITY_CACHE_UPDATER.getVolatile(this);
                        ExecBooleanIdentityData s2_original = s2_;
                        while (s2_ != null) {
                            {
                                ExecBooleanCompiledRegexNode execBoolNode_ = this.execBoolNode;
                                if (execBoolNode_ != null) {
                                    if ((arg0Value == s2_.cachedSymbol_)) {
                                        assert DSLSupport.assertIdempotence((s2_.cachedSymbol_.equals(RegexObject.PROP_EXEC_BOOLEAN)));
                                        break;
                                    }
                                }
                            }
                            count2_++;
                            s2_ = s2_.next_;
                        }
                        if (s2_ == null) {
                            {
                                String cachedSymbol__2 = (arg0Value);
                                // assert (arg0Value == s2_.cachedSymbol_);
                                if ((cachedSymbol__2.equals(RegexObject.PROP_EXEC_BOOLEAN)) && count2_ < (2)) {
                                    s2_ = new ExecBooleanIdentityData(s2_original);
                                    s2_.cachedSymbol_ = cachedSymbol__2;
                                    ExecBooleanCompiledRegexNode execBoolNode_;
                                    ExecBooleanCompiledRegexNode execBoolNode__shared = this.execBoolNode;
                                    if (execBoolNode__shared != null) {
                                        execBoolNode_ = execBoolNode__shared;
                                    } else {
                                        execBoolNode_ = this.insert((ExecBooleanCompiledRegexNodeGen.create()));
                                        if (execBoolNode_ == null) {
                                            throw new IllegalStateException("Specialization 'execBooleanIdentity(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)' contains a shared cache with name 'execBoolNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.execBoolNode == null) {
                                        this.execBoolNode = execBoolNode_;
                                    }
                                    if (!EXEC_BOOLEAN_IDENTITY_CACHE_UPDATER.compareAndSet(this, s2_original, s2_)) {
                                        continue;
                                    }
                                    state_0 = state_0 | 0b1000 /* add SpecializationActive[RegexObject.InvokeCacheNode.execBooleanIdentity(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s2_ != null) {
                            return execBooleanIdentity(arg0Value, arg1Value, arg2Value, s2_.cachedSymbol_, this.execBoolNode);
                        }
                        break;
                    }
                }
                if (((state_0 & 0b100)) == 0 /* is-not SpecializationActive[RegexObject.InvokeCacheNode.invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)] */) {
                    while (true) {
                        int count3_ = 0;
                        ExecBooleanEqualsData s3_ = EXEC_BOOLEAN_EQUALS_CACHE_UPDATER.getVolatile(this);
                        ExecBooleanEqualsData s3_original = s3_;
                        while (s3_ != null) {
                            {
                                ExecBooleanCompiledRegexNode execBoolNode_1 = this.execBoolNode;
                                if (execBoolNode_1 != null) {
                                    if ((arg0Value.equals(s3_.cachedSymbol_))) {
                                        assert DSLSupport.assertIdempotence((s3_.cachedSymbol_.equals(RegexObject.PROP_EXEC_BOOLEAN)));
                                        break;
                                    }
                                }
                            }
                            count3_++;
                            s3_ = s3_.next_;
                        }
                        if (s3_ == null) {
                            {
                                String cachedSymbol__3 = (arg0Value);
                                // assert (arg0Value.equals(s3_.cachedSymbol_));
                                if ((cachedSymbol__3.equals(RegexObject.PROP_EXEC_BOOLEAN)) && count3_ < (2)) {
                                    s3_ = new ExecBooleanEqualsData(s3_original);
                                    s3_.cachedSymbol_ = cachedSymbol__3;
                                    ExecBooleanCompiledRegexNode execBoolNode_1;
                                    ExecBooleanCompiledRegexNode execBoolNode_1_shared = this.execBoolNode;
                                    if (execBoolNode_1_shared != null) {
                                        execBoolNode_1 = execBoolNode_1_shared;
                                    } else {
                                        execBoolNode_1 = this.insert((ExecBooleanCompiledRegexNodeGen.create()));
                                        if (execBoolNode_1 == null) {
                                            throw new IllegalStateException("Specialization 'execBooleanEquals(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)' contains a shared cache with name 'execBoolNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                                        }
                                    }
                                    if (this.execBoolNode == null) {
                                        this.execBoolNode = execBoolNode_1;
                                    }
                                    if (!EXEC_BOOLEAN_EQUALS_CACHE_UPDATER.compareAndSet(this, s3_original, s3_)) {
                                        continue;
                                    }
                                    this.execBooleanIdentity_cache = null;
                                    state_0 = state_0 & 0xfffffff7 /* remove SpecializationActive[RegexObject.InvokeCacheNode.execBooleanIdentity(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] */;
                                    state_0 = state_0 | 0b10000 /* add SpecializationActive[RegexObject.InvokeCacheNode.execBooleanEquals(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] */;
                                    this.state_0_ = state_0;
                                }
                            }
                        }
                        if (s3_ != null) {
                            return execBooleanEquals(arg0Value, arg1Value, arg2Value, s3_.cachedSymbol_, this.execBoolNode);
                        }
                        break;
                    }
                }
                ExecCompiledRegexNode execNode_2;
                ExecCompiledRegexNode execNode_2_shared = this.execNode;
                if (execNode_2_shared != null) {
                    execNode_2 = execNode_2_shared;
                } else {
                    execNode_2 = this.insert((ExecCompiledRegexNodeGen.create()));
                    if (execNode_2 == null) {
                        throw new IllegalStateException("Specialization 'invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)' contains a shared cache with name 'execNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                    }
                }
                if (this.execNode == null) {
                    VarHandle.storeStoreFence();
                    this.execNode = execNode_2;
                }
                ExecBooleanCompiledRegexNode execBoolNode_2;
                ExecBooleanCompiledRegexNode execBoolNode_2_shared = this.execBoolNode;
                if (execBoolNode_2_shared != null) {
                    execBoolNode_2 = execBoolNode_2_shared;
                } else {
                    execBoolNode_2 = this.insert((ExecBooleanCompiledRegexNodeGen.create()));
                    if (execBoolNode_2 == null) {
                        throw new IllegalStateException("Specialization 'invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)' contains a shared cache with name 'execBoolNode' that returned a default value for the cached initializer. Default values are not supported for shared cached initializers because the default value is reserved for the uninitialized state.");
                    }
                }
                if (this.execBoolNode == null) {
                    VarHandle.storeStoreFence();
                    this.execBoolNode = execBoolNode_2;
                }
                this.execIdentity_cache = null;
                this.execEquals_cache = null;
                this.execBooleanIdentity_cache = null;
                this.execBooleanEquals_cache = null;
                state_0 = state_0 & 0xffffffe4 /* remove SpecializationActive[RegexObject.InvokeCacheNode.execIdentity(String, RegexObject, Object[], String, ExecCompiledRegexNode)], SpecializationActive[RegexObject.InvokeCacheNode.execEquals(String, RegexObject, Object[], String, ExecCompiledRegexNode)], SpecializationActive[RegexObject.InvokeCacheNode.execBooleanIdentity(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)], SpecializationActive[RegexObject.InvokeCacheNode.execBooleanEquals(String, RegexObject, Object[], String, ExecBooleanCompiledRegexNode)] */;
                state_0 = state_0 | 0b100 /* add SpecializationActive[RegexObject.InvokeCacheNode.invokeGeneric(String, RegexObject, Object[], ExecCompiledRegexNode, ExecBooleanCompiledRegexNode)] */;
                this.state_0_ = state_0;
                return InvokeCacheNode.invokeGeneric(arg0Value, arg1Value, arg2Value, execNode_2, execBoolNode_2);
            } finally {
                if (oldState_0 != 0) {
                    checkForPolymorphicSpecialize(oldState_0);
                }
            }
        }

        private void checkForPolymorphicSpecialize(int oldState_0) {
            if (((oldState_0 & 0b100) == 0 && (state_0_ & 0b100) != 0)) {
                this.reportPolymorphicSpecialize();
            }
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                    ExecIdentityData s0_ = this.execIdentity_cache;
                    ExecEqualsData s1_ = this.execEquals_cache;
                    ExecBooleanIdentityData s2_ = this.execBooleanIdentity_cache;
                    ExecBooleanEqualsData s3_ = this.execBooleanEquals_cache;
                    if ((s0_ == null || s0_.next_ == null) && (s1_ == null || s1_.next_ == null) && (s2_ == null || s2_.next_ == null) && (s3_ == null || s3_.next_ == null)) {
                        return NodeCost.MONOMORPHIC;
                    }
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static InvokeCacheNode create() {
            return new InvokeCacheNodeGen();
        }

        @NeverDefault
        public static InvokeCacheNode getUncached() {
            return InvokeCacheNodeGen.UNCACHED;
        }

        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class ExecIdentityData implements SpecializationDataNode {

            @CompilationFinal final ExecIdentityData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InvokeCacheNode#execIdentity}
             *   Parameter: {@link String} cachedSymbol</pre>
             */
            @CompilationFinal String cachedSymbol_;

            ExecIdentityData(ExecIdentityData next_) {
                this.next_ = next_;
            }

        }
        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class ExecEqualsData implements SpecializationDataNode {

            @CompilationFinal final ExecEqualsData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InvokeCacheNode#execEquals}
             *   Parameter: {@link String} cachedSymbol</pre>
             */
            @CompilationFinal String cachedSymbol_;

            ExecEqualsData(ExecEqualsData next_) {
                this.next_ = next_;
            }

        }
        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class ExecBooleanIdentityData implements SpecializationDataNode {

            @CompilationFinal final ExecBooleanIdentityData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InvokeCacheNode#execBooleanIdentity}
             *   Parameter: {@link String} cachedSymbol</pre>
             */
            @CompilationFinal String cachedSymbol_;

            ExecBooleanIdentityData(ExecBooleanIdentityData next_) {
                this.next_ = next_;
            }

        }
        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class ExecBooleanEqualsData implements SpecializationDataNode {

            @CompilationFinal final ExecBooleanEqualsData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link InvokeCacheNode#execBooleanEquals}
             *   Parameter: {@link String} cachedSymbol</pre>
             */
            @CompilationFinal String cachedSymbol_;

            ExecBooleanEqualsData(ExecBooleanEqualsData next_) {
                this.next_ = next_;
            }

        }
        @GeneratedBy(InvokeCacheNode.class)
        @DenyReplace
        private static final class Uncached extends InvokeCacheNode {

            @TruffleBoundary
            @Override
            Object execute(String arg0Value, RegexObject arg1Value, Object[] arg2Value) throws UnsupportedMessageException, ArityException, UnsupportedTypeException, UnknownIdentifierException {
                return InvokeCacheNode.invokeGeneric(arg0Value, arg1Value, arg2Value, (ExecCompiledRegexNodeGen.getUncached()), (ExecBooleanCompiledRegexNodeGen.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ExecCompiledRegexNode#doDirectCall}
     *     Activation probability: 0.65000
     *     With/without class size: 22/8 bytes
     *   Specialization {@link ExecCompiledRegexNode#doIndirectCall}
     *     Activation probability: 0.35000
     *     With/without class size: 11/4 bytes
     * </pre>
     */
    @GeneratedBy(ExecCompiledRegexNode.class)
    @SuppressWarnings("javadoc")
    static final class ExecCompiledRegexNodeGen extends ExecCompiledRegexNode {

        static final ReferenceField<DirectCallData> DIRECT_CALL_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "directCall_cache", DirectCallData.class);
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link ExecCompiledRegexNode#doDirectCall}
         *   1: SpecializationActive {@link ExecCompiledRegexNode#doIndirectCall}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        @UnsafeAccessedField @Child private DirectCallData directCall_cache;
        /**
         * Source Info: <pre>
         *   Specialization: {@link ExecCompiledRegexNode#doIndirectCall}
         *   Parameter: {@link IndirectCallNode} indirectCallNode</pre>
         */
        @Child private IndirectCallNode indirectCall_indirectCallNode_;

        private ExecCompiledRegexNodeGen() {
        }

        @ExplodeLoop
        @Override
        Object execute(RegexObject arg0Value, Object[] arg1Value) throws UnsupportedMessageException, ArityException, UnsupportedTypeException {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[RegexObject.ExecCompiledRegexNode.doDirectCall(RegexObject, Object[], RegexObject, DirectCallNode)] || SpecializationActive[RegexObject.ExecCompiledRegexNode.doIndirectCall(RegexObject, Object[], IndirectCallNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexObject.ExecCompiledRegexNode.doDirectCall(RegexObject, Object[], RegexObject, DirectCallNode)] */) {
                    DirectCallData s0_ = this.directCall_cache;
                    while (s0_ != null) {
                        if ((arg0Value == s0_.cachedReceiver_)) {
                            return ExecCompiledRegexNode.doDirectCall(arg0Value, arg1Value, s0_.cachedReceiver_, s0_.directCallNode_);
                        }
                        s0_ = s0_.next_;
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[RegexObject.ExecCompiledRegexNode.doIndirectCall(RegexObject, Object[], IndirectCallNode)] */) {
                    {
                        IndirectCallNode indirectCallNode__ = this.indirectCall_indirectCallNode_;
                        if (indirectCallNode__ != null) {
                            return ExecCompiledRegexNode.doIndirectCall(arg0Value, arg1Value, indirectCallNode__);
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(RegexObject arg0Value, Object[] arg1Value) {
            int state_0 = this.state_0_;
            int oldState_0 = state_0;
            try {
                if (((state_0 & 0b10)) == 0 /* is-not SpecializationActive[RegexObject.ExecCompiledRegexNode.doIndirectCall(RegexObject, Object[], IndirectCallNode)] */) {
                    while (true) {
                        int count0_ = 0;
                        DirectCallData s0_ = DIRECT_CALL_CACHE_UPDATER.getVolatile(this);
                        DirectCallData s0_original = s0_;
                        while (s0_ != null) {
                            if ((arg0Value == s0_.cachedReceiver_)) {
                                break;
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            // assert (arg0Value == s0_.cachedReceiver_);
                            if (count0_ < (4)) {
                                s0_ = this.insert(new DirectCallData(s0_original));
                                s0_.cachedReceiver_ = (arg0Value);
                                s0_.directCallNode_ = s0_.insert((DirectCallNode.create(arg0Value.getExecCallTarget())));
                                if (!DIRECT_CALL_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                    continue;
                                }
                                state_0 = state_0 | 0b1 /* add SpecializationActive[RegexObject.ExecCompiledRegexNode.doDirectCall(RegexObject, Object[], RegexObject, DirectCallNode)] */;
                                this.state_0_ = state_0;
                            }
                        }
                        if (s0_ != null) {
                            return ExecCompiledRegexNode.doDirectCall(arg0Value, arg1Value, s0_.cachedReceiver_, s0_.directCallNode_);
                        }
                        break;
                    }
                }
                VarHandle.storeStoreFence();
                this.indirectCall_indirectCallNode_ = this.insert((IndirectCallNode.create()));
                this.directCall_cache = null;
                state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[RegexObject.ExecCompiledRegexNode.doDirectCall(RegexObject, Object[], RegexObject, DirectCallNode)] */;
                state_0 = state_0 | 0b10 /* add SpecializationActive[RegexObject.ExecCompiledRegexNode.doIndirectCall(RegexObject, Object[], IndirectCallNode)] */;
                this.state_0_ = state_0;
                return ExecCompiledRegexNode.doIndirectCall(arg0Value, arg1Value, this.indirectCall_indirectCallNode_);
            } finally {
                if (oldState_0 != 0) {
                    checkForPolymorphicSpecialize(oldState_0);
                }
            }
        }

        private void checkForPolymorphicSpecialize(int oldState_0) {
            if (((oldState_0 & 0b10) == 0 && (state_0_ & 0b10) != 0)) {
                this.reportPolymorphicSpecialize();
            }
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                    DirectCallData s0_ = this.directCall_cache;
                    if ((s0_ == null || s0_.next_ == null)) {
                        return NodeCost.MONOMORPHIC;
                    }
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static ExecCompiledRegexNode create() {
            return new ExecCompiledRegexNodeGen();
        }

        @NeverDefault
        public static ExecCompiledRegexNode getUncached() {
            return ExecCompiledRegexNodeGen.UNCACHED;
        }

        @GeneratedBy(ExecCompiledRegexNode.class)
        @DenyReplace
        private static final class DirectCallData extends Node implements SpecializationDataNode {

            @Child DirectCallData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ExecCompiledRegexNode#doDirectCall}
             *   Parameter: {@link RegexObject} cachedReceiver</pre>
             */
            @CompilationFinal RegexObject cachedReceiver_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ExecCompiledRegexNode#doDirectCall}
             *   Parameter: {@link DirectCallNode} directCallNode</pre>
             */
            @Child DirectCallNode directCallNode_;

            DirectCallData(DirectCallData next_) {
                this.next_ = next_;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

        }
        @GeneratedBy(ExecCompiledRegexNode.class)
        @DenyReplace
        private static final class Uncached extends ExecCompiledRegexNode {

            @TruffleBoundary
            @Override
            Object execute(RegexObject arg0Value, Object[] arg1Value) throws UnsupportedMessageException, ArityException, UnsupportedTypeException {
                return ExecCompiledRegexNode.doIndirectCall(arg0Value, arg1Value, (IndirectCallNode.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
    /**
     * Debug Info: <pre>
     *   Specialization {@link ExecBooleanCompiledRegexNode#doDirectCall}
     *     Activation probability: 0.65000
     *     With/without class size: 22/8 bytes
     *   Specialization {@link ExecBooleanCompiledRegexNode#doIndirectCall}
     *     Activation probability: 0.35000
     *     With/without class size: 11/4 bytes
     * </pre>
     */
    @GeneratedBy(ExecBooleanCompiledRegexNode.class)
    @SuppressWarnings("javadoc")
    static final class ExecBooleanCompiledRegexNodeGen extends ExecBooleanCompiledRegexNode {

        static final ReferenceField<DirectCallData> DIRECT_CALL_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "directCall_cache", DirectCallData.class);
        private static final Uncached UNCACHED = new Uncached();

        /**
         * State Info: <pre>
         *   0: SpecializationActive {@link ExecBooleanCompiledRegexNode#doDirectCall}
         *   1: SpecializationActive {@link ExecBooleanCompiledRegexNode#doIndirectCall}
         * </pre>
         */
        @CompilationFinal private int state_0_;
        @UnsafeAccessedField @Child private DirectCallData directCall_cache;
        /**
         * Source Info: <pre>
         *   Specialization: {@link ExecBooleanCompiledRegexNode#doIndirectCall}
         *   Parameter: {@link IndirectCallNode} indirectCallNode</pre>
         */
        @Child private IndirectCallNode indirectCall_indirectCallNode_;

        private ExecBooleanCompiledRegexNodeGen() {
        }

        @ExplodeLoop
        @Override
        Object execute(RegexObject arg0Value, Object[] arg1Value) throws UnsupportedMessageException, ArityException, UnsupportedTypeException {
            int state_0 = this.state_0_;
            if (state_0 != 0 /* is SpecializationActive[RegexObject.ExecBooleanCompiledRegexNode.doDirectCall(RegexObject, Object[], RegexObject, DirectCallNode)] || SpecializationActive[RegexObject.ExecBooleanCompiledRegexNode.doIndirectCall(RegexObject, Object[], IndirectCallNode)] */) {
                if ((state_0 & 0b1) != 0 /* is SpecializationActive[RegexObject.ExecBooleanCompiledRegexNode.doDirectCall(RegexObject, Object[], RegexObject, DirectCallNode)] */) {
                    DirectCallData s0_ = this.directCall_cache;
                    while (s0_ != null) {
                        if ((arg0Value == s0_.cachedReceiver_)) {
                            return ExecBooleanCompiledRegexNode.doDirectCall(arg0Value, arg1Value, s0_.cachedReceiver_, s0_.directCallNode_);
                        }
                        s0_ = s0_.next_;
                    }
                }
                if ((state_0 & 0b10) != 0 /* is SpecializationActive[RegexObject.ExecBooleanCompiledRegexNode.doIndirectCall(RegexObject, Object[], IndirectCallNode)] */) {
                    {
                        IndirectCallNode indirectCallNode__ = this.indirectCall_indirectCallNode_;
                        if (indirectCallNode__ != null) {
                            return ExecBooleanCompiledRegexNode.doIndirectCall(arg0Value, arg1Value, indirectCallNode__);
                        }
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(RegexObject arg0Value, Object[] arg1Value) {
            int state_0 = this.state_0_;
            int oldState_0 = state_0;
            try {
                if (((state_0 & 0b10)) == 0 /* is-not SpecializationActive[RegexObject.ExecBooleanCompiledRegexNode.doIndirectCall(RegexObject, Object[], IndirectCallNode)] */) {
                    while (true) {
                        int count0_ = 0;
                        DirectCallData s0_ = DIRECT_CALL_CACHE_UPDATER.getVolatile(this);
                        DirectCallData s0_original = s0_;
                        while (s0_ != null) {
                            if ((arg0Value == s0_.cachedReceiver_)) {
                                break;
                            }
                            count0_++;
                            s0_ = s0_.next_;
                        }
                        if (s0_ == null) {
                            // assert (arg0Value == s0_.cachedReceiver_);
                            if (count0_ < (4)) {
                                s0_ = this.insert(new DirectCallData(s0_original));
                                s0_.cachedReceiver_ = (arg0Value);
                                s0_.directCallNode_ = s0_.insert((DirectCallNode.create(arg0Value.getExecBooleanCallTarget())));
                                if (!DIRECT_CALL_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                    continue;
                                }
                                state_0 = state_0 | 0b1 /* add SpecializationActive[RegexObject.ExecBooleanCompiledRegexNode.doDirectCall(RegexObject, Object[], RegexObject, DirectCallNode)] */;
                                this.state_0_ = state_0;
                            }
                        }
                        if (s0_ != null) {
                            return ExecBooleanCompiledRegexNode.doDirectCall(arg0Value, arg1Value, s0_.cachedReceiver_, s0_.directCallNode_);
                        }
                        break;
                    }
                }
                VarHandle.storeStoreFence();
                this.indirectCall_indirectCallNode_ = this.insert((IndirectCallNode.create()));
                this.directCall_cache = null;
                state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[RegexObject.ExecBooleanCompiledRegexNode.doDirectCall(RegexObject, Object[], RegexObject, DirectCallNode)] */;
                state_0 = state_0 | 0b10 /* add SpecializationActive[RegexObject.ExecBooleanCompiledRegexNode.doIndirectCall(RegexObject, Object[], IndirectCallNode)] */;
                this.state_0_ = state_0;
                return ExecBooleanCompiledRegexNode.doIndirectCall(arg0Value, arg1Value, this.indirectCall_indirectCallNode_);
            } finally {
                if (oldState_0 != 0) {
                    checkForPolymorphicSpecialize(oldState_0);
                }
            }
        }

        private void checkForPolymorphicSpecialize(int oldState_0) {
            if (((oldState_0 & 0b10) == 0 && (state_0_ & 0b10) != 0)) {
                this.reportPolymorphicSpecialize();
            }
        }

        @Override
        public NodeCost getCost() {
            int state_0 = this.state_0_;
            if (state_0 == 0) {
                return NodeCost.UNINITIALIZED;
            } else {
                if ((state_0 & (state_0 - 1)) == 0 /* is-single  */) {
                    DirectCallData s0_ = this.directCall_cache;
                    if ((s0_ == null || s0_.next_ == null)) {
                        return NodeCost.MONOMORPHIC;
                    }
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        @NeverDefault
        public static ExecBooleanCompiledRegexNode create() {
            return new ExecBooleanCompiledRegexNodeGen();
        }

        @NeverDefault
        public static ExecBooleanCompiledRegexNode getUncached() {
            return ExecBooleanCompiledRegexNodeGen.UNCACHED;
        }

        @GeneratedBy(ExecBooleanCompiledRegexNode.class)
        @DenyReplace
        private static final class DirectCallData extends Node implements SpecializationDataNode {

            @Child DirectCallData next_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ExecBooleanCompiledRegexNode#doDirectCall}
             *   Parameter: {@link RegexObject} cachedReceiver</pre>
             */
            @CompilationFinal RegexObject cachedReceiver_;
            /**
             * Source Info: <pre>
             *   Specialization: {@link ExecBooleanCompiledRegexNode#doDirectCall}
             *   Parameter: {@link DirectCallNode} directCallNode</pre>
             */
            @Child DirectCallNode directCallNode_;

            DirectCallData(DirectCallData next_) {
                this.next_ = next_;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

        }
        @GeneratedBy(ExecBooleanCompiledRegexNode.class)
        @DenyReplace
        private static final class Uncached extends ExecBooleanCompiledRegexNode {

            @TruffleBoundary
            @Override
            Object execute(RegexObject arg0Value, Object[] arg1Value) throws UnsupportedMessageException, ArityException, UnsupportedTypeException {
                return ExecBooleanCompiledRegexNode.doIndirectCall(arg0Value, arg1Value, (IndirectCallNode.getUncached()));
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.MEGAMORPHIC;
            }

            @Override
            public boolean isAdoptable() {
                return false;
            }

        }
    }
}
