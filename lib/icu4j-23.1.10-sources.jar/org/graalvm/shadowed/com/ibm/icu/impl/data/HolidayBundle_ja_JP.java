// @formatter:off
// © 2016 and later: Unicode, Inc. and others.
// License & terms of use: http://www.unicode.org/copyright.html
/*
 *******************************************************************************
 * Copyright (C) 1996-2010, International Business Machines Corporation and    *
 * others. All Rights Reserved.                                                *
 *******************************************************************************
 */

package org.graalvm.shadowed.com.ibm.icu.impl.data;

import java.util.Calendar;
import java.util.ListResourceBundle;

import org.graalvm.shadowed.com.ibm.icu.util.Holiday;
import org.graalvm.shadowed.com.ibm.icu.util.SimpleHoliday;

public class HolidayBundle_ja_JP extends ListResourceBundle {
    static private final Holiday[] fHolidays = {
        new SimpleHoliday(Calendar.FEBRUARY,  11,  0,    "National Foundation Day"),
    };
    static private final Object[][] fContents = {
        {   "holidays",         fHolidays   },
    };
    @Override
    public synchronized Object[][] getContents() { return fContents; }
}
